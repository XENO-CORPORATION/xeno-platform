import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hashValue, sha256 } from './hash.mjs';
import { codeCells, declaredInputs, withOutputs } from './ipynb.mjs';

export const PROVENANCE_FORMAT = 'xeno-research.provenance/1';
export const HARNESS_PATH = resolve(dirname(fileURLToPath(import.meta.url)), 'harness.py');

// Object addresses (`<Foo at 0x7f3a…>`) change on every run and say nothing about the result.
// This is the ONLY normalisation applied, and the record names it so nobody has to guess.
const NORMALISATION = 'object-addresses';
const normalise = (s) => (s == null ? s : String(s).replace(/0x[0-9a-fA-F]{6,}/g, '0x?'));

/** What a cell produced, reduced to the facts a reproduction must match. */
export function cellOutputHash(r) {
  return hashValue(r.outputs.map((o) => {
    switch (o.output_type) {
      case 'stream': return { stream: o.name, text: normalise(o.text) };
      case 'execute_result':
      case 'display_data':
        // Every mime bundle counts (an image is a result); output metadata and execution counts
        // are presentation, not result.
        return { kind: o.output_type, data: Object.fromEntries(Object.entries(o.data).map(([m, v]) => [m, normalise(Array.isArray(v) ? v.join('') : v)])) };
      // The traceback carries interpreter paths and colour codes that differ between machines;
      // the type and message are the result.
      default: return { error: o.ename, evalue: normalise(o.evalue) };
    }
  }));
}

/**
 * Runs a notebook through an executor and returns the notebook with outputs plus its
 * provenance record. The executor is where isolation lives (XENO Box); this function never runs
 * code itself.
 */
export async function runNotebook({ notebook, notebookDir, executor, lock = null, timeoutMs = 600_000 }) {
  const cells = codeCells(notebook);
  if (cells.length === 0) throw new Error('the notebook has no code cells');
  const inputs = [];
  for (const path of declaredInputs(notebook)) {
    const bytes = await readFile(resolve(notebookDir, path));
    inputs.push({ path, bytes, sha256: sha256(bytes) });
  }
  const harness = await readFile(HARNESS_PATH);
  const run = await executor.run({ cells, inputs, harness, lock, timeoutMs });

  const cellRecords = cells.map((c) => {
    const r = run.cells.find((x) => x.index === c.index);
    return {
      index: c.index,
      source_sha256: sha256(c.source),
      status: !r ? 'not-run' : r.error ? 'error' : 'ok',
      output_sha256: r ? cellOutputHash(r) : null,
    };
  });
  const environment = {
    ...run.environment,
    packages_sha256: run.environment.packages ? hashValue(run.environment.packages) : null,
  };
  const subject = {
    code_sha256: hashValue(cells.map((c) => c.source)),
    inputs: inputs.map(({ path, sha256: h }) => ({ path, sha256: h })),
    harness_sha256: sha256(harness),
    // The image digest and the lock are what REBUILD the environment; the package list is what
    // was observed in it. All three are part of the subject, so any of them moving is a "change".
    environment_sha256: hashValue({ image: run.executor?.image ?? null, lock_sha256: lock ? sha256(lock) : null, python: environment.python, implementation: environment.implementation, packages: environment.packages }),
    image: run.executor?.image ?? null,
    lock_sha256: lock ? sha256(lock) : null,
  };
  const provenance = {
    format: PROVENANCE_FORMAT,
    created_at: new Date().toISOString(),
    executor: run.executor,
    normalisation: NORMALISATION,
    subject,
    environment,
    cells: cellRecords,
    complete: cellRecords.every((c) => c.status === 'ok'),
  };
  provenance.run_sha256 = hashValue({ subject, cells: cellRecords.map(({ index, source_sha256, output_sha256 }) => ({ index, source_sha256, output_sha256 })) });
  return { notebook: withOutputs(notebook, run.cells, provenance.run_sha256), provenance };
}

/**
 * Compares a fresh run with a recorded one. Says WHY something differs, because "different code",
 * "different data", "different environment" and "same everything, different answer" are four
 * different findings — only the last is a reproducibility failure.
 */
export function compareRuns(recorded, fresh) {
  const findings = [];
  if (recorded.format !== PROVENANCE_FORMAT) throw new Error(`unknown provenance format ${recorded.format}`);
  if (recorded.subject.code_sha256 !== fresh.subject.code_sha256) findings.push({ kind: 'code-changed' });
  const before = new Map(recorded.subject.inputs.map((i) => [i.path, i.sha256]));
  for (const i of fresh.subject.inputs) {
    if (before.get(i.path) !== i.sha256) findings.push({ kind: 'input-changed', path: i.path });
    before.delete(i.path);
  }
  for (const path of before.keys()) findings.push({ kind: 'input-removed', path });
  if (recorded.subject.environment_sha256 !== fresh.subject.environment_sha256) findings.push({ kind: 'environment-changed' });
  if (recorded.subject.harness_sha256 !== fresh.subject.harness_sha256) findings.push({ kind: 'harness-changed' });

  const sameSubject = findings.length === 0;
  const cells = recorded.cells.map((r) => {
    const f = fresh.cells.find((x) => x.index === r.index);
    const matches = !!f && f.output_sha256 === r.output_sha256 && f.status === r.status;
    return { index: r.index, reproduced: matches };
  });
  const allMatch = cells.every((c) => c.reproduced) && recorded.cells.length === fresh.cells.length;
  let verdict;
  if (allMatch) verdict = 'reproduced';
  else if (sameSubject) verdict = 'not-reproduced'; // same code, data and environment — a real failure
  else verdict = 'changed'; // something it depends on moved; the difference is explained, not a failure
  return { verdict, findings, cells };
}
