// The open export: everything a reviewer needs to re-run a notebook WITHOUT XENO, in formats that
// outlive us (NASA SPD-41a, Horizon Europe FAIR). Also the W3C PROV-JSON view of a run, so the
// provenance is readable by any PROV tool rather than only by ours.

import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, join } from 'node:path';
import { sha256 } from './hash.mjs';
import { lockedPackages } from './lock.mjs';

/** W3C PROV-JSON (https://www.w3.org/submissions/prov-json/) for one run. */
export function toProvJson(provenance, notebookName) {
  const run = `xr:run/${provenance.run_sha256}`;
  const entity = {};
  const used = {};
  const wasGeneratedBy = {};
  entity[`xr:notebook/${provenance.subject.code_sha256}`] = { 'prov:label': notebookName, 'xr:sha256': provenance.subject.code_sha256, 'prov:type': 'xr:NotebookCode' };
  used['_:u-code'] = { 'prov:activity': run, 'prov:entity': `xr:notebook/${provenance.subject.code_sha256}` };
  for (const [i, input] of provenance.subject.inputs.entries()) {
    const id = `xr:input/${input.sha256}`;
    entity[id] = { 'prov:label': input.path, 'xr:sha256': input.sha256, 'prov:type': 'xr:Input' };
    used[`_:u-in${i}`] = { 'prov:activity': run, 'prov:entity': id };
  }
  entity[`xr:environment/${provenance.subject.environment_sha256}`] = {
    'prov:type': 'xr:Environment', 'xr:image': provenance.subject.image, 'xr:lock_sha256': provenance.subject.lock_sha256,
    'xr:python': provenance.environment.python,
  };
  used['_:u-env'] = { 'prov:activity': run, 'prov:entity': `xr:environment/${provenance.subject.environment_sha256}` };
  for (const c of provenance.cells) {
    if (!c.output_sha256) continue;
    const id = `xr:output/${c.index}/${c.output_sha256}`;
    entity[id] = { 'prov:type': 'xr:CellOutput', 'xr:cell': c.index, 'xr:status': c.status, 'xr:sha256': c.output_sha256 };
    wasGeneratedBy[`_:g${c.index}`] = { 'prov:entity': id, 'prov:activity': run };
  }
  return {
    prefix: { xr: 'https://xenosystem.ai/ns/research#' },
    entity,
    activity: { [run]: { 'prov:startTime': provenance.created_at, 'prov:type': 'xr:NotebookRun', 'xr:complete': provenance.complete } },
    agent: { 'xr:executor': { 'prov:type': 'prov:SoftwareAgent', 'xr:kind': provenance.executor?.kind, 'xr:isolation': provenance.executor?.isolation, 'xr:network': provenance.executor?.network } },
    used,
    wasGeneratedBy,
    wasAssociatedWith: { '_:a': { 'prov:activity': run, 'prov:agent': 'xr:executor' } },
  };
}

function readme({ name, provenance, lock }) {
  const packages = lock ? lockedPackages(lock).length : 0;
  return `# ${name} — reproducible research package

Exported by XENO Research. Everything here re-runs without XENO, with standard tools only.

| File | What it is |
|---|---|
| \`${name}\` | the notebook, with the outputs of the recorded run |
${lock ? `| \`${name}.lock\` | the exact environment: ${packages} packages, each pinned and hashed (pip format) |\n` : ''}| ${provenance.subject.inputs.map((i) => `\`${i.path}\``).join(', ') || '(none)'} | the data the notebook read, byte-identical to the recorded run |
| \`provenance.json\` | the run record: hashes of code, inputs, environment and every output${provenance.signature ? '; Ed25519-signed' : ''} |
| \`provenance.prov.json\` | the same run in W3C PROV-JSON |
| \`SHA256SUMS\` | a checksum for every file in this package |

## Re-run it

\`\`\`sh
sha256sum -c SHA256SUMS                       # the package is intact
python3 -m venv .venv && . .venv/bin/activate
${lock ? `pip install --require-hashes --no-deps -r ${name}.lock   # Python ${provenance.environment.python}, Linux x86_64` : 'pip install ipykernel jupyter_client nbconvert'}
pip install nbconvert
jupyter nbconvert --to notebook --execute ${name} --output rerun.ipynb
\`\`\`

Then compare \`rerun.ipynb\` with \`${name}\`, or let XENO do it: \`xeno-research verify ${name}\`
(reports *reproduced*, *changed* with what moved, or *not-reproduced*).

Recorded run: \`${provenance.run_sha256}\` · ${provenance.created_at}
Executor: ${provenance.executor?.kind ?? 'unknown'} (isolation: ${provenance.executor?.isolation ?? 'unknown'}, network: ${provenance.executor?.network ?? 'unknown'})
`;
}

/** Writes the export package to `outDir`. Returns the list of files with their hashes. */
export async function exportPackage({ notebookPath, notebook, provenance, lock, outDir }) {
  const name = basename(notebookPath);
  const files = new Map();
  files.set(name, Buffer.from(`${JSON.stringify(notebook, null, 1)}\n`));
  if (lock) files.set(`${name}.lock`, Buffer.from(lock));
  for (const input of provenance.subject.inputs) {
    const bytes = await readFile(join(dirname(notebookPath), input.path));
    if (sha256(bytes) !== input.sha256) throw new Error(`${input.path} changed since the recorded run; re-run before exporting`);
    // Beside the notebook, at its declared path: that is the folder Jupyter runs a notebook from.
    if (['README.md', 'SHA256SUMS', 'provenance.json', 'provenance.prov.json', name, `${name}.lock`].includes(input.path)) throw new Error(`input ${input.path} collides with a package file`);
    files.set(input.path, bytes);
  }
  files.set('provenance.json', Buffer.from(`${JSON.stringify(provenance, null, 2)}\n`));
  files.set('provenance.prov.json', Buffer.from(`${JSON.stringify(toProvJson(provenance, name), null, 2)}\n`));
  files.set('README.md', Buffer.from(readme({ name, provenance, lock })));
  const sums = [...files].map(([p, b]) => `${sha256(b)}  ${p}`).join('\n');
  files.set('SHA256SUMS', Buffer.from(`${sums}\n`));
  for (const [p, bytes] of files) {
    await mkdir(dirname(join(outDir, p)), { recursive: true });
    await writeFile(join(outDir, p), bytes);
  }
  return [...files].map(([p, b]) => ({ path: p, sha256: sha256(b), bytes: b.length }));
}
