// Reading and writing Jupyter notebooks (nbformat 4). `.ipynb` is the native format (SPEC §9 D4):
// research outputs are never locked in a format of ours.

const sourceText = (s) => (Array.isArray(s) ? s.join('') : String(s ?? ''));
const toLines = (text) => (text ? text.split(/(?<=\n)/) : []);
// Text mime types are stored as line lists in .ipynb; binary ones (image/png) stay base64 strings.
const textLines = (data) =>
  Object.fromEntries(Object.entries(data).map(([mime, v]) => [mime, mime.startsWith('text/') && typeof v === 'string' ? toLines(v) : v]));

export function parseNotebook(text) {
  const nb = JSON.parse(text);
  if (nb?.nbformat !== 4 || !Array.isArray(nb.cells)) {
    throw new Error('not an nbformat 4 notebook (expected "nbformat": 4 and a "cells" array)');
  }
  const language = nb.metadata?.kernelspec?.language ?? nb.metadata?.language_info?.name ?? 'python';
  if (language !== 'python') throw new Error(`kernel language "${language}" is not supported yet; Python only`);
  return nb;
}

/** Code cells in document order, with their position in `nb.cells`. */
export const codeCells = (nb) =>
  nb.cells.flatMap((cell, index) => (cell.cell_type === 'code' ? [{ index, source: sourceText(cell.source) }] : []));

/**
 * Inputs the notebook declares in `metadata.xeno.inputs` — relative paths next to the notebook.
 * Declared, not discovered: a result can only be checked against data we know it read.
 */
export function declaredInputs(nb) {
  const inputs = nb.metadata?.xeno?.inputs ?? [];
  if (!Array.isArray(inputs)) throw new Error('metadata.xeno.inputs must be a list of relative paths');
  for (const p of inputs) {
    if (typeof p !== 'string' || !p || p.startsWith('/') || /^[a-zA-Z]:/.test(p) || p.split(/[\\/]/).includes('..')) {
      throw new Error(`input "${p}" must be a relative path inside the notebook's folder`);
    }
  }
  return inputs.map((p) => p.replace(/\\/g, '/'));
}

/** Writes a run's outputs into the notebook as standard Jupyter outputs. */
export function withOutputs(nb, cellResults, runSha256) {
  const next = structuredClone(nb);
  const byIndex = new Map(cellResults.map((r) => [r.index, r]));
  let count = 0;
  for (const [index, cell] of next.cells.entries()) {
    if (cell.cell_type !== 'code') continue;
    const r = byIndex.get(index);
    if (!r) {
      cell.outputs = [];
      cell.execution_count = null;
      continue;
    }
    count += 1;
    // The kernel already speaks nbformat; only the multi-line text convention is applied here.
    cell.outputs = r.outputs.map((o) => {
      if (o.output_type === 'stream') return { ...o, text: toLines(o.text) };
      if (o.output_type === 'execute_result') return { ...o, execution_count: count, data: textLines(o.data) };
      if (o.output_type === 'display_data') return { ...o, data: textLines(o.data) };
      return o;
    });
    cell.execution_count = count;
  }
  // nbformat 4 requires kernelspec.name AND display_name; fill only what is missing, so the file we
  // write passes Jupyter's own validator even when the source notebook did not.
  const kernelspec = next.metadata?.kernelspec ?? {};
  next.metadata = {
    ...next.metadata,
    kernelspec: { ...kernelspec, name: kernelspec.name ?? 'python3', display_name: kernelspec.display_name ?? 'Python 3', language: kernelspec.language ?? 'python' },
    xeno: { ...next.metadata?.xeno, run_sha256: runSha256 },
  };
  return next;
}
