"""XENO Research cell harness.

Runs every code cell of a notebook IN ORDER through a FRESH Jupyter kernel (ipykernel, the Jupyter
messaging protocol) and prints one JSON record. The kernel lives only for this run: there is no
long-lived kernel, so there is no hidden state and no out-of-order execution. That is the
reproducibility model. The kernel is what gives us Jupyter's real outputs — streams, rich results
(text/plain, text/html), display data (image/png from matplotlib) and errors — in nbformat shape.

Usage: python3 harness.py <cells.json>
"""
import json
import os
import platform
import sys
import tempfile

from jupyter_client.manager import start_new_kernel

MARKER = "\x1eXENO-RESEARCH-RESULT\x1e"
CELL_TIMEOUT_S = 3600
KEEP = {"stream", "execute_result", "display_data", "error"}


def environment():
    try:
        from importlib.metadata import distributions
        packages = sorted({f"{d.metadata['Name']}=={d.version}" for d in distributions() if d.metadata["Name"]})
    except Exception:  # pragma: no cover - recorded, never hidden
        packages = None
    return {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "kernel": "ipykernel",
        "packages": packages,
    }


def kernel_env():
    # Box runs the image read-only: every place Jupyter or IPython writes goes under a temp dir.
    scratch = tempfile.mkdtemp(prefix="xeno-research-")
    env = dict(os.environ)
    env.update({
        "JUPYTER_RUNTIME_DIR": os.path.join(scratch, "runtime"),
        "JUPYTER_DATA_DIR": os.path.join(scratch, "data"),
        "IPYTHONDIR": os.path.join(scratch, "ipython"),
        "MPLCONFIGDIR": os.path.join(scratch, "matplotlib"),
        # Inline plots become image/png display data, the way Jupyter shows them.
        "MPLBACKEND": "module://matplotlib_inline.backend_inline",
    })
    os.environ["JUPYTER_RUNTIME_DIR"] = env["JUPYTER_RUNTIME_DIR"]
    return env


def to_output(msg):
    kind, c = msg["header"]["msg_type"], msg["content"]
    if kind == "stream":
        return {"output_type": "stream", "name": c["name"], "text": c["text"]}
    if kind == "execute_result":
        return {"output_type": "execute_result", "data": c["data"], "metadata": c.get("metadata", {})}
    if kind == "display_data":
        return {"output_type": "display_data", "data": c["data"], "metadata": c.get("metadata", {})}
    return {"output_type": "error", "ename": c["ename"], "evalue": c["evalue"], "traceback": c["traceback"]}


def run_cell(kc, source, index):
    msg_id = kc.execute(source, store_history=True, allow_stdin=False, stop_on_error=True)
    outputs = []
    while True:
        msg = kc.get_iopub_msg(timeout=CELL_TIMEOUT_S)
        if msg["parent_header"].get("msg_id") != msg_id:
            continue
        kind = msg["header"]["msg_type"]
        if kind == "status" and msg["content"]["execution_state"] == "idle":
            break
        if kind in KEEP:
            out = to_output(msg)
            # Merge consecutive writes to the same stream, as Jupyter front ends do, so how the
            # kernel happened to chunk its output does not change the result.
            if out["output_type"] == "stream" and outputs and outputs[-1]["output_type"] == "stream" and outputs[-1]["name"] == out["name"]:
                outputs[-1]["text"] += out["text"]
            else:
                outputs.append(out)
    error = next(({"ename": o["ename"], "evalue": o["evalue"]} for o in outputs if o["output_type"] == "error"), None)
    return {"index": index, "outputs": outputs, "error": error}


def main():
    with open(sys.argv[1], encoding="utf-8") as fh:
        cells = json.load(fh)
    km, kc = start_new_kernel(kernel_name="python3", env=kernel_env(), cwd=os.getcwd())
    results = []
    try:
        for cell in cells:
            record = run_cell(kc, cell["source"], cell["index"])
            results.append(record)
            if record["error"] is not None:
                break
    finally:
        kc.stop_channels()
        km.shutdown_kernel(now=True)
    sys.stdout.write(MARKER + json.dumps({"environment": environment(), "cells": results}) + "\n")


if __name__ == "__main__":
    main()
