// The one executor: XENO Box over its HTTP API (`xeno-box/crates/box-server/src/api.rs`).
// Research never runs a cell on the host. There is deliberately no local fallback — a notebook that
// silently ran unsandboxed would record a provenance that claims an isolation it never had.
//
// Three kinds of sandbox share one volume, and only two of them ever get a network:
//   lock    — egress to PyPI only: `uv pip compile` resolves requirements into a pinned, hashed lock
//   install — egress to PyPI only: a fresh venv built from exactly the locked wheels, hashes
//             enforced, binary wheels only (no package build scripts run). No notebook code here.
//   run     — NO network: the notebook runs in that venv
// So the code that runs a notebook can never reach the internet, and the environment it ran in
// is rebuilt from the lock every time rather than described after the fact.
// uv, not pip: Box's egress relay accepts only HTTP/1.1 CONNECT and Python's http.client sends
// HTTP/1.0 — and uv is the current standard for Python locking anyway.

import { randomUUID } from 'node:crypto';

const WORK = '/mnt/xeno/work';
const MARKER = '\x1eXENO-RESEARCH-RESULT\x1e';
const PYPI = [
  { protocol: 'https', hostname: 'pypi.org', port: 443 },
  { protocol: 'https', hostname: 'files.pythonhosted.org', port: 443 },
];
const PROXY_ENV = [
  { name: 'HTTPS_PROXY', value: 'http://127.0.0.1:3128' },
  { name: 'HTTP_PROXY', value: 'http://127.0.0.1:3128' },
];
// The image is read-only: everything pip or Python writes goes to a tmpfs or the volume.
const BASE_ENV = [
  { name: 'HOME', value: '/tmp' },
  { name: 'UV_CACHE_DIR', value: '/tmp/uv-cache' },
  { name: 'UV_LINK_MODE', value: 'copy' },
  { name: 'UV_NO_PROGRESS', value: '1' },
  { name: 'PIP_CACHE_DIR', value: '/tmp/pip-cache' },
  { name: 'PIP_DISABLE_PIP_VERSION_CHECK', value: '1' },
  { name: 'PYTHONHASHSEED', value: '0' },
  { name: 'PYTHONDONTWRITEBYTECODE', value: '1' },
];

export class BoxError extends Error {}

// Who is running. Fail closed: anything other than an explicit 'xeno' is an outside lab, and an
// outside lab's code runs only on a Box that reports host_safety.state === 'qualified'. An
// unqualified backend is fine for our own notebooks and not a promise we make to anyone else.
export const AUDIENCES = ['xeno', 'external'];
export function assertQualifiedFor(audience, caps) {
  if (audience === 'xeno') return;
  const state = caps?.host_safety?.state ?? 'unknown';
  if (state !== 'qualified') {
    throw new BoxError(`this Box reports host_safety "${state}", not "qualified"; runs for outside labs are refused until it is (internal XENO use: XENO_RESEARCH_AUDIENCE=xeno)`);
  }
}

export class BoxExecutor {
  constructor({ url, token, image, audience = 'external', fetchImpl = fetch }) {
    if (!url || !token) throw new BoxError('a Box URL and token are required (XENO_BOX_URL, XENO_BOX_TOKEN)');
    this.audience = audience === 'xeno' ? 'xeno' : 'external';
    this.url = url.replace(/\/$/, '');
    this.token = token;
    this.image = image;
    this.fetch = fetchImpl;
  }

  async call(method, path, body, headers = {}) {
    const raw = body instanceof Uint8Array || typeof body === 'string';
    const res = await this.fetch(this.url + path, {
      method,
      headers: { authorization: `Bearer ${this.token}`, ...(raw || body === undefined ? {} : { 'content-type': 'application/json' }), ...headers },
      body: body === undefined ? undefined : raw ? body : JSON.stringify(body),
    });
    const text = await res.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch { json = text; }
    return { status: res.status, json };
  }

  async expect(status, method, path, body, headers) {
    const r = await this.call(method, path, body, headers);
    const ok = Array.isArray(status) ? status.includes(r.status) : r.status === status;
    if (!ok) throw new BoxError(`Box ${method} ${path} answered ${r.status}: ${typeof r.json === 'string' ? r.json : JSON.stringify(r.json)}`);
    return r.json;
  }

  async capabilities() {
    const caps = await this.expect(200, 'GET', '/v1/capabilities');
    assertQualifiedFor(this.audience, caps);
    if (caps.backend?.kind && caps.backend.kind !== 'container') {
      throw new BoxError(`Box backend "${caps.backend.kind}" is not supported yet; notebooks run on the Linux container backend`);
    }
    const image = this.image ?? caps.images?.[0];
    if (!image || !caps.images?.includes(image)) throw new BoxError(`image "${image}" is not on this Box's approved list: ${JSON.stringify(caps.images)}`);
    return { caps, image };
  }

  /** A volume for one job, destroyed afterwards. Teardown is asserted, never assumed. */
  async withVolume(fn) {
    const volume = await this.expect(201, 'POST', '/v1/volumes', { name: 'xeno-research' }, { 'idempotency-key': `research-vol-${randomUUID()}` });
    const put = (path, bytes) => this.expect(204, 'PUT', `/v1/volumes/${volume.id}/files?path=${encodeURIComponent(path)}`, bytes);
    const get = async (path) => {
      const res = await this.fetch(`${this.url}/v1/volumes/${volume.id}/files?path=${encodeURIComponent(path)}`, { headers: { authorization: `Bearer ${this.token}` } });
      if (res.status !== 200) throw new BoxError(`Box could not return ${path}: ${res.status}`);
      return Buffer.from(await res.arrayBuffer());
    };
    let failure = null;
    try {
      return await fn({ volume, put, get });
    } catch (error) {
      failure = error;
      throw error;
    } finally {
      const v = await this.call('DELETE', `/v1/volumes/${volume.id}`);
      if (v.status !== 204) throw new BoxError(`Box teardown failed — volume ${volume.id}: ${v.status}${failure ? ` (after: ${failure.message})` : ''}`);
    }
  }

  /** One sandbox on the volume; `network` must be a subset of this tenant's allowlist. */
  async withSandbox({ image, volume, network = [] }, fn) {
    const sandbox = await this.expect([200, 201], 'POST', '/v1/sandboxes',
      { workspace: 'xeno-research', image, mounts: [{ volume: volume.id, target: WORK, read_only: false }], network },
      { 'idempotency-key': `research-sbx-${randomUUID()}` });
    const exec = (argv, { timeoutMs = 600_000, env = [], cwd } = {}) =>
      this.expect(200, 'POST', `/v1/sandboxes/${sandbox.id}/exec`, { argv, cwd, timeout_ms: timeoutMs, env: [...BASE_ENV, ...env] });
    let failure = null;
    try {
      if (network.length) {
        // The relay starts with the sandbox; wait for it rather than racing the first request.
        const ready = await exec(['sh', '-c', 'for i in $(seq 1 100); do test -f /run/xeno-box-egress-relay.ready && exit 0; sleep 0.1; done; exit 1'], { timeoutMs: 30_000 });
        if (ready.exit_code !== 0) throw new BoxError('Box granted egress but the relay never became ready');
      }
      return await fn({ exec, sandbox });
    } catch (error) {
      failure = error;
      throw error;
    } finally {
      // A destroy can time out on Box's side while it completes in the background (seen once,
      // 2026-10-19); destroy is idempotent, so one retry tells "slow" from "failed".
      let d = await this.call('DELETE', `/v1/sandboxes/${sandbox.id}`);
      if (![200, 202, 204, 404].includes(d.status)) d = await this.call('DELETE', `/v1/sandboxes/${sandbox.id}`);
      if (![200, 202, 204, 404].includes(d.status)) {
        throw new BoxError(`Box teardown failed — sandbox ${sandbox.id}: ${d.status}${failure ? ` (after: ${failure.message})` : ''}`);
      }
    }
  }

  static checked(r, what) {
    if (r.timed_out) throw new BoxError(`${what} did not finish in time`);
    if (r.exit_code !== 0) throw new BoxError(`${what} failed (exit ${r.exit_code}): ${(r.stderr || r.stdout).slice(-2500)}`);
    return r;
  }

  /**
   * Resolves requirements into a lock for the image's own platform and Python, inside Box, with
   * egress to PyPI only. Returns uv's pinned, hashed requirements text.
   */
  async resolve({ requirements }) {
    const { image } = await this.capabilities();
    return this.withVolume(async ({ volume, put, get }) => {
      await put('.xeno/requirements.in', requirements);
      return this.withSandbox({ image, volume, network: PYPI }, async ({ exec }) => {
        BoxExecutor.checked(await exec(['uv', 'pip', 'compile', `${WORK}/.xeno/requirements.in`, '--generate-hashes', '--only-binary', ':all:',
          '--python', 'python3', '--no-header', '--no-annotate', '-o', `${WORK}/.xeno/requirements.lock`], { env: PROXY_ENV }), 'resolving the requirements');
        const py = BoxExecutor.checked(await exec(['python3', '-c', 'import platform,sys;print(platform.python_version());print(sys.platform)']), 'reading the Python version');
        const [python, platform] = py.stdout.trim().split('\n');
        return { image, compiled: (await get('.xeno/requirements.lock')).toString('utf8'), python, platform };
      });
    });
  }

  async run({ cells, inputs, harness, lock, timeoutMs }) {
    const { caps, image } = await this.capabilities();
    return this.withVolume(async ({ volume, put }) => {
      await put('.xeno/harness.py', harness);
      await put('.xeno/cells.json', JSON.stringify(cells.map(({ index, source }) => ({ index, source }))));
      for (const i of inputs) await put(`inputs/${i.path}`, i.bytes);
      const venv = `${WORK}/.xeno/venv`;
      if (lock) {
        await put('.xeno/requirements.lock', lock);
        // Rebuild the environment from the lock: exact versions, every file's hash checked, wheels only.
        await this.withSandbox({ image, volume, network: PYPI }, async ({ exec }) => {
          BoxExecutor.checked(await exec(['uv', 'venv', venv, '--python', 'python3']), 'creating the environment');
          BoxExecutor.checked(await exec(['uv', 'pip', 'install', '--python', `${venv}/bin/python`, '--require-hashes', '--no-deps', '--only-binary', ':all:',
            '-r', `${WORK}/.xeno/requirements.lock`], { env: PROXY_ENV }), 'installing the locked environment');
        });
      }
      return this.withSandbox({ image, volume }, async ({ exec }) => {
        BoxExecutor.checked(await exec(['mkdir', '-p', `${WORK}/inputs`], { timeoutMs: 10_000 }), 'preparing the work folder');
        const python = lock ? `${venv}/bin/python` : 'python3';
        const probe = await exec([python, '-c', 'import jupyter_client, ipykernel'], { timeoutMs: 60_000 });
        if (probe.exit_code !== 0) {
          throw new BoxError(lock
            ? 'the locked environment has no Jupyter kernel — re-run `xeno-research lock` (it adds ipykernel)'
            : `Box image "${image}" has no Python Jupyter kernel — a scientific Python image must be on Box's approved list (cross-repo requirement on xeno-box)`);
        }
        const r = await exec([python, `${WORK}/.xeno/harness.py`, `${WORK}/.xeno/cells.json`], { timeoutMs, cwd: `${WORK}/inputs` });
        if (r.timed_out) throw new BoxError(`the notebook did not finish within ${timeoutMs} ms`);
        if (r.truncated) throw new BoxError('the notebook produced more output than Box returns (2 MiB); the run is incomplete and is not recorded');
        const at = r.stdout.lastIndexOf(MARKER);
        if (r.exit_code !== 0 || at < 0) throw new BoxError(`the harness failed (exit ${r.exit_code}): ${r.stderr.slice(-2000)}`);
        const parsed = JSON.parse(r.stdout.slice(at + MARKER.length));
        return {
          ...parsed,
          executor: { kind: 'xeno-box', image, backend: caps.backend ?? null, isolation: caps.sandbox?.isolation ?? null, network: caps.network ?? null, host_safety: caps.host_safety ?? null },
        };
      });
    });
  }
}
