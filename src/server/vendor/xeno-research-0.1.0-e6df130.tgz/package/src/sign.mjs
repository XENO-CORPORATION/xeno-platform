// Signed provenance. A record is signed with Ed25519 over its canonical JSON (sorted keys, the
// `signature` field excluded), so anyone holding the record and the public key can check that
// nothing in it — code hashes, inputs, environment, outputs, verdict — changed after the run.
//
// What a signature proves: WHO vouched for the record (the holder of the key). It does not by itself
// prove the run happened in Box; that is what the record's executor block and a re-run are for.

import { createPrivateKey, createPublicKey, generateKeyPairSync, sign, verify } from 'node:crypto';
import { canonical, sha256 } from './hash.mjs';

const ALGORITHM = 'ed25519';
// PKCS#8 / SPKI DER prefixes for a raw 32-byte Ed25519 key — the format the ecosystem stores (hex).
const PKCS8 = Buffer.from('302e020100300506032b657004220420', 'hex');
const SPKI = Buffer.from('302a300506032b6570032100', 'hex');

export function newSigningKey() {
  const { privateKey } = generateKeyPairSync('ed25519');
  return privateKey.export({ format: 'der', type: 'pkcs8' }).subarray(PKCS8.length).toString('hex');
}

function privateKey(hex) {
  if (!/^[0-9a-f]{64}$/i.test(hex ?? '')) throw new Error('a signing key is 64 hex characters (XENO_RESEARCH_SIGNING_KEY)');
  return createPrivateKey({ key: Buffer.concat([PKCS8, Buffer.from(hex, 'hex')]), format: 'der', type: 'pkcs8' });
}

export function publicKeyHex(secretHex) {
  return createPublicKey(privateKey(secretHex)).export({ format: 'der', type: 'spki' }).subarray(SPKI.length).toString('hex');
}

const payload = (record) => {
  const { signature, ...rest } = record;
  return Buffer.from(canonical(rest), 'utf8');
};

export function signRecord(record, secretHex) {
  const public_key = publicKeyHex(secretHex);
  const unsigned = { ...record };
  delete unsigned.signature;
  const value = sign(null, payload(unsigned), privateKey(secretHex)).toString('hex');
  return { ...unsigned, signature: { algorithm: ALGORITHM, public_key, key_id: sha256(Buffer.from(public_key, 'hex')).slice(0, 16), value } };
}

/** Checks a record's signature, and optionally that it was made by an expected key. */
export function verifyRecord(record, expectedPublicKeyHex) {
  const s = record.signature;
  if (!s) return { valid: false, reason: 'unsigned' };
  if (s.algorithm !== ALGORITHM) return { valid: false, reason: `unknown algorithm ${s.algorithm}` };
  if (expectedPublicKeyHex && s.public_key !== expectedPublicKeyHex) return { valid: false, reason: 'signed by a different key' };
  const key = createPublicKey({ key: Buffer.concat([SPKI, Buffer.from(s.public_key, 'hex')]), format: 'der', type: 'spki' });
  const ok = verify(null, payload(record), key, Buffer.from(s.value, 'hex'));
  return ok ? { valid: true, key_id: s.key_id } : { valid: false, reason: 'the signature does not match the record' };
}
