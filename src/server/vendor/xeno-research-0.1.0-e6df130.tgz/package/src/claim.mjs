// Results as checked claims in XENO Corpus. A claim says "cell N of this notebook produces this
// output"; its assay re-runs the notebook in Box and prints that cell's output hash, and Corpus
// compares it with the recorded one. So a figure in a paper is `held` (it still reproduces),
// `lapsed` (it reproduces to something else) or `unobserved` (the check could not run) — the
// living-figure badge reads exactly that.
//
// Integration is through Corpus's supported CLI (`corpus tenet new --json`), never by writing its
// files: Corpus runs the assay before it saves, and refuses a claim whose check does not pass.

import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

export function corpusCli() {
  const cli = process.env.XENO_CORPUS_CLI ?? resolve(here, '../../xeno-corpus/dist/corpus.mjs');
  if (!existsSync(cli)) throw new Error(`XENO Corpus CLI not found at ${cli} — set XENO_CORPUS_CLI`);
  return cli;
}

/** The project root that owns the corpus: the nearest folder with `.xeno/corpus`, like git. */
export function corpusRoot(fromDir) {
  for (let d = resolve(fromDir); ; d = dirname(d)) {
    if (existsSync(join(d, '.xeno', 'corpus'))) return d;
    if (dirname(d) === d) throw new Error('no XENO Corpus here — run `xeno-research claim --init` in the project root, or `corpus init`');
  }
}

const slug = (s) => s.toLowerCase().replace(/\.ipynb$/, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export function claimId(notebookRel, cell) {
  return `research#${slug(notebookRel)}-cell-${cell}`;
}

function corpus(root, args) {
  const out = execFileSync(process.execPath, [corpusCli(), ...args, '--json'], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], env: process.env });
  return JSON.parse(out);
}

/**
 * Registers a recorded cell result as a claim. The assay command is `xeno-research check …` — the
 * installed CLI, not a path on this machine — so the corpus works on any machine that has
 * xeno-research and Box access.
 */
export function registerClaim({ notebookPath, provenance, cell, claim, owner = 'research', expire = '30d' }) {
  const record = provenance.cells.find((c) => c.index === cell);
  if (!record) throw new Error(`cell ${cell} is not a code cell of this notebook`);
  if (record.status !== 'ok') throw new Error(`cell ${cell} did not complete in the recorded run (${record.status}); only a completed result can be claimed`);
  const root = corpusRoot(dirname(notebookPath));
  const rel = relative(root, notebookPath).replace(/\\/g, '/');
  const id = claimId(rel, cell);
  const result = corpus(root, ['tenet', 'new',
    '--id', id,
    '--subject', rel,
    '--owner', owner,
    '--claim', claim ?? `Cell ${cell} of ${rel} reproduces its recorded output in XENO Box`,
    '--run', `xeno-research check "${rel}" --cell ${cell}`,
    '--expect', record.output_sha256,
    '--expire', expire]);
  // Registering is not observing: record the first verdict now, through Corpus's own pulse.
  const pulsed = pulseClaim({ root, id });
  return { id, root, result, state: pulsed.state };
}

/** Re-checks one claim now (Corpus runs the assay and appends the verdict). */
export function pulseClaim({ root, id }) {
  let out;
  try {
    out = execFileSync(process.execPath, [corpusCli(), 'pulse', '--tenet', id, '--json'], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], env: process.env });
  } catch (error) {
    // pulse exits 1 on a new lapse and 5 on unobserved; its JSON is still the answer.
    out = error.stdout;
    if (!out) throw error;
  }
  const verdict = JSON.parse(out).verdicts?.find((v) => v.tenet === id);
  return { state: verdict?.state ?? 'unobserved', observed: verdict?.observed ?? null, why: verdict?.why ?? verdict?.reason ?? null };
}

/**
 * The living-figure state of each claimed cell, from Corpus's latest verdict. The notebook lists
 * its claims in `metadata.xeno.claims` ({cell: id}); a claim with no verdict yet is `unobserved` —
 * never shown as passing.
 */
export function claimStatus({ notebookPath, notebook }) {
  const root = corpusRoot(dirname(notebookPath));
  return Object.entries(notebook.metadata?.xeno?.claims ?? {}).map(([cell, id]) => {
    const t = corpus(root, ['tenet', 'show', id]);
    const latest = t.latest ?? null;
    return { cell: Number(cell), id, state: latest?.state ?? 'unobserved', at: latest?.at ?? null, why: latest?.why ?? latest?.reason ?? null };
  });
}
