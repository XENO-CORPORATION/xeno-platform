# XENO Research

The XENO division for scientists — physics, space, biology, chemistry, and academic research generally.
Its first product is the **reproducible research notebook**: a Jupyter-compatible notebook where every
cell runs in a XENO Box sandbox, every result is recorded as a checked claim in XENO Corpus, and the
paper is produced from those claims. The pitch: **every figure in your paper can prove itself.**

- **Status (2026-10-19):** decisions D1–D5 made. Notebook core runs through a real Jupyter kernel; 16 tests green;
  **proven end to end against the live Box API** (`npm run smoke:box` 5/5, SPEC §7a).
- **Audience research:** [`AUDIENCE.md`](AUDIENCE.md).

```sh
export XENO_BOX_URL=... XENO_BOX_TOKEN=...      # never as flags
node bin/xeno-research.mjs run    examples/reproducible.ipynb   # outputs + .provenance.json
node bin/xeno-research.mjs verify examples/reproducible.ipynb   # reproduced | changed | not-reproduced
npm test                                                     # engine tests (no Box needed)
npm run smoke:box                                            # live proof against a real Box
```
- **Spec:** [`SPEC.md`](SPEC.md) — who it is for, the benchmark, what we reuse, the first build, open decisions.
- **Agent contract:** [`agents.md`](agents.md).
- **Catalog row:** `../XENO PRODUCTS - CATALOG.md`.

## Why this exists

On 2026-10-19 a sweep of the product catalog and every root spec found no product for scientists: no
notebook, no lab record, no paper workflow, no cluster-compute surface. Yet the ecosystem already owns
the hardest parts — reproducible execution (`xeno-box`), claims bound to the procedure that checks them
(`xeno-corpus`), pipelines (`xeno-workflow`), local and offline inference (`xeno-rt`), documents
(`xeno-docs`), and agents. This repo is where those become a product a researcher would choose.

## Where things will live

| Part | Where |
|---|---|
| Product decisions, spec, agent contract | this repo |
| Sandboxed execution of notebook cells | `xeno-box` (consumed, never re-implemented) |
| Claims, checks and signed results | `xeno-corpus` (consumed) |
| Pipelines | `xeno-workflow` |
| Inference (local, offline-capable) | `xeno-rt` |
| Writing / LaTeX | `xeno-docs` |
| Plots and dashboards | `xeno-spectra` |
