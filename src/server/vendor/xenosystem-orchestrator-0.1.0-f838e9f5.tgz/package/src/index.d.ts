export interface Step { id:string; taskId:string; principalId:string; role:string; dependsOn:string[]; maxAttempts:number;projectIds?:string[];requiredCapabilities?:string[] }
export interface Plan { version:1; id:string; revision:number; projectId:string; steps:Step[] }
export interface Binding { planId:string; planRevision:number; projectId:string; stepId:string; taskId:string; principalId:string; attempt:number }
export interface Receipt { kind:'claim'|'context'|'admission'; id:string; binding:Binding; allowed:boolean; expiresAt:number }
export interface JournalEvent { version:1; sequence:number; planDigest:string; step:string; status:string; attempt:number; request:string|null; at:number; result?:string; runId?:string }
export interface Ports {
 ecosystem?:ReturnType<typeof createEcosystemResolver>;
 plan:Plan; planner:{plan(definition:{schemaVersion:1;id:string;name:string;nodes:Array<{id:string;dependsOn:string[]}>}):unknown};
 journal:{read(planId:string):JournalEvent[];append(planId:string,expectedRevision:number,event:JournalEvent):Promise<void>};
 tasks:{claim(binding:Binding):Promise<Receipt>}; context:{prepare(binding:Binding):Promise<Receipt>}; admission:{authorize(binding:Binding):Promise<Receipt>};
 execution:{dispatch(input:{request:string;binding:Binding;context:Receipt;admission:Receipt;claim:Receipt}):Promise<{request:string;runId:string}>;lookup(request:string):Promise<{request:string;status:'running'|'produced'|'failed'|'cancelled'|'unknown';resultDigest?:string}>;cancel(request:string):Promise<unknown>};
 acceptance:{verify(input:Binding & {request:string;resultDigest:string}):Promise<{binding:Binding;request:string;resultDigest:string;reviewerId:string;accepted:boolean;expiresAt:number}>};clock?:()=>number;
}
export interface Orchestrator { snapshot():{planId:string;revision:number;complete:boolean;nodes:Record<string,{status:string;attempt:number;request:string|null;result:string|null}>};tick():Promise<Array<{step:string;state:string;request?:string}>>;reconcile(step:string):Promise<{state:string}>;accept(step:string):Promise<{state:string}>;cancel(step:string):Promise<{state:string}> }
export function validatePlan(plan:Plan,planner:Ports['planner']):Plan;
export function createOrchestrator(ports:Ports):Orchestrator;
export interface DiscoveryRecord {projectId:string;revision:string;observedAt:number;expiresAt:number;dependencies?:string[];complete:boolean}
export interface PlatformCoordinationView extends Omit<DiscoveryRecord,'dependencies'> {complete:boolean;dependencies:Array<{projectId:string;kind:'build'|'runtime'|'contract';revision:string}>;nextCursor?:string|null}
export function createPlatformCatalog(options:{readProject(scope:{principalId:string;projectId:string}):Promise<PlatformCoordinationView|null>;clock?:()=>number;maxAgeMs?:number}):EcosystemPorts['catalog'];
export function createCorpusContextPort(options:{resolveHost(binding:Binding):Promise<{projectId:string;taskId:string;principalId:string;expiresAt:number;host:{completion():unknown}}>;clock?:()=>number;maxAgeMs?:number}):Ports['context'];
export interface RunAuthorityPort {admissionId?:string;authorizeDispatch(request:unknown,signal?:AbortSignal):Promise<unknown>;authorizeToolCall(request:unknown,signal?:AbortSignal):Promise<unknown>}
export function createOrchestratorRunAuthority(options:{ecosystem:ReturnType<typeof createEcosystemResolver>;principalId:string;projectIds:string[];requiredCapabilities:string[];authority:RunAuthorityPort}):RunAuthorityPort;
export interface EcosystemPorts {
 catalog:{list(scope:{principalId:string;projectIds:string[]}):Promise<DiscoveryRecord[]>};
 capabilities:{describe(scope:{principalId:string;projectId:string;revision:string}):Promise<DiscoveryRecord & {capabilities:string[]}>};
 ownership:{describe(scope:{principalId:string;projectId:string;revision:string}):Promise<DiscoveryRecord & {principalId:string}>};
 authorizeRead(scope:{principalId:string;projectId:string}):Promise<boolean>;clock?:()=>number;
}
export function createEcosystemResolver(ports:EcosystemPorts):{resolve(scope:{principalId:string;projectIds:string[];requiredCapabilities?:string[]}):Promise<{version:1;principalId:string;projects:Array<{projectId:string;revision:string;ownerPrincipalId:string;capabilities:string[];dependencies:string[];dependenciesOutsideScope:boolean;satisfies:boolean;expiresAt:number;assurance:string}>;denied:string[];unknown:Array<{projectId:string;reason:string}>;complete:boolean;executionAuthorized:false}>};
export function dependenciesSatisfied(dependsOn:string[],isSatisfied:(id:string)=>boolean):boolean;
export function attemptDecision(input:{open:boolean;live?:boolean;attempts:number;maxAttempts:number;dependenciesSatisfied:boolean}):{allowed:true;attempt:number}|{allowed:false;reason:'closed'|'blocked'|'live'|'exhausted'};
export function planGraph(input:{nodes:Array<{id:string;done:boolean}>;edges?:Array<{from:string;to:string}>;planner:Ports['planner']}):{waves:string[][];order:string[];nodes:Record<string,{done:boolean;ready:boolean;blockedBy:string[]}>;ready:string[]};
export function wouldCycle(input:{edges?:Array<{from:string;to:string}>;from:string;to:string;planner:Ports['planner']}):boolean;
