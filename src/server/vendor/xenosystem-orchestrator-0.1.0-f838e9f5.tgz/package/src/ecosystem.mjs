/** Scoped discovery over authoritative owner ports. Catalogue knowledge never grants execution. */
const identifier = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,255}$/.test(value);
function strings(values, label) {
  if (!Array.isArray(values) || values.length > 1000 || values.some(v => !identifier(v)) || new Set(values).size !== values.length)
    throw Error(`ECOSYSTEM_INVALID_${label}`);
  return [...values];
}
export function createEcosystemResolver({catalog, capabilities, ownership, authorizeRead, clock=Date.now}) {
  if (typeof catalog?.list !== 'function' || typeof capabilities?.describe !== 'function' ||
      typeof ownership?.describe !== 'function' || typeof authorizeRead !== 'function') throw Error('ECOSYSTEM_PORTS_REQUIRED');
  return {
    async resolve({principalId, projectIds, requiredCapabilities=[]}) {
      if (!identifier(principalId)) throw Error('ECOSYSTEM_PRINCIPAL_REQUIRED');
      const requested=strings(projectIds,'PROJECTS'),required=strings(requiredCapabilities,'CAPABILITIES');
      if (!requested.length) throw Error('ECOSYSTEM_EXPLICIT_SCOPE_REQUIRED');
      // Read grants are checked BEFORE contacting owners or constructing a searchable view.
      const permitted=[]; const denied=[];
      for (const projectId of requested) {
        if (await authorizeRead({principalId,projectId}) === true) permitted.push(projectId);
        else denied.push(projectId);
      }
      const records=permitted.length ? await catalog.list({principalId,projectIds:permitted}) : [];
      if (!Array.isArray(records) || records.length>1000) throw Error('ECOSYSTEM_CATALOG_INVALID');
      const seen=new Set(),projects=[],unknown=[];
      for (const record of records) {
        if (!record || !permitted.includes(record.projectId) || seen.has(record.projectId)) throw Error('ECOSYSTEM_CATALOG_SCOPE_VIOLATION');
        seen.add(record.projectId);
        if (!identifier(record.revision) || !Number.isFinite(record.observedAt) || record.observedAt>clock() ||
            !Number.isFinite(record.expiresAt) || record.expiresAt<=clock()) {unknown.push({projectId:record.projectId,reason:'catalog-stale-or-unverified'});continue;}
        if(record.complete!==true){unknown.push({projectId:record.projectId,reason:'catalog-scope-incomplete'});continue;}
        const dependencies=strings(record.dependencies??[],'DEPENDENCIES');
        const [cap,owner]=await Promise.all([
          capabilities.describe({principalId,projectId:record.projectId,revision:record.revision}),
          ownership.describe({principalId,projectId:record.projectId,revision:record.revision}),
        ]);
        const current=value=>value?.projectId===record.projectId && value.revision===record.revision &&
          Number.isFinite(value.observedAt) && value.observedAt<=clock() && Number.isFinite(value.expiresAt) && value.expiresAt>clock();
        if (!current(cap)||!current(owner)||!identifier(owner.principalId)) {unknown.push({projectId:record.projectId,reason:'owner-or-capability-unverified'});continue;}
        const available=strings(cap.capabilities,'CAPABILITIES');
        // Permission may have been revoked while owner requests were in flight.
        if (await authorizeRead({principalId,projectId:record.projectId}) !== true) {denied.push(record.projectId);continue;}
        projects.push({projectId:record.projectId,revision:record.revision,ownerPrincipalId:owner.principalId,
          capabilities:available,dependencies:dependencies.filter(d=>permitted.includes(d)),
          dependenciesOutsideScope:dependencies.some(d=>!permitted.includes(d)),
          satisfies:required.every(c=>available.includes(c)),
          expiresAt:Math.min(record.expiresAt,cap.expiresAt,owner.expiresAt),
          assurance:'discovery-only; separate admission required'});
      }
      for (const projectId of permitted) if(!seen.has(projectId)) unknown.push({projectId,reason:'not-in-catalog-response'});
      // Recheck the entire visible scope after asynchronous discovery, including dependency names.
      const stillPermitted=new Set();
      for(const projectId of permitted)if(await authorizeRead({principalId,projectId})===true)stillPermitted.add(projectId);
      const visible=projects.filter(p=>stillPermitted.has(p.projectId)&&p.expiresAt>clock());
      for(const p of projects)if(!stillPermitted.has(p.projectId))denied.push(p.projectId);
      else if(p.expiresAt<=clock())unknown.push({projectId:p.projectId,reason:'expired-during-discovery'});
      for(const p of visible){p.dependenciesOutsideScope ||= p.dependencies.some(d=>!stillPermitted.has(d));p.dependencies=p.dependencies.filter(d=>stillPermitted.has(d));}
      return {version:1,principalId,projects:visible,denied:[...new Set(denied)],unknown,
        complete:denied.length===0&&unknown.length===0,executionAuthorized:false};
    },
  };
}
