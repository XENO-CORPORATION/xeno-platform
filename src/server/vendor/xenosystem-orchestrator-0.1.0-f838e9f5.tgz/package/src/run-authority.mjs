/** Compose discovery with the existing SDK RunAuthority; discovery never replaces admission. */
export function createOrchestratorRunAuthority({ecosystem,principalId,projectIds,requiredCapabilities,authority}) {
  if(typeof ecosystem?.resolve!=='function'||typeof authority?.authorizeDispatch!=='function'||typeof authority?.authorizeToolCall!=='function')throw Error('RUN_AUTHORITY_PORTS_REQUIRED');
  if(typeof principalId!=='string'||!principalId||!Array.isArray(projectIds)||!projectIds.length||new Set(projectIds).size!==projectIds.length||!Array.isArray(requiredCapabilities))throw Error('RUN_AUTHORITY_SCOPE_REQUIRED');
  const scope=structuredClone({principalId,projectIds,requiredCapabilities});
  async function check(signal){
    signal?.throwIfAborted();
    const result=await ecosystem.resolve(scope);
    signal?.throwIfAborted();
    if(result.principalId!==scope.principalId||!result.complete||!Array.isArray(result.projects)||
      result.projects.length!==scope.projectIds.length||result.projects.some(p=>!scope.projectIds.includes(p.projectId)||!p.satisfies))throw Error('ORCHESTRATOR_DISCOVERY_REFUSED');
  }
  return {
    ...(authority.admissionId?{admissionId:authority.admissionId}:{}),
    async authorizeDispatch(request,signal){await check(signal);return authority.authorizeDispatch(request,signal);},
    async authorizeToolCall(request,signal){await check(signal);return authority.authorizeToolCall(request,signal);},
  };
}
