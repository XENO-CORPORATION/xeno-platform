/** Read adapter for the proposed Platform-owned coordination view. No endpoint/authority invented here. */
export function createPlatformCatalog({readProject,clock=Date.now,maxAgeMs=30000}) {
  if(typeof readProject!=='function'||!Number.isInteger(maxAgeMs)||maxAgeMs<1||maxAgeMs>60000)throw Error('PLATFORM_CATALOG_CONFIG_INVALID');
  return {
    async list({principalId,projectIds}){
      const rows=[];
      for(const projectId of projectIds){
        const value=await readProject({principalId,projectId});
        if(value===null)continue; // absent and inaccessible are indistinguishable at this boundary
        if(!value||value.projectId!==projectId||typeof value.revision!=='string'||!value.revision||
          typeof value.complete!=='boolean'||!Number.isFinite(value.observedAt)||value.observedAt>clock()||
          !Number.isFinite(value.expiresAt)||value.expiresAt<=clock()||!Array.isArray(value.dependencies))throw Error('PLATFORM_COORDINATION_VIEW_INVALID');
        if(value.nextCursor)throw Error('PLATFORM_COORDINATION_PAGING_REQUIRED');
        if(value.dependencies.some(e=>!e||!['build','runtime','contract'].includes(e.kind)||typeof e.projectId!=='string'||typeof e.revision!=='string'))throw Error('PLATFORM_DEPENDENCY_INVALID');
        rows.push({projectId,revision:value.revision,complete:value.complete,observedAt:value.observedAt,
          expiresAt:Math.min(value.expiresAt,value.observedAt+maxAgeMs),
          dependencies:[...new Set(value.dependencies.map(e=>e.projectId))]});
      }
      return rows;
    },
  };
}
