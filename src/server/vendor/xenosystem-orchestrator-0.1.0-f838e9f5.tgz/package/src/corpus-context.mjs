/** Corpus adapter: the host resolves task/principal-scoped bindings, never the model. */
import {createHash} from 'node:crypto';
export function createCorpusContextPort({resolveHost,clock=Date.now,maxAgeMs=30000}){
 if(typeof resolveHost!=='function'||!Number.isInteger(maxAgeMs)||maxAgeMs<1||maxAgeMs>60000)throw Error('CORPUS_CONTEXT_CONFIG_INVALID');
 return {async prepare(binding){
   const resolved=await resolveHost(structuredClone(binding));
   if(!resolved||resolved.projectId!==binding.projectId||resolved.taskId!==binding.taskId||resolved.principalId!==binding.principalId||typeof resolved.host?.completion!=='function')throw Error('CORPUS_CONTEXT_BINDING_REFUSED');
   const decision=await resolved.host.completion();
   const envelope=decision?.envelope;
   if(decision?.ship!==true||decision.advisory!==false||envelope?.status!=='ready'||envelope.completion?.satisfied!==true||typeof envelope.digest!=='string')throw Error('CORPUS_CONTEXT_UNVERIFIED');
   if(envelope.correlation?.projectId!==binding.projectId||envelope.correlation?.taskId!==binding.taskId)throw Error('CORPUS_CONTEXT_CORRELATION_MISMATCH');
   const observedAt=Date.parse(envelope.generatedAt);
   if(!Number.isFinite(observedAt)||observedAt>clock()||observedAt+maxAgeMs<=clock())throw Error('CORPUS_CONTEXT_STALE');
   const expiresAt=Math.min(observedAt+maxAgeMs,resolved.expiresAt??0);
   if(!Number.isFinite(expiresAt)||expiresAt<=clock())throw Error('CORPUS_CONTEXT_SCOPE_EXPIRED');
   // Envelope remains private in the owner's store; the coordination receipt carries only its digest.
   return {kind:'context',id:'context-'+createHash('sha256').update(envelope.digest).digest('hex'),binding:structuredClone(binding),allowed:true,expiresAt};
 }};
}
