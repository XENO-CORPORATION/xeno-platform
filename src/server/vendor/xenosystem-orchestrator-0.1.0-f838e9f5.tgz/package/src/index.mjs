/** Coordination kernel. All effects belong to injected host ports. */
import { createHash } from 'node:crypto';
export { createEcosystemResolver } from './ecosystem.mjs';
export { createPlatformCatalog } from './platform-catalog.mjs';
export { createOrchestratorRunAuthority } from './run-authority.mjs';
export { createCorpusContextPort } from './corpus-context.mjs';
const canonical = value => Array.isArray(value) ? value.map(canonical) : value && typeof value === 'object'
  ? Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])])) : value;
const hash = value => createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
const id = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}$/.test(value);
const states = new Set(['pending','intent','running','produced','accepted','rejected','failed','cancel-requested','cancelled']);
/**
 * ONE readiness rule, shared by the kernel's tick() and by hosts that read readiness from their own records (the
 * platform's Tasks/goals/objectives). Topology — cycle refusal and order — always comes from the injected planner
 * (the SDK WorkflowPlanner); nothing here is a second DAG runtime.
 */
export function dependenciesSatisfied(dependsOn, isSatisfied) {
  if (!Array.isArray(dependsOn) || typeof isSatisfied !== 'function') throw Error('DEPENDENCIES_INVALID');
  return dependsOn.every(d => isSatisfied(d) === true);
}
/** May a step take its next attempt? open = not terminal; live = an attempt still running. */
export function attemptDecision({ open, live = false, attempts, maxAttempts, dependenciesSatisfied: satisfied }) {
  if (!Number.isInteger(attempts) || attempts < 0 || !Number.isInteger(maxAttempts) || maxAttempts < 1) throw Error('ATTEMPTS_INVALID');
  if (open !== true) return { allowed: false, reason: 'closed' };
  if (satisfied !== true) return { allowed: false, reason: 'blocked' };
  if (live) return { allowed: false, reason: 'live' };
  if (attempts >= maxAttempts) return { allowed: false, reason: 'exhausted' };
  return { allowed: true, attempt: attempts + 1 };
}
const requirePlanner = planner => { if (!planner || typeof planner.plan !== 'function') throw Error('PLANNER_REQUIRED'); return planner; };
function topology(byId, planner) {
  try {
    return requirePlanner(planner).plan({ schemaVersion: 1, id: 'graph', name: 'graph', nodes: [...byId.values()].map(n => ({ id: n.id, dependsOn: n.dependsOn })) }).waves;
  } catch (e) { if (/cycle|depend on itself/i.test(String(e && e.message))) throw Error('GRAPH_CYCLE'); throw e; }
}
/**
 * Readiness of a dependency graph. nodes: [{ id, done }]; edges: [{ from, to }] — `from` must be done before `to`.
 * Returns waves/order from the planner, per node { done, ready, blockedBy }, and the ready set in dependency order.
 */
export function planGraph({ nodes, edges = [], planner }) {
  requirePlanner(planner);
  if (!Array.isArray(nodes) || !Array.isArray(edges)) throw Error('GRAPH_INVALID');
  const byId = new Map();
  for (const n of nodes) {
    if (!n || typeof n.id !== 'string' || !n.id) throw Error('GRAPH_NODE_INVALID');
    if (byId.has(n.id)) throw Error('GRAPH_NODE_DUPLICATE');
    byId.set(n.id, { id: n.id, done: n.done === true, dependsOn: [] });
  }
  for (const e of edges) {
    const from = byId.get(e && e.from), to = byId.get(e && e.to);
    if (!from || !to) throw Error('GRAPH_EDGE_UNKNOWN');
    if (!to.dependsOn.includes(from.id)) to.dependsOn.push(from.id);
  }
  const waves = topology(byId, planner), order = waves.flat(), out = {};
  for (const n of byId.values()) {
    const blockedBy = n.dependsOn.filter(d => !byId.get(d).done);
    out[n.id] = { done: n.done, blockedBy, ready: !n.done && dependenciesSatisfied(n.dependsOn, d => byId.get(d).done) };
  }
  return { waves, order, nodes: out, ready: order.filter(id => out[id].ready) };
}
/** Would adding from→to close a loop over these edges? The planner decides. */
export function wouldCycle({ edges = [], from, to, planner }) {
  requirePlanner(planner);
  if (typeof from !== 'string' || !from || typeof to !== 'string' || !to) throw Error('GRAPH_EDGE_INVALID');
  if (from === to) return true;
  const byId = new Map(), at = id => byId.get(id) || (byId.set(id, { id, dependsOn: [] }), byId.get(id));
  for (const e of [...edges, { from, to }]) { const t = at(e.to); at(e.from); if (!t.dependsOn.includes(e.from)) t.dependsOn.push(e.from); }
  try { topology(byId, planner); return false; } catch (e) { if (e.message === 'GRAPH_CYCLE') return true; throw e; }
}
export function validatePlan(input, planner) {
  if (!input || input.version !== 1 || !id(input.id) || !id(input.projectId) || !Number.isSafeInteger(input.revision) || input.revision < 1 || !Array.isArray(input.steps) || !input.steps.length || input.steps.length > 1000) throw Error('PLAN_INVALID');
  for (const s of input.steps) if (!s || !id(s.id) || !id(s.taskId) || !id(s.principalId) || typeof s.role !== 'string' || !s.role.trim() || !Number.isInteger(s.maxAttempts) || s.maxAttempts < 1 || s.maxAttempts > 10 || !Array.isArray(s.dependsOn)) throw Error('PLAN_STEP_INVALID');
  for(const s of input.steps) for(const key of ['projectIds','requiredCapabilities'])
    if(s[key]!==undefined&&(!Array.isArray(s[key])||s[key].length>1000||s[key].some(v=>!id(v))||new Set(s[key]).size!==s[key].length))throw Error('PLAN_SCOPE_INVALID');
  if (!planner || typeof planner.plan !== 'function') throw Error('PLANNER_REQUIRED');
  planner.plan({schemaVersion:1,id:input.id,name:input.id,nodes:input.steps.map(s=>({id:s.id,dependsOn:s.dependsOn}))});
  return structuredClone(input);
}
export function createOrchestrator({plan:input,planner,journal,tasks,context,admission,execution,acceptance,ecosystem=null,clock=Date.now}) {
  const plan=validatePlan(input,planner),planDigest=hash(plan);
  for (const [name,port,methods] of [['journal',journal,['read','append']],['tasks',tasks,['claim']],['context',context,['prepare']],['admission',admission,['authorize']],['execution',execution,['dispatch','lookup','cancel']],['acceptance',acceptance,['verify']]])
    if (!port || methods.some(m=>typeof port[m]!=='function')) throw Error(`PORT_REQUIRED:${name}`);
  let revision=0;
  const nodes=new Map(plan.steps.map(s=>[s.id,{status:'pending',attempt:0,request:null,result:null}]));
  function apply(e) {
    if(e.planDigest!==planDigest||e.sequence!==revision||!nodes.has(e.step)||!states.has(e.status))throw Error('JOURNAL_INVALID');
    const n=nodes.get(e.step);
    const allowed={pending:['intent','cancelled'],intent:['running','produced','failed','cancel-requested'],running:['produced','failed','cancel-requested'],produced:['accepted','rejected','cancel-requested'],failed:['intent','cancelled'],rejected:[],accepted:[], 'cancel-requested':['cancelled'],cancelled:[]};
    if(!allowed[n.status].includes(e.status))throw Error('TRANSITION_INVALID');
    const step=plan.steps.find(s=>s.id===e.step);
    if(e.version!==1||!Number.isFinite(e.at)||!Number.isInteger(e.attempt)||e.attempt<0||e.attempt>step.maxAttempts)throw Error('JOURNAL_INVALID');
    if(e.status==='intent'){
      if(e.attempt!==n.attempt+1||!step.dependsOn.every(d=>nodes.get(d)?.status==='accepted'))throw Error('INTENT_INVALID');
      const expected='dispatch-'+hash({planDigest,planId:plan.id,planRevision:plan.revision,projectId:plan.projectId,stepId:step.id,taskId:step.taskId,principalId:step.principalId,attempt:e.attempt});
      if(e.request!==expected)throw Error('REQUEST_ID_INVALID');
    }else if(e.attempt!==n.attempt||e.request!==n.request)throw Error('ATTEMPT_MISMATCH');
    Object.assign(n,{status:e.status,attempt:e.attempt,request:e.request,result:e.result??n.result});revision++;
  }
  for(const event of journal.read(plan.id))apply(event);
  async function record(step,status,fields={}) {
    const n=nodes.get(step),event={version:1,sequence:revision,planDigest,step,status,attempt:n.attempt,request:n.request,at:clock(),...fields};
    await journal.append(plan.id,revision,event);apply(event);
  }
  const binding=(s,n,attempt=n.attempt)=>({planId:plan.id,planRevision:plan.revision,projectId:plan.projectId,stepId:s.id,taskId:s.taskId,principalId:s.principalId,attempt});
  function receipt(value,b,kind){if(!value||value.kind!==kind||value.allowed!==true||!id(value.id)||!Number.isFinite(value.expiresAt)||value.expiresAt<=clock()||hash(value.binding)!==hash(b))throw Error(`${kind.toUpperCase()}_REFUSED`);return value;}
  let busy=false;
  async function serialized(fn){if(busy)throw Error('COORDINATOR_BUSY');busy=true;try{return await fn();}finally{busy=false;}}
  return {
    snapshot(){return {planId:plan.id,revision,complete:[...nodes.values()].every(n=>n.status==='accepted'),nodes:Object.fromEntries([...nodes].map(([k,v])=>[k,structuredClone(v)]))};},
    async tick(){return serialized(async()=>{
      const outcomes=[];
      for(const s of plan.steps){const n=nodes.get(s.id);
        const decision=attemptDecision({open:['pending','failed'].includes(n.status),attempts:n.attempt,maxAttempts:s.maxAttempts,dependenciesSatisfied:dependenciesSatisfied(s.dependsOn,d=>nodes.get(d)?.status==='accepted')});
        if(!decision.allowed)continue;
        const attempt=decision.attempt,b=binding(s,n,attempt);
        let claimed,ctx,grant,discoveryExpiry=Infinity;
        if(s.projectIds?.length){
          if(!ecosystem) {outcomes.push({step:s.id,state:'discovery-unavailable'});continue;}
          try{const discovered=await ecosystem.resolve({principalId:s.principalId,projectIds:s.projectIds,requiredCapabilities:s.requiredCapabilities??[]});
            if(!discovered.complete||!discovered.projects.length||discovered.projects.some(p=>!p.satisfies)){outcomes.push({step:s.id,state:'discovery-incomplete'});continue;}
            discoveryExpiry=Math.min(...discovered.projects.map(p=>p.expiresAt));
          }catch{outcomes.push({step:s.id,state:'discovery-unavailable'});continue;}
        }
        try{claimed=receipt(await tasks.claim(b),b,'claim');ctx=receipt(await context.prepare(b),b,'context');grant=receipt(await admission.authorize(b),b,'admission');receipt(claimed,b,'claim');receipt(ctx,b,'context');receipt(grant,b,'admission');}
        catch{outcomes.push({step:s.id,state:'blocked'});continue;}
        if(discoveryExpiry<=clock()){outcomes.push({step:s.id,state:'discovery-expired'});continue;}
        const request='dispatch-'+hash({planDigest,...b});
        await record(s.id,'intent',{attempt,request});
        try{
          if(discoveryExpiry<=clock())throw Error('DISCOVERY_EXPIRED');
          receipt(claimed,b,'claim');receipt(ctx,b,'context');receipt(grant,b,'admission');
          const run=await execution.dispatch({request,binding:b,context:ctx,admission:grant,claim:claimed});
          if(!run||!id(run.runId)||run.request!==request)throw Error('DISPATCH_REPLY_INVALID');
          await record(s.id,'running',{runId:run.runId});outcomes.push({step:s.id,state:'running',request});
        }catch{outcomes.push({step:s.id,state:'reconcile-required',request});}
      }return outcomes;
    });},
    async reconcile(step){return serialized(async()=>{
      const s=plan.steps.find(s=>s.id===step),n=nodes.get(step);if(!s||!['intent','running','cancel-requested'].includes(n.status))throw Error('RECONCILE_STATE_INVALID');
      const r=await execution.lookup(n.request);
      if(!r||r.request!==n.request||!['running','produced','failed','cancelled','unknown'].includes(r.status))throw Error('RUNTIME_REPLY_INVALID');
      if(r.status==='unknown')return {state:'reconcile-required'};
      if(n.status==='cancel-requested'){if(r.status==='cancelled')await record(step,'cancelled');return {state:n.status};}
      if(r.status==='running'&&n.status==='intent')await record(step,'running');
      if(r.status==='failed')await record(step,'failed');
      if(r.status==='produced'){if(typeof r.resultDigest!=='string'||!/^sha256:[a-f0-9]{64}$/.test(r.resultDigest))throw Error('RESULT_DIGEST_INVALID');await record(step,'produced',{result:r.resultDigest});}
      return {state:n.status};
    });},
    async accept(step){return serialized(async()=>{
      const s=plan.steps.find(s=>s.id===step),n=nodes.get(step);if(!s||n.status!=='produced')throw Error('ACCEPT_STATE_INVALID');
      const b=binding(s,n),r=await acceptance.verify({...b,request:n.request,resultDigest:n.result});
      if(!r||hash(r.binding)!==hash(b)||r.request!==n.request||r.resultDigest!==n.result||!id(r.reviewerId)||r.reviewerId===s.principalId||!Number.isFinite(r.expiresAt)||r.expiresAt<=clock()||typeof r.accepted!=='boolean')throw Error('ACCEPTANCE_INVALID');
      await record(step,r.accepted?'accepted':'rejected');return {state:n.status};
    });},
    async cancel(step){return serialized(async()=>{
      const n=nodes.get(step);if(!n)throw Error('STEP_UNKNOWN');
      if(['cancelled','accepted','rejected'].includes(n.status))return {state:n.status};
      if(['pending','failed'].includes(n.status)){await record(step,'cancelled');return {state:n.status};}
      if(n.status!=='cancel-requested')await record(step,'cancel-requested');
      await execution.cancel(n.request);return {state:n.status};
    });},
  };
}
