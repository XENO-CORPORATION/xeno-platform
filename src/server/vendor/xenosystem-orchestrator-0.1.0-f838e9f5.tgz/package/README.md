# XENO Orchestrator

The agentic coordination engine: plan work, obtain scoped Corpus context and admission, dispatch through existing runtimes, recover uncertain outcomes and require independent acceptance.

**Not another agent loop, task database, identity provider or memory store.** Read [SPEC.md](SPEC.md) for ownership, [INTEGRATION.md](INTEGRATION.md) for ports, and [PLAN.md](PLAN.md) for verified status.

```sh
npm test
npm run dogfood
```

The tests use the existing sibling SDK's built WorkflowPlanner, with explicitly labelled in-memory host adapters. Dogfood also uses the real local Corpus engine. No production service or model is contacted. These are local foundation proofs, not an installed CLI Orchestrator mode.

This folder is a separate local Git repository. No remote or published package is configured. Open a new agent session here and read CLAUDE.md + agents.md before continuing.
