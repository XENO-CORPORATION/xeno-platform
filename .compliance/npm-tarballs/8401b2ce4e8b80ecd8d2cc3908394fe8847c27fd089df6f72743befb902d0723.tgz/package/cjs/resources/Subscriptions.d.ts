import { StripeResource } from '../StripeResource.js';
import { DeletedDiscount, Discount } from './Discounts.js';
import { Application, DeletedApplication } from './Applications.js';
import { Customer, DeletedCustomer } from './Customers.js';
import { PaymentMethod } from './PaymentMethods.js';
import { CustomerSource } from './CustomerSources.js';
import { TaxRate } from './TaxRates.js';
import { SubscriptionItem } from './SubscriptionItems.js';
import { Invoice } from './Invoices.js';
import { Account } from './Accounts.js';
import { SetupIntent } from './SetupIntents.js';
import { SubscriptionSchedule } from './SubscriptionSchedules.js';
import { Price } from './Prices.js';
import { TaxId, DeletedTaxId } from './TaxIds.js';
import * as TestHelpers from './TestHelpers/index.js';
import * as Billing from './Billing/index.js';
import { Emptyable, MetadataParam, OtherString, Decimal, PaginationParams, RangeQueryParam, Metadata } from '../shared.js';
import { RequestOptions, Response, ApiListPromise, ApiList, ApiSearchResultPromise } from '../lib.js';
export declare class SubscriptionResource extends StripeResource {
    /**
     * Cancels a customer's subscription immediately. The customer won't be charged again for the subscription. After it's canceled, the subscription is largely immutable. You can still update its [metadata](https://docs.stripe.com/metadata) and cancellation_details.
     *
     * Any pending invoice items that you've created are still charged at the end of the period, unless manually [deleted](https://docs.stripe.com/api/invoiceitems/delete). If you've set the subscription to cancel at the end of the period, any pending prorations are also left in place and collected at the end of the period. But if the subscription is set to cancel immediately, pending prorations are removed if invoice_now and prorate are both set to false.
     *
     * By default, upon subscription cancellation, Stripe stops automatic collection of all finalized invoices for the customer. This is intended to prevent unexpected payment attempts after the customer has canceled a subscription. However, you can resume automatic collection of the invoices manually after subscription cancellation to have us proceed. Or, you could check for unpaid invoices before allowing the customer to cancel the subscription at all.
     */
    cancel(id: string, params?: SubscriptionCancelParams, options?: RequestOptions): Promise<Response<Subscription>>;
    /**
     * Retrieves the subscription with the given ID.
     */
    retrieve(id: string, params?: SubscriptionRetrieveParams, options?: RequestOptions): Promise<Response<Subscription>>;
    /**
     * Updates an existing subscription to match the specified parameters.
     * When changing prices or quantities, we optionally prorate the price we charge next month to make up for any price changes.
     * To preview how the proration is calculated, use the [create preview](https://docs.stripe.com/docs/api/invoices/create_preview) endpoint.
     *
     * By default, we prorate subscription changes. For example, if a customer signs up on May 1 for a 100 price, they'll be billed 100 immediately. If on May 15 they switch to a 200 price, then on June 1 they'll be billed 250 (200 for a renewal of her subscription, plus a 50 prorating adjustment for half of the previous month's 100 difference). Similarly, a downgrade generates a credit that is applied to the next invoice. We also prorate when you make quantity changes. You can also [use scripts to prorate your billing. To learn more, see <a href="/billing/subscriptions/prorations">Prorations](https://docs.stripe.com/billing/scripts/stripe-authored/proration).
     *
     * Switching prices does not normally change the billing date or generate an immediate charge unless:
     *
     *
     * The billing interval is changed (for example, from monthly to yearly).
     * The subscription moves from free to paid.
     * A trial starts or ends.
     *
     *
     * In these cases, we apply a credit for the unused time on the previous price, immediately charge the customer using the new price, and reset the billing date. Learn about how [Stripe immediately attempts payment for subscription changes](https://docs.stripe.com/docs/billing/subscriptions/upgrade-downgrade#immediate-payment).
     *
     * If you want to charge for an upgrade immediately, pass proration_behavior as always_invoice to create prorations, automatically invoice the customer for those proration adjustments, and attempt to collect payment. If you pass create_prorations, the prorations are created but not automatically invoiced. If you want to bill the customer for the prorations before the subscription's renewal date, you need to manually [invoice the customer](https://docs.stripe.com/docs/api/invoices/create).
     *
     * If you don't want to prorate, set the proration_behavior option to none. With this option, the customer is billed 100 on May 1 and 200 on June 1. Similarly, if you set proration_behavior to none when switching between different billing intervals (for example, from monthly to yearly), we don't generate any credits for the old subscription's unused time. We still reset the billing date and bill immediately for the new subscription.
     *
     * Updating the quantity on a subscription many times in an hour may result in [rate limiting. If you need to bill for a frequently changing quantity, consider integrating <a href="/docs/billing/subscriptions/usage-based">usage-based billing](https://docs.stripe.com/docs/rate-limits) instead.
     */
    update(id: string, params?: SubscriptionUpdateParams, options?: RequestOptions): Promise<Response<Subscription>>;
    /**
     * Removes the currently applied discount on a subscription.
     */
    deleteDiscount(id: string, params?: SubscriptionDeleteDiscountParams, options?: RequestOptions): Promise<Response<DeletedDiscount>>;
    /**
     * By default, returns a list of subscriptions that have not been canceled. In order to list canceled subscriptions, specify status=canceled.
     */
    list(params?: SubscriptionListParams, options?: RequestOptions): ApiListPromise<Subscription>;
    /**
     * Creates a new subscription on an existing customer. Each customer can have up to 500 active or scheduled subscriptions.
     *
     * When you create a subscription with collection_method=charge_automatically, the first invoice is finalized as part of the request.
     * The payment_behavior parameter determines the exact behavior of the initial payment.
     *
     * To start subscriptions where the first invoice always begins in a draft status, use [subscription schedules](https://docs.stripe.com/docs/billing/subscriptions/subscription-schedules#managing) instead.
     * Schedules provide the flexibility to model more complex billing configurations that change over time.
     */
    create(params?: SubscriptionCreateParams, options?: RequestOptions): Promise<Response<Subscription>>;
    /**
     * Search for subscriptions you've previously created using Stripe's [Search Query Language](https://docs.stripe.com/docs/search#search-query-language).
     * Don't use search in read-after-write flows where strict consistency is necessary. Under normal operating
     * conditions, data is searchable in less than a minute. Occasionally, propagation of new or updated data can be up
     * to an hour behind during outages. Search functionality is not available to merchants in India.
     */
    search(params: SubscriptionSearchParams, options?: RequestOptions): ApiSearchResultPromise<Subscription>;
    /**
     * Upgrade the billing_mode of an existing subscription.
     */
    migrate(id: string, params: SubscriptionMigrateParams, options?: RequestOptions): Promise<Response<Subscription>>;
    /**
     * Initiates resumption of a paused subscription, optionally resetting the billing cycle anchor and creating prorations. Resume is only available for subscriptions that use charge_automatically collection. If Stripe doesn't generate a resumption invoice, the subscription becomes active immediately. When a resumption invoice is generated, Stripe finalizes it immediately. If the invoice is paid or marked uncollectible, the subscription becomes active. If the invoice is manually voided, the subscription stays paused. If there is no payment attempt within 23 hours, Stripe voids the invoice and the subscription stays paused. Learn more about [resuming subscriptions](https://docs.stripe.com/docs/billing/subscriptions/pause#resume-subscriptions).
     */
    resume(id: string, params?: SubscriptionResumeParams, options?: RequestOptions): Promise<Response<Subscription>>;
}
export interface Subscription {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'subscription';
    /**
     * ID of the Connect Application that created the subscription.
     */
    application: string | Application | DeletedApplication | null;
    /**
     * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account.
     */
    application_fee_percent: number | null;
    automatic_tax: Subscription.AutomaticTax;
    /**
     * The reference point that aligns future [billing cycle](https://docs.stripe.com/subscriptions/billing-cycle) dates. It sets the day of week for `week` intervals, the day of month for `month` and `year` intervals, and the month of year for `year` intervals. The timestamp is in UTC format.
     */
    billing_cycle_anchor: number;
    /**
     * The fixed values used to calculate the `billing_cycle_anchor`.
     */
    billing_cycle_anchor_config: Subscription.BillingCycleAnchorConfig | null;
    /**
     * The billing mode of the subscription.
     */
    billing_mode: Subscription.BillingMode;
    /**
     * Billing schedules for this subscription.
     */
    billing_schedules: Array<Subscription.BillingSchedule>;
    /**
     * Define thresholds at which an invoice will be sent, and the subscription advanced to a new billing period
     */
    billing_thresholds: Subscription.BillingThresholds | null;
    /**
     * A date in the future at which the subscription will automatically get canceled
     */
    cancel_at: number | null;
    /**
     * Whether this subscription will (if `status=active`) or did (if `status=canceled`) cancel at the end of the current billing period.
     */
    cancel_at_period_end: boolean;
    /**
     * If the subscription has been canceled, the date of that cancellation. If the subscription was canceled with `cancel_at_period_end`, `canceled_at` will reflect the time of the most recent update request, not the end of the subscription period when the subscription is automatically moved to a canceled state.
     */
    canceled_at: number | null;
    /**
     * Details about why this subscription was cancelled
     */
    cancellation_details: Subscription.CancellationDetails | null;
    /**
     * Either `charge_automatically`, or `send_invoice`. When charging automatically, Stripe will attempt to pay this subscription at the end of the cycle using the default source attached to the customer. When sending an invoice, Stripe will email your customer an invoice with payment instructions and mark the subscription as `active`.
     */
    collection_method: Subscription.CollectionMethod;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
     */
    currency: string;
    /**
     * ID of the customer who owns the subscription.
     */
    customer: string | Customer | DeletedCustomer;
    /**
     * ID of the account representing the customer who owns the subscription.
     */
    customer_account: string | null;
    /**
     * Number of days a customer has to pay invoices generated by this subscription. This value will be `null` for subscriptions where `collection_method=charge_automatically`.
     */
    days_until_due: number | null;
    /**
     * ID of the default payment method for the subscription. It must belong to the customer associated with the subscription. This takes precedence over `default_source`. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).
     */
    default_payment_method: string | PaymentMethod | null;
    /**
     * ID of the default payment source for the subscription. It must belong to the customer associated with the subscription and be in a chargeable state. If `default_payment_method` is also set, `default_payment_method` will take precedence. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).
     */
    default_source: string | CustomerSource | null;
    /**
     * The tax rates that will apply to any subscription item that does not have `tax_rates` set. Invoices created will have their `default_tax_rates` populated from the subscription.
     */
    default_tax_rates?: Array<TaxRate> | null;
    /**
     * The subscription's description, meant to be displayable to the customer. Use this field to optionally store an explanation of the subscription for rendering in Stripe surfaces and certain local payment methods UIs.
     */
    description: string | null;
    /**
     * The discounts applied to the subscription. Subscription item discounts are applied before subscription discounts. Use `expand[]=discounts` to expand each discount.
     */
    discounts: Array<string | Discount>;
    /**
     * If the subscription has ended, the date the subscription ended.
     */
    ended_at: number | null;
    invoice_settings: Subscription.InvoiceSettings;
    /**
     * List of subscription items, each with an attached price.
     */
    items: ApiList<SubscriptionItem>;
    /**
     * The most recent invoice this subscription has generated over its lifecycle (for example, when it cycles or is updated).
     */
    latest_invoice: string | Invoice | null;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * Settings for Managed Payments for this Subscription and resulting [Invoices](https://docs.stripe.com/api/invoices/object) and [PaymentIntents](https://docs.stripe.com/api/payment_intents/object).
     */
    managed_payments: Subscription.ManagedPayments | null;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
     */
    metadata: Metadata;
    /**
     * Specifies the approximate timestamp on which any pending invoice items will be billed according to the schedule provided at `pending_invoice_item_interval`.
     */
    next_pending_invoice_item_invoice: number | null;
    /**
     * The account (if any) the charge was made on behalf of for charges associated with this subscription. See the [Connect documentation](https://docs.stripe.com/connect/subscriptions#on-behalf-of) for details.
     */
    on_behalf_of: string | Account | null;
    /**
     * If specified, payment collection for this subscription will be paused. Note that the subscription status will be unchanged and will not be updated to `paused`. Learn more about [pausing collection](https://docs.stripe.com/billing/subscriptions/pause-payment).
     */
    pause_collection: Subscription.PauseCollection | null;
    /**
     * Payment settings passed on to invoices created by the subscription.
     */
    payment_settings: Subscription.PaymentSettings | null;
    /**
     * Specifies an interval for how often to bill for any pending invoice items. It is analogous to calling [Create an invoice](https://docs.stripe.com/api/invoices/create) for the given subscription at the specified interval.
     */
    pending_invoice_item_interval: Subscription.PendingInvoiceItemInterval | null;
    /**
     * You can use this [SetupIntent](https://docs.stripe.com/api/setup_intents) to collect user authentication when creating a subscription without immediate payment or updating a subscription's payment method, allowing you to optimize for off-session payments. Learn more in the [SCA Migration Guide](https://docs.stripe.com/billing/migration/strong-customer-authentication#scenario-2).
     */
    pending_setup_intent: string | SetupIntent | null;
    /**
     * If specified, [pending updates](https://docs.stripe.com/billing/subscriptions/pending-updates) that will be applied to the subscription once the `latest_invoice` has been paid.
     */
    pending_update: Subscription.PendingUpdate | null;
    presentment_details?: Subscription.PresentmentDetails;
    /**
     * The schedule attached to the subscription
     */
    schedule: string | SubscriptionSchedule | null;
    /**
     * Date when the subscription was first created. The date might differ from the `created` date due to backdating.
     */
    start_date: number;
    /**
     * Possible values are `incomplete`, `incomplete_expired`, `trialing`, `active`, `past_due`, `canceled`, `unpaid`, or `paused`.
     *
     * For `collection_method=charge_automatically` a subscription moves into `incomplete` if the initial payment attempt fails. A subscription in this status can only have metadata and default_source updated. Once the first invoice is paid, the subscription moves into an `active` status. If the first invoice is not paid within 23 hours, the subscription transitions to `incomplete_expired`. This is a terminal status, the open invoice will be voided and no further invoices will be generated.
     *
     * A subscription that is currently in a trial period is `trialing` and moves to `active` when the trial period is over.
     *
     * A subscription can only enter a `paused` status [when a trial ends without a payment method](https://docs.stripe.com/billing/subscriptions/trials#create-free-trials-without-payment). A `paused` subscription doesn't generate invoices and can be resumed after your customer adds their payment method. The `paused` status is different from [pausing collection](https://docs.stripe.com/billing/subscriptions/pause-payment), which still generates invoices and leaves the subscription's status unchanged.
     *
     * If subscription `collection_method=charge_automatically`, it becomes `past_due` when payment is required but cannot be paid (due to failed payment or awaiting additional user actions). Once Stripe has exhausted all payment retry attempts, the subscription will become `canceled` or `unpaid` (depending on your subscriptions settings).
     *
     * If subscription `collection_method=send_invoice` it becomes `past_due` when its invoice is not paid by the due date, and `canceled` or `unpaid` if it is still not paid by an additional deadline after that. Note that when a subscription has a status of `unpaid`, no subsequent invoices will be attempted (invoices will be created, but then immediately automatically closed). After receiving updated payment information from a customer, you may choose to reopen and pay their closed invoices.
     */
    status: Subscription.Status;
    /**
     * ID of the test clock this subscription belongs to.
     */
    test_clock: string | TestHelpers.TestClock | null;
    /**
     * The account (if any) the subscription's payments will be attributed to for tax reporting, and where funds from each payment will be transferred to for each of the subscription's invoices.
     */
    transfer_data: Subscription.TransferData | null;
    /**
     * If the subscription has a trial, the end of that trial.
     */
    trial_end: number | null;
    /**
     * Settings related to subscription trials.
     */
    trial_settings: Subscription.TrialSettings | null;
    /**
     * If the subscription has a trial, the beginning of that trial.
     */
    trial_start: number | null;
}
export declare namespace Subscription {
    interface AutomaticTax {
        /**
         * If Stripe disabled automatic tax, this enum describes why.
         */
        disabled_reason: 'requires_location_inputs' | null;
        /**
         * Whether Stripe automatically computes tax on this subscription.
         */
        enabled: boolean;
        /**
         * The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account.
         */
        liability: AutomaticTax.Liability | null;
    }
    interface BillingCycleAnchorConfig {
        /**
         * The day of the month of the billing_cycle_anchor.
         */
        day_of_month: number;
        /**
         * The hour of the day of the billing_cycle_anchor.
         */
        hour: number | null;
        /**
         * The minute of the hour of the billing_cycle_anchor.
         */
        minute: number | null;
        /**
         * The month to start full cycle billing periods.
         */
        month: number | null;
        /**
         * The second of the minute of the billing_cycle_anchor.
         */
        second: number | null;
    }
    interface BillingMode {
        /**
         * Configure behavior for flexible billing mode
         */
        flexible: BillingMode.Flexible | null;
        /**
         * Controls how prorations and invoices for subscriptions are calculated and orchestrated.
         */
        type: BillingMode.Type;
        /**
         * Details on when the current billing_mode was adopted.
         */
        updated_at?: number;
    }
    interface BillingSchedule {
        /**
         * Specifies which subscription items the billing schedule applies to.
         */
        applies_to: Array<BillingSchedule.AppliesTo> | null;
        /**
         * Specifies the end of billing period.
         */
        bill_until: BillingSchedule.BillUntil;
        /**
         * Unique identifier for the billing schedule.
         */
        key: string;
    }
    interface BillingThresholds {
        /**
         * Monetary threshold that triggers the subscription to create an invoice
         */
        amount_gte: number | null;
        /**
         * Indicates if the `billing_cycle_anchor` should be reset when a threshold is reached. If true, `billing_cycle_anchor` will be updated to the date/time the threshold was last reached; otherwise, the value will remain unchanged. This value may not be `true` if the subscription contains items with plans that have `aggregate_usage=last_ever`.
         */
        reset_billing_cycle_anchor: boolean | null;
    }
    interface CancellationDetails {
        /**
         * Additional comments about why the user canceled the subscription, if the subscription was canceled explicitly by the user.
         */
        comment: string | null;
        /**
         * The customer submitted reason for why they canceled, if the subscription was canceled explicitly by the user.
         */
        feedback: CancellationDetails.Feedback | null;
        /**
         * Customized feedback options that provide deeper insight into why the subscription was canceled, if the subscription was canceled explicitly by the user.
         */
        feedback_option: string | Billing.FeedbackOption | null;
        /**
         * Why this subscription was canceled.
         */
        reason: CancellationDetails.Reason | null;
    }
    type CollectionMethod = 'charge_automatically' | 'send_invoice' | OtherString;
    interface InvoiceSettings {
        /**
         * The account tax IDs associated with the subscription. Will be set on invoices generated by the subscription.
         */
        account_tax_ids: Array<string | TaxId | DeletedTaxId> | null;
        /**
         * A list of up to 4 custom fields to be displayed on the invoice.
         */
        custom_fields: Array<InvoiceSettings.CustomField> | null;
        /**
         * An arbitrary string attached to the object. Often useful for displaying to users.
         */
        description: string | null;
        /**
         * Footer to be displayed on the invoice.
         */
        footer: string | null;
        issuer: InvoiceSettings.Issuer;
    }
    interface ManagedPayments {
        /**
         * Set to `true` to enable [Managed Payments](https://docs.stripe.com/payments/managed-payments), Stripe's merchant of record solution, for this session.
         */
        enabled: boolean;
    }
    interface PauseCollection {
        /**
         * The payment collection behavior for this subscription while paused.
         */
        behavior: PauseCollection.Behavior;
        /**
         * The time after which the subscription will resume collecting payments.
         */
        resumes_at: number | null;
    }
    interface PaymentSettings {
        /**
         * Payment-method-specific configuration to provide to invoices created by the subscription.
         */
        payment_method_options: PaymentSettings.PaymentMethodOptions | null;
        /**
         * The list of payment method types to provide to every invoice created by the subscription. If not set, Stripe attempts to automatically determine the types to use by looking at the invoice's default payment method, the subscription's default payment method, the customer's default payment method, and your [invoice template settings](https://dashboard.stripe.com/settings/billing/invoice).
         */
        payment_method_types: Array<PaymentSettings.PaymentMethodType> | null;
        /**
         * Configure whether Stripe updates `subscription.default_payment_method` when payment succeeds. Defaults to `off`.
         */
        save_default_payment_method: PaymentSettings.SaveDefaultPaymentMethod | null;
    }
    interface PendingInvoiceItemInterval {
        /**
         * Specifies invoicing frequency. Either `day`, `week`, `month` or `year`.
         */
        interval: PendingInvoiceItemInterval.Interval;
        /**
         * The number of intervals between invoices. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of one year interval allowed (1 year, 12 months, or 52 weeks).
         */
        interval_count: number;
    }
    interface PendingUpdate {
        /**
         * If the update is applied, determines the date of the first full invoice, and, for plans with `month` or `year` intervals, the day of the month for subsequent invoices. The timestamp is in UTC format.
         */
        billing_cycle_anchor: number | null;
        /**
         * The pending subscription-level discount that will be applied when the pending update is applied.
         */
        discount: Discount | null;
        /**
         * The discounts that will be applied to the subscription when the pending update is applied. Use `expand[]=discounts` to expand each discount.
         */
        discounts: Array<string | Discount> | null;
        /**
         * The point after which the changes reflected by this update will be discarded and no longer applied.
         */
        expires_at: number;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
         */
        metadata: Metadata | null;
        /**
         * List of subscription items, each with an attached plan, that will be set if the update is applied.
         */
        subscription_items: Array<SubscriptionItem> | null;
        /**
         * Unix timestamp representing the end of the trial period the customer will get before being charged for the first time, if the update is applied.
         */
        trial_end: number | null;
        /**
         * Indicates if a plan's `trial_period_days` should be applied to the subscription. Setting `trial_end` per subscription is preferred, and this defaults to `false`. Setting this flag to `true` together with `trial_end` is not allowed. See [Using trial periods on subscriptions](https://docs.stripe.com/billing/subscriptions/trials) to learn more.
         */
        trial_from_plan: boolean | null;
    }
    interface PresentmentDetails {
        /**
         * Currency used for customer payments.
         */
        presentment_currency: string;
    }
    type Status = 'active' | 'canceled' | 'incomplete' | 'incomplete_expired' | 'past_due' | 'paused' | 'trialing' | 'unpaid' | OtherString;
    interface TransferData {
        /**
         * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the destination account. By default, the entire amount is transferred to the destination.
         */
        amount_percent: number | null;
        /**
         * The account where funds from the payment will be transferred to upon payment success.
         */
        destination: string | Account;
    }
    interface TrialSettings {
        /**
         * Defines how a subscription behaves when a trial ends.
         */
        end_behavior: TrialSettings.EndBehavior;
    }
    namespace AutomaticTax {
        interface Liability {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string | Account;
            /**
             * Type of the account referenced.
             */
            type: Liability.Type;
        }
        namespace Liability {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace BillingMode {
        interface Flexible {
            /**
             * Controls how invoices and invoice items display proration amounts and discount amounts.
             */
            proration_discounts?: Flexible.ProrationDiscounts;
        }
        type Type = 'classic' | 'flexible' | OtherString;
        namespace Flexible {
            type ProrationDiscounts = 'included' | 'itemized' | OtherString;
        }
    }
    namespace BillingSchedule {
        interface AppliesTo {
            /**
             * The billing schedule will apply to the subscription item with the given price ID.
             */
            price: string | Price | null;
            /**
             * Controls which subscription items the billing schedule applies to.
             */
            type: 'price';
        }
        interface BillUntil {
            /**
             * The timestamp the billing schedule will apply until.
             */
            computed_timestamp: number;
            /**
             * Specifies the billing period.
             */
            duration: BillUntil.Duration | null;
            /**
             * If specified, the billing schedule will apply until the specified timestamp.
             */
            timestamp: number | null;
            /**
             * Describes how the billing schedule will determine the end date. Either `duration` or `timestamp`.
             */
            type: BillUntil.Type;
        }
        namespace BillUntil {
            interface Duration {
                /**
                 * Specifies billing duration. Either `day`, `week`, `month` or `year`.
                 */
                interval: Duration.Interval;
                /**
                 * The multiplier applied to the interval.
                 */
                interval_count: number | null;
            }
            type Type = 'duration' | 'timestamp' | OtherString;
            namespace Duration {
                type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
            }
        }
    }
    namespace CancellationDetails {
        type Feedback = 'customer_service' | 'low_quality' | 'missing_features' | 'other' | 'switched_service' | 'too_complex' | 'too_expensive' | 'unused' | OtherString;
        type Reason = 'canceled_by_retention_policy' | 'cancellation_requested' | 'payment_disputed' | 'payment_failed' | OtherString;
    }
    namespace InvoiceSettings {
        interface CustomField {
            /**
             * The name of the custom field.
             */
            name: string;
            /**
             * The value of the custom field.
             */
            value: string;
        }
        interface Issuer {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string | Account;
            /**
             * Type of the account referenced.
             */
            type: Issuer.Type;
        }
        namespace Issuer {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace PauseCollection {
        type Behavior = 'keep_as_draft' | 'mark_uncollectible' | 'void' | OtherString;
    }
    namespace PaymentSettings {
        interface PaymentMethodOptions {
            /**
             * This sub-hash contains details about the Canadian pre-authorized debit payment method options to pass to invoices created by the subscription.
             */
            acss_debit: PaymentMethodOptions.AcssDebit | null;
            /**
             * This sub-hash contains details about the Bancontact payment method options to pass to invoices created by the subscription.
             */
            bancontact: PaymentMethodOptions.Bancontact | null;
            /**
             * This sub-hash contains details about the Billie payment method options to pass to invoices created by the subscription.
             */
            billie?: PaymentMethodOptions.Billie | null;
            /**
             * This sub-hash contains details about the Card payment method options to pass to invoices created by the subscription.
             */
            card: PaymentMethodOptions.Card | null;
            /**
             * This sub-hash contains details about the Bank transfer payment method options to pass to invoices created by the subscription.
             */
            customer_balance: PaymentMethodOptions.CustomerBalance | null;
            /**
             * This sub-hash contains details about the Konbini payment method options to pass to invoices created by the subscription.
             */
            konbini: PaymentMethodOptions.Konbini | null;
            /**
             * This sub-hash contains details about the PayTo payment method options to pass to invoices created by the subscription.
             */
            payto: PaymentMethodOptions.Payto | null;
            /**
             * This sub-hash contains details about the Pix payment method options to pass to invoices created by the subscription.
             */
            pix: PaymentMethodOptions.Pix | null;
            /**
             * This sub-hash contains details about the SEPA Direct Debit payment method options to pass to invoices created by the subscription.
             */
            sepa_debit: PaymentMethodOptions.SepaDebit | null;
            /**
             * This sub-hash contains details about the UPI payment method options to pass to invoices created by the subscription.
             */
            upi: PaymentMethodOptions.Upi | null;
            /**
             * This sub-hash contains details about the ACH direct debit payment method options to pass to invoices created by the subscription.
             */
            us_bank_account: PaymentMethodOptions.UsBankAccount | null;
        }
        type PaymentMethodType = 'ach_credit_transfer' | 'ach_debit' | 'acss_debit' | 'affirm' | 'alipay' | 'amazon_pay' | 'au_becs_debit' | 'bacs_debit' | 'bancontact' | 'billie' | 'boleto' | 'card' | 'cashapp' | 'crypto' | 'custom' | 'customer_balance' | 'eps' | 'fpx' | 'giropay' | 'grabpay' | 'ideal' | 'jp_credit_transfer' | 'kakao_pay' | 'klarna' | 'konbini' | 'kr_card' | 'link' | 'mb_way' | 'multibanco' | 'naver_pay' | 'nz_bank_account' | 'p24' | 'pay_by_bank' | 'payco' | 'paynow' | 'paypal' | 'payto' | 'pix' | 'promptpay' | 'revolut_pay' | 'satispay' | 'sepa_credit_transfer' | 'sepa_debit' | 'sofort' | 'swish' | 'twint' | 'upi' | 'us_bank_account' | 'wechat_pay' | OtherString;
        type SaveDefaultPaymentMethod = 'off' | 'on_subscription' | OtherString;
        namespace PaymentMethodOptions {
            interface AcssDebit {
                mandate_options?: AcssDebit.MandateOptions;
                /**
                 * Bank account verification method. The default value is `automatic`.
                 */
                verification_method?: AcssDebit.VerificationMethod;
            }
            interface Bancontact {
                /**
                 * Preferred language of the Bancontact authorization page that the customer is redirected to.
                 */
                preferred_language: Bancontact.PreferredLanguage;
            }
            interface Billie {
            }
            interface Card {
                mandate_options?: Card.MandateOptions;
                /**
                 * Selected network to process this Subscription on. Depends on the available networks of the card attached to the Subscription. Can be only set confirm-time.
                 */
                network: Card.Network | null;
                /**
                 * We strongly recommend that you rely on our SCA Engine to automatically prompt your customers for authentication based on risk level and [other requirements](https://docs.stripe.com/strong-customer-authentication). However, if you wish to request 3D Secure based on logic from your own fraud engine, provide this option. Read our guide on [manually requesting 3D Secure](https://docs.stripe.com/payments/3d-secure/authentication-flow#manual-three-ds) for more information on how this configuration interacts with Radar and our SCA Engine.
                 */
                request_three_d_secure: Card.RequestThreeDSecure | null;
            }
            interface CustomerBalance {
                bank_transfer?: CustomerBalance.BankTransfer;
                /**
                 * The funding method type to be used when there are not enough funds in the customer balance. Permitted values include: `bank_transfer`.
                 */
                funding_type: 'bank_transfer' | null;
            }
            interface Konbini {
            }
            interface Payto {
                mandate_options?: Payto.MandateOptions;
            }
            interface Pix {
                /**
                 * The number of seconds (between 10 and 1209600) after which Pix payment will expire. Defaults to 86400 seconds.
                 */
                expires_after_seconds?: number;
                mandate_options?: Pix.MandateOptions;
            }
            interface SepaDebit {
            }
            interface Upi {
                mandate_options?: Upi.MandateOptions;
            }
            interface UsBankAccount {
                financial_connections?: UsBankAccount.FinancialConnections;
                /**
                 * Bank account verification method. The default value is `automatic`.
                 */
                verification_method?: UsBankAccount.VerificationMethod;
            }
            namespace AcssDebit {
                interface MandateOptions {
                    /**
                     * Transaction type of the mandate.
                     */
                    transaction_type: MandateOptions.TransactionType | null;
                }
                type VerificationMethod = 'automatic' | 'instant' | 'microdeposits' | OtherString;
                namespace MandateOptions {
                    type TransactionType = 'business' | 'personal' | OtherString;
                }
            }
            namespace Bancontact {
                type PreferredLanguage = 'de' | 'en' | 'fr' | 'nl' | OtherString;
            }
            namespace Card {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments, specified in the presentment currency.
                     */
                    amount: number | null;
                    /**
                     * One of `fixed` or `maximum`. If `fixed`, the `amount` param refers to the exact amount to be charged in future payments. If `maximum`, the amount charged can be up to the value passed for the `amount` param.
                     */
                    amount_type: MandateOptions.AmountType | null;
                    /**
                     * A description of the mandate or subscription that is meant to be displayed to the customer.
                     */
                    description: string | null;
                }
                type Network = 'amex' | 'cartes_bancaires' | 'diners' | 'discover' | 'eftpos_au' | 'girocard' | 'interac' | 'jcb' | 'link' | 'mastercard' | 'unionpay' | 'unknown' | 'visa' | OtherString;
                type RequestThreeDSecure = 'any' | 'automatic' | 'challenge' | OtherString;
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                }
            }
            namespace CustomerBalance {
                interface BankTransfer {
                    eu_bank_transfer?: BankTransfer.EuBankTransfer;
                    /**
                     * The bank transfer type that can be used for funding. Permitted values include: `eu_bank_transfer`, `gb_bank_transfer`, `jp_bank_transfer`, `mx_bank_transfer`, or `us_bank_transfer`.
                     */
                    type: string | null;
                }
                namespace BankTransfer {
                    interface EuBankTransfer {
                        /**
                         * The desired country code of the bank account information. Permitted values include: `DE`, `FR`, `IE`, or `NL`.
                         */
                        country: EuBankTransfer.Country;
                    }
                    namespace EuBankTransfer {
                        type Country = 'BE' | 'DE' | 'ES' | 'FR' | 'IE' | 'NL' | OtherString;
                    }
                }
            }
            namespace Payto {
                interface MandateOptions {
                    /**
                     * The maximum amount that can be collected in a single invoice. If you don't specify a maximum, then there is no limit.
                     */
                    amount: number | null;
                    /**
                     * Only `maximum` is supported.
                     */
                    amount_type: MandateOptions.AmountType | null;
                    /**
                     * The purpose for which payments are made. Has a default value based on your merchant category code.
                     */
                    purpose: MandateOptions.Purpose | null;
                }
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                    type Purpose = 'dependant_support' | 'government' | 'loan' | 'mortgage' | 'other' | 'pension' | 'personal' | 'retail' | 'salary' | 'tax' | 'utility' | OtherString;
                }
            }
            namespace Pix {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments.
                     */
                    amount: number | null;
                    /**
                     * Determines if the amount includes the IOF tax.
                     */
                    amount_includes_iof: MandateOptions.AmountIncludesIof | null;
                    /**
                     * Date when the mandate expires and no further payments will be charged, in `YYYY-MM-DD`.
                     */
                    end_date: string | null;
                    /**
                     * Schedule at which the future payments will be charged.
                     */
                    payment_schedule: MandateOptions.PaymentSchedule | null;
                }
                namespace MandateOptions {
                    type AmountIncludesIof = 'always' | 'never' | OtherString;
                    type PaymentSchedule = 'halfyearly' | 'monthly' | 'quarterly' | 'weekly' | 'yearly' | OtherString;
                }
            }
            namespace Upi {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments.
                     */
                    amount: number | null;
                    /**
                     * One of `fixed` or `maximum`. If `fixed`, the `amount` param refers to the exact amount to be charged in future payments. If `maximum`, the amount charged can be up to the value passed for the `amount` param.
                     */
                    amount_type: MandateOptions.AmountType | null;
                    /**
                     * A description of the mandate or subscription that is meant to be displayed to the customer.
                     */
                    description: string | null;
                    /**
                     * End date of the mandate or subscription.
                     */
                    end_date: number | null;
                }
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                }
            }
            namespace UsBankAccount {
                interface FinancialConnections {
                    filters?: FinancialConnections.Filters;
                    /**
                     * The list of permissions to request. The `payment_method` permission must be included.
                     */
                    permissions?: Array<FinancialConnections.Permission>;
                    /**
                     * Data features requested to be retrieved upon account creation.
                     */
                    prefetch: Array<FinancialConnections.Prefetch> | null;
                }
                type VerificationMethod = 'automatic' | 'instant' | 'microdeposits' | OtherString;
                namespace FinancialConnections {
                    interface Filters {
                        /**
                         * The account subcategories to use to filter for possible accounts to link. Valid subcategories are `checking` and `savings`.
                         */
                        account_subcategories?: Array<Filters.AccountSubcategory>;
                    }
                    type Permission = 'balances' | 'ownership' | 'payment_method' | 'transactions' | OtherString;
                    type Prefetch = 'balances' | 'ownership' | 'transactions' | OtherString;
                    namespace Filters {
                        type AccountSubcategory = 'checking' | 'savings' | OtherString;
                    }
                }
            }
        }
    }
    namespace PendingInvoiceItemInterval {
        type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
    }
    namespace TrialSettings {
        interface EndBehavior {
            /**
             * Indicates how the subscription should change when the trial ends if the user did not provide a payment method.
             */
            missing_payment_method: EndBehavior.MissingPaymentMethod;
        }
        namespace EndBehavior {
            type MissingPaymentMethod = 'cancel' | 'create_invoice' | 'pause' | OtherString;
        }
    }
}
export interface SubscriptionCreateParams {
    /**
     * A list of prices and quantities that will generate invoice items appended to the next invoice for this subscription. You may pass up to 20 items.
     */
    add_invoice_items?: Array<SubscriptionCreateParams.AddInvoiceItem>;
    /**
     * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account. The request must be made by a platform account on a connected account in order to set an application fee percentage. For more information, see the application fees [documentation](https://stripe.com/docs/connect/subscriptions#collecting-fees-on-subscriptions).
     */
    application_fee_percent?: Emptyable<number>;
    /**
     * Automatic tax settings for this subscription.
     */
    automatic_tax?: SubscriptionCreateParams.AutomaticTax;
    /**
     * A past timestamp to backdate the subscription's start date to. If set, the first invoice will contain line items for the timespan between the start date and the current time. Can be combined with trials and the billing cycle anchor.
     */
    backdate_start_date?: number;
    /**
     * A future timestamp in UTC format to anchor the subscription's [billing cycle](https://docs.stripe.com/subscriptions/billing-cycle). The anchor is the reference point that aligns future billing cycle dates. It sets the day of week for `week` intervals, the day of month for `month` and `year` intervals, and the month of year for `year` intervals.
     */
    billing_cycle_anchor?: number;
    /**
     * Mutually exclusive with billing_cycle_anchor and only valid with monthly and yearly price intervals. When provided, the billing_cycle_anchor is set to the next occurrence of the day_of_month at the hour, minute, and second UTC.
     */
    billing_cycle_anchor_config?: SubscriptionCreateParams.BillingCycleAnchorConfig;
    /**
     * Controls how prorations and invoices for subscriptions are calculated and orchestrated.
     */
    billing_mode?: SubscriptionCreateParams.BillingMode;
    /**
     * An array of billing schedules, which allow you to bill customers in advance for multiple service periods. Requires flexible billing mode and API version 2026-05-27.dahlia or later. Learn more about [prebilling](https://docs.stripe.com/billing/subscriptions/prebilling).
     */
    billing_schedules?: Array<SubscriptionCreateParams.BillingSchedule>;
    /**
     * Define thresholds at which an invoice will be sent, and the subscription advanced to a new billing period. When updating, pass an empty string to remove previously-defined thresholds.
     */
    billing_thresholds?: Emptyable<SubscriptionCreateParams.BillingThresholds>;
    /**
     * A timestamp at which the subscription should cancel. If set to a date before the current period ends, this will cause a proration if prorations have been enabled using `proration_behavior`. If set during a future period, this will always cause a proration for that period.
     */
    cancel_at?: number | SubscriptionCreateParams.CancelAt;
    /**
     * Indicate whether this subscription should cancel at the end of the current period (`current_period_end`). Defaults to `false`.
     */
    cancel_at_period_end?: boolean;
    /**
     * Either `charge_automatically`, or `send_invoice`. When charging automatically, Stripe will attempt to pay this subscription at the end of the cycle using the default source attached to the customer. When sending an invoice, Stripe will email your customer an invoice with payment instructions and mark the subscription as `active`. Defaults to `charge_automatically`.
     */
    collection_method?: SubscriptionCreateParams.CollectionMethod;
    /**
     * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
     */
    currency?: string;
    /**
     * The identifier of the customer to subscribe.
     */
    customer?: string;
    /**
     * The identifier of the account representing the customer to subscribe.
     */
    customer_account?: string;
    /**
     * Number of days a customer has to pay invoices generated by this subscription. Valid only for subscriptions where `collection_method` is set to `send_invoice`.
     */
    days_until_due?: number;
    /**
     * ID of the default payment method for the subscription. It must belong to the customer associated with the subscription. This takes precedence over `default_source`. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).
     */
    default_payment_method?: string;
    /**
     * ID of the default payment source for the subscription. It must belong to the customer associated with the subscription and be in a chargeable state. If `default_payment_method` is also set, `default_payment_method` will take precedence. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).
     */
    default_source?: string;
    /**
     * The tax rates that will apply to any subscription item that does not have `tax_rates` set. Invoices created will have their `default_tax_rates` populated from the subscription.
     */
    default_tax_rates?: Emptyable<Array<string>>;
    /**
     * The subscription's description, meant to be displayable to the customer. Use this field to optionally store an explanation of the subscription for rendering in Stripe surfaces and certain local payment methods UIs.
     */
    description?: string;
    /**
     * The coupons to redeem into discounts for the subscription. If not specified or empty, inherits the discount from the subscription's customer.
     */
    discounts?: Emptyable<Array<SubscriptionCreateParams.Discount>>;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * All invoices will be billed using the specified settings.
     */
    invoice_settings?: SubscriptionCreateParams.InvoiceSettings;
    /**
     * A list of up to 20 subscription items, each with an attached price.
     */
    items?: Array<SubscriptionCreateParams.Item>;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
     */
    metadata?: Emptyable<MetadataParam>;
    /**
     * Indicates if a customer is on or off-session while an invoice payment is attempted. Defaults to `false` (on-session).
     */
    off_session?: boolean;
    /**
     * The account on behalf of which to charge, for each of the subscription's invoices.
     */
    on_behalf_of?: Emptyable<string>;
    /**
     * Controls how Stripe handles the first invoice when payment is required and `collection_method=charge_automatically`. Subscriptions with `collection_method=send_invoice` are automatically activated regardless of the first Invoice status.
     */
    payment_behavior?: SubscriptionCreateParams.PaymentBehavior;
    /**
     * Payment settings to pass to invoices created by the subscription.
     */
    payment_settings?: SubscriptionCreateParams.PaymentSettings;
    /**
     * Specifies an interval for how often to bill for any pending invoice items. It is analogous to calling [Create an invoice](https://docs.stripe.com/api/invoices/create) for the given subscription at the specified interval.
     */
    pending_invoice_item_interval?: Emptyable<SubscriptionCreateParams.PendingInvoiceItemInterval>;
    /**
     * Determines how to handle [prorations](https://docs.stripe.com/billing/subscriptions/prorations) resulting from the `billing_cycle_anchor`. If no value is passed, the default is `create_prorations`.
     */
    proration_behavior?: SubscriptionCreateParams.ProrationBehavior;
    /**
     * If specified, the funds from the subscription's invoices will be transferred to the destination and the ID of the resulting transfers will be found on the resulting charges.
     */
    transfer_data?: SubscriptionCreateParams.TransferData;
    /**
     * Unix timestamp representing the end of the trial period the customer will get before being charged for the first time. If set, trial_end will override the default trial period of the plan the customer is being subscribed to. The special value `now` can be provided to end the customer's trial immediately. Can be at most two years from `billing_cycle_anchor`. See [Using trial periods on subscriptions](https://docs.stripe.com/billing/subscriptions/trials) to learn more.
     */
    trial_end?: 'now' | number;
    /**
     * Indicates if a plan's `trial_period_days` should be applied to the subscription. Setting `trial_end` per subscription is preferred, and this defaults to `false`. Setting this flag to `true` together with `trial_end` is not allowed. See [Using trial periods on subscriptions](https://docs.stripe.com/billing/subscriptions/trials) to learn more.
     */
    trial_from_plan?: boolean;
    /**
     * Integer representing the number of trial period days before the customer is charged for the first time. This will always overwrite any trials that might apply via a subscribed plan. See [Using trial periods on subscriptions](https://docs.stripe.com/billing/subscriptions/trials) to learn more.
     */
    trial_period_days?: number;
    /**
     * Settings related to subscription trials.
     */
    trial_settings?: SubscriptionCreateParams.TrialSettings;
}
export declare namespace SubscriptionCreateParams {
    interface AddInvoiceItem {
        /**
         * Controls whether discounts apply to this invoice item. Defaults to true if no value is provided.
         */
        discountable?: boolean;
        /**
         * The coupons to redeem into discounts for the item.
         */
        discounts?: Array<AddInvoiceItem.Discount>;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
         */
        metadata?: MetadataParam;
        /**
         * The period associated with this invoice item. If not set, `period.start.type` defaults to `max_item_period_start` and `period.end.type` defaults to `min_item_period_end`.
         */
        period?: AddInvoiceItem.Period;
        /**
         * The ID of the price object. One of `price` or `price_data` is required.
         */
        price?: string;
        /**
         * Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline. One of `price` or `price_data` is required.
         */
        price_data?: AddInvoiceItem.PriceData;
        /**
         * Quantity for this item. Defaults to 1.
         */
        quantity?: number;
        /**
         * The tax rates which apply to the item. When set, the `default_tax_rates` do not apply to this item.
         */
        tax_rates?: Emptyable<Array<string>>;
    }
    interface AutomaticTax {
        /**
         * Enabled automatic tax calculation which will automatically compute tax rates on all invoices generated by the subscription.
         */
        enabled: boolean;
        /**
         * The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account.
         */
        liability?: AutomaticTax.Liability;
    }
    interface BillingCycleAnchorConfig {
        /**
         * The day of the month the anchor should be. Ranges from 1 to 31.
         */
        day_of_month: number;
        /**
         * The hour of the day the anchor should be. Ranges from 0 to 23.
         */
        hour?: number;
        /**
         * The minute of the hour the anchor should be. Ranges from 0 to 59.
         */
        minute?: number;
        /**
         * The month to start full cycle periods. Ranges from 1 to 12.
         */
        month?: number;
        /**
         * The second of the minute the anchor should be. Ranges from 0 to 59.
         */
        second?: number;
    }
    interface BillingMode {
        /**
         * Configure behavior for flexible billing mode.
         */
        flexible?: BillingMode.Flexible;
        /**
         * Controls the calculation and orchestration of prorations and invoices for subscriptions. If no value is passed, the default is `flexible`.
         */
        type: BillingMode.Type;
    }
    interface BillingSchedule {
        /**
         * Configure billing schedule differently for individual subscription items.
         */
        applies_to?: Array<BillingSchedule.AppliesTo>;
        /**
         * The end date for the billing schedule. You must not set this earlier than current period end for every applicable subscription item.
         */
        bill_until: BillingSchedule.BillUntil;
        /**
         * Specify a key for the billing schedule. Must be unique to this field, alphanumeric, and up to 200 characters. If not provided, a unique key will be generated.
         */
        key?: string;
    }
    interface BillingThresholds {
        /**
         * Monetary threshold that triggers the subscription to advance to a new billing period
         */
        amount_gte?: number;
        /**
         * Indicates if the `billing_cycle_anchor` should be reset when a threshold is reached. If true, `billing_cycle_anchor` will be updated to the date/time the threshold was last reached; otherwise, the value will remain unchanged.
         */
        reset_billing_cycle_anchor?: boolean;
    }
    type CancelAt = 'max_billed_until' | 'max_period_end' | 'min_period_end' | OtherString;
    type CollectionMethod = 'charge_automatically' | 'send_invoice' | OtherString;
    interface Discount {
        /**
         * ID of the coupon to create a new discount for.
         */
        coupon?: string;
        /**
         * ID of an existing discount on the object (or one of its ancestors) to reuse.
         */
        discount?: string;
        /**
         * ID of the promotion code to create a new discount for.
         */
        promotion_code?: string;
    }
    interface InvoiceSettings {
        /**
         * The account tax IDs associated with the subscription. Will be set on invoices generated by the subscription.
         */
        account_tax_ids?: Emptyable<Array<string>>;
        /**
         * A list of up to 4 custom fields to be displayed on the invoice.
         */
        custom_fields?: Emptyable<Array<InvoiceSettings.CustomField>>;
        /**
         * An arbitrary string attached to the object. Often useful for displaying to users.
         */
        description?: string;
        /**
         * Footer to be displayed on the invoice.
         */
        footer?: string;
        /**
         * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
         */
        issuer?: InvoiceSettings.Issuer;
    }
    interface Item {
        /**
         * Define thresholds at which an invoice will be sent, and the subscription advanced to a new billing period. Pass an empty string to remove previously-defined thresholds.
         */
        billing_thresholds?: Emptyable<Item.BillingThresholds>;
        /**
         * The coupons to redeem into discounts for the subscription item.
         */
        discounts?: Emptyable<Array<Item.Discount>>;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
         */
        metadata?: MetadataParam;
        /**
         * Plan ID for this item, as a string.
         */
        plan?: string;
        /**
         * The ID of the price object.
         */
        price?: string;
        /**
         * Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
         */
        price_data?: Item.PriceData;
        /**
         * Quantity for this item.
         */
        quantity?: number;
        /**
         * A list of [Tax Rate](https://docs.stripe.com/api/tax_rates) ids. These Tax Rates will override the [`default_tax_rates`](https://docs.stripe.com/api/subscriptions/create#create_subscription-default_tax_rates) on the Subscription. When updating, pass an empty string to remove previously-defined tax rates.
         */
        tax_rates?: Emptyable<Array<string>>;
    }
    type PaymentBehavior = 'allow_incomplete' | 'default_incomplete' | 'error_if_incomplete' | 'pending_if_incomplete' | OtherString;
    interface PaymentSettings {
        /**
         * Payment-method-specific configuration to provide to invoices created by the subscription.
         */
        payment_method_options?: PaymentSettings.PaymentMethodOptions;
        /**
         * The list of payment method types (e.g. card) to provide to the invoice's PaymentIntent. If not set, Stripe attempts to automatically determine the types to use by looking at the invoice's default payment method, the subscription's default payment method, the customer's default payment method, and your [invoice template settings](https://dashboard.stripe.com/settings/billing/invoice). Should not be specified with payment_method_configuration
         */
        payment_method_types?: Emptyable<Array<PaymentSettings.PaymentMethodType>>;
        /**
         * Configure whether Stripe updates `subscription.default_payment_method` when payment succeeds. Defaults to `off` if unspecified.
         */
        save_default_payment_method?: PaymentSettings.SaveDefaultPaymentMethod;
    }
    interface PendingInvoiceItemInterval {
        /**
         * Specifies invoicing frequency. Either `day`, `week`, `month` or `year`.
         */
        interval: PendingInvoiceItemInterval.Interval;
        /**
         * The number of intervals between invoices. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of one year interval allowed (1 year, 12 months, or 52 weeks).
         */
        interval_count?: number;
    }
    type ProrationBehavior = 'always_invoice' | 'create_prorations' | 'none' | OtherString;
    interface TransferData {
        /**
         * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the destination account. By default, the entire amount is transferred to the destination.
         */
        amount_percent?: number;
        /**
         * ID of an existing, connected Stripe account.
         */
        destination: string;
    }
    interface TrialSettings {
        /**
         * Defines how the subscription should behave when the user's free trial ends.
         */
        end_behavior: TrialSettings.EndBehavior;
    }
    namespace AddInvoiceItem {
        interface Discount {
            /**
             * ID of the coupon to create a new discount for.
             */
            coupon?: string;
            /**
             * ID of an existing discount on the object (or one of its ancestors) to reuse.
             */
            discount?: string;
            /**
             * ID of the promotion code to create a new discount for.
             */
            promotion_code?: string;
        }
        interface Period {
            /**
             * End of the invoice item period.
             */
            end: Period.End;
            /**
             * Start of the invoice item period.
             */
            start: Period.Start;
        }
        interface PriceData {
            /**
             * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
             */
            currency: string;
            /**
             * The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
             */
            product: string;
            /**
             * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
             */
            tax_behavior?: PriceData.TaxBehavior;
            /**
             * A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge or a negative integer representing the amount to credit to the customer.
             */
            unit_amount?: number;
            /**
             * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
             */
            unit_amount_decimal?: Decimal;
        }
        namespace Period {
            interface End {
                /**
                 * A precise Unix timestamp for the end of the invoice item period. Must be greater than or equal to `period.start`.
                 */
                timestamp?: number;
                /**
                 * Select how to calculate the end of the invoice item period.
                 */
                type: End.Type;
            }
            interface Start {
                /**
                 * A precise Unix timestamp for the start of the invoice item period. Must be less than or equal to `period.end`.
                 */
                timestamp?: number;
                /**
                 * Select how to calculate the start of the invoice item period.
                 */
                type: Start.Type;
            }
            namespace End {
                type Type = 'min_item_period_end' | 'timestamp' | OtherString;
            }
            namespace Start {
                type Type = 'max_item_period_start' | 'now' | 'timestamp' | OtherString;
            }
        }
        namespace PriceData {
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
        }
    }
    namespace AutomaticTax {
        interface Liability {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string;
            /**
             * Type of the account referenced in the request.
             */
            type: Liability.Type;
        }
        namespace Liability {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace BillingMode {
        interface Flexible {
            /**
             * Controls how invoices and invoice items display proration amounts and discount amounts.
             */
            proration_discounts?: Flexible.ProrationDiscounts;
        }
        type Type = 'classic' | 'flexible' | OtherString;
        namespace Flexible {
            type ProrationDiscounts = 'included' | 'itemized' | OtherString;
        }
    }
    namespace BillingSchedule {
        interface AppliesTo {
            /**
             * The ID of the price object.
             */
            price?: string;
            /**
             * Controls which subscription items the billing schedule applies to.
             */
            type: 'price';
        }
        interface BillUntil {
            /**
             * Specifies the billing period.
             */
            duration?: BillUntil.Duration;
            /**
             * The end date of the billing schedule.
             */
            timestamp?: number;
            /**
             * Describes how the billing schedule will determine the end date. Either `duration` or `timestamp`.
             */
            type: BillUntil.Type;
        }
        namespace BillUntil {
            interface Duration {
                /**
                 * Specifies billing duration. Either `day`, `week`, `month` or `year`.
                 */
                interval: Duration.Interval;
                /**
                 * The multiplier applied to the interval.
                 */
                interval_count?: number;
            }
            type Type = 'duration' | 'timestamp' | OtherString;
            namespace Duration {
                type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
            }
        }
    }
    namespace InvoiceSettings {
        interface CustomField {
            /**
             * The name of the custom field. This may be up to 40 characters.
             */
            name: string;
            /**
             * The value of the custom field. This may be up to 140 characters.
             */
            value: string;
        }
        interface Issuer {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string;
            /**
             * Type of the account referenced in the request.
             */
            type: Issuer.Type;
        }
        namespace Issuer {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace Item {
        interface BillingThresholds {
            /**
             * Number of units that meets the billing threshold to advance the subscription to a new billing period (e.g., it takes 10 $5 units to meet a $50 [monetary threshold](https://docs.stripe.com/api/subscriptions/update#update_subscription-billing_thresholds-amount_gte))
             */
            usage_gte: number;
        }
        interface Discount {
            /**
             * ID of the coupon to create a new discount for.
             */
            coupon?: string;
            /**
             * ID of an existing discount on the object (or one of its ancestors) to reuse.
             */
            discount?: string;
            /**
             * ID of the promotion code to create a new discount for.
             */
            promotion_code?: string;
        }
        interface PriceData {
            /**
             * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
             */
            currency: string;
            /**
             * The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
             */
            product: string;
            /**
             * The recurring components of a price such as `interval` and `interval_count`.
             */
            recurring: PriceData.Recurring;
            /**
             * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
             */
            tax_behavior?: PriceData.TaxBehavior;
            /**
             * A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge.
             */
            unit_amount?: number;
            /**
             * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
             */
            unit_amount_decimal?: Decimal;
        }
        namespace PriceData {
            interface Recurring {
                /**
                 * Specifies billing frequency. Either `day`, `week`, `month` or `year`.
                 */
                interval: Recurring.Interval;
                /**
                 * The number of intervals between subscription billings. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of three years interval allowed (3 years, 36 months, or 156 weeks).
                 */
                interval_count?: number;
            }
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
            namespace Recurring {
                type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
            }
        }
    }
    namespace PaymentSettings {
        interface PaymentMethodOptions {
            /**
             * This sub-hash contains details about the Canadian pre-authorized debit payment method options to pass to the invoice's PaymentIntent.
             */
            acss_debit?: Emptyable<PaymentMethodOptions.AcssDebit>;
            /**
             * This sub-hash contains details about the Bancontact payment method options to pass to the invoice's PaymentIntent.
             */
            bancontact?: Emptyable<PaymentMethodOptions.Bancontact>;
            /**
             * This sub-hash contains details about the Billie payment method options to pass to the invoice's PaymentIntent.
             */
            billie?: Emptyable<PaymentMethodOptions.Billie>;
            /**
             * This sub-hash contains details about the Card payment method options to pass to the invoice's PaymentIntent.
             */
            card?: Emptyable<PaymentMethodOptions.Card>;
            /**
             * This sub-hash contains details about the Bank transfer payment method options to pass to the invoice's PaymentIntent.
             */
            customer_balance?: Emptyable<PaymentMethodOptions.CustomerBalance>;
            /**
             * This sub-hash contains details about the Konbini payment method options to pass to the invoice's PaymentIntent.
             */
            konbini?: Emptyable<PaymentMethodOptions.Konbini>;
            /**
             * This sub-hash contains details about the PayTo payment method options to pass to the invoice's PaymentIntent.
             */
            payto?: Emptyable<PaymentMethodOptions.Payto>;
            /**
             * This sub-hash contains details about the Pix payment method options to pass to the invoice's PaymentIntent.
             */
            pix?: Emptyable<PaymentMethodOptions.Pix>;
            /**
             * This sub-hash contains details about the SEPA Direct Debit payment method options to pass to the invoice's PaymentIntent.
             */
            sepa_debit?: Emptyable<PaymentMethodOptions.SepaDebit>;
            /**
             * This sub-hash contains details about the UPI payment method options to pass to the invoice's PaymentIntent.
             */
            upi?: Emptyable<PaymentMethodOptions.Upi>;
            /**
             * This sub-hash contains details about the ACH direct debit payment method options to pass to the invoice's PaymentIntent.
             */
            us_bank_account?: Emptyable<PaymentMethodOptions.UsBankAccount>;
        }
        type PaymentMethodType = 'ach_credit_transfer' | 'ach_debit' | 'acss_debit' | 'affirm' | 'alipay' | 'amazon_pay' | 'au_becs_debit' | 'bacs_debit' | 'bancontact' | 'billie' | 'boleto' | 'card' | 'cashapp' | 'crypto' | 'custom' | 'customer_balance' | 'eps' | 'fpx' | 'giropay' | 'grabpay' | 'ideal' | 'jp_credit_transfer' | 'kakao_pay' | 'klarna' | 'konbini' | 'kr_card' | 'link' | 'mb_way' | 'multibanco' | 'naver_pay' | 'nz_bank_account' | 'p24' | 'pay_by_bank' | 'payco' | 'paynow' | 'paypal' | 'payto' | 'pix' | 'promptpay' | 'revolut_pay' | 'satispay' | 'sepa_credit_transfer' | 'sepa_debit' | 'sofort' | 'swish' | 'twint' | 'upi' | 'us_bank_account' | 'wechat_pay' | OtherString;
        type SaveDefaultPaymentMethod = 'off' | 'on_subscription' | OtherString;
        namespace PaymentMethodOptions {
            interface AcssDebit {
                /**
                 * Additional fields for Mandate creation
                 */
                mandate_options?: AcssDebit.MandateOptions;
                /**
                 * Verification method for the intent
                 */
                verification_method?: AcssDebit.VerificationMethod;
            }
            interface Bancontact {
                /**
                 * Preferred language of the Bancontact authorization page that the customer is redirected to.
                 */
                preferred_language?: Bancontact.PreferredLanguage;
            }
            interface Billie {
            }
            interface Card {
                /**
                 * Configuration options for setting up an eMandate for cards issued in India.
                 */
                mandate_options?: Card.MandateOptions;
                /**
                 * Selected network to process this Subscription on. Depends on the available networks of the card attached to the Subscription. Can be only set confirm-time.
                 */
                network?: Card.Network;
                /**
                 * We strongly recommend that you rely on our SCA Engine to automatically prompt your customers for authentication based on risk level and [other requirements](https://docs.stripe.com/strong-customer-authentication). However, if you wish to request 3D Secure based on logic from your own fraud engine, provide this option. Read our guide on [manually requesting 3D Secure](https://docs.stripe.com/payments/3d-secure/authentication-flow#manual-three-ds) for more information on how this configuration interacts with Radar and our SCA Engine.
                 */
                request_three_d_secure?: Card.RequestThreeDSecure;
            }
            interface CustomerBalance {
                /**
                 * Configuration for the bank transfer funding type, if the `funding_type` is set to `bank_transfer`.
                 */
                bank_transfer?: CustomerBalance.BankTransfer;
                /**
                 * The funding method type to be used when there are not enough funds in the customer balance. Permitted values include: `bank_transfer`.
                 */
                funding_type?: string;
            }
            interface Konbini {
            }
            interface Payto {
                /**
                 * Additional fields for Mandate creation.
                 */
                mandate_options?: Payto.MandateOptions;
            }
            interface Pix {
                /**
                 * The number of seconds (between 10 and 1209600) after which Pix payment will expire. Defaults to 86400 seconds.
                 */
                expires_after_seconds?: number;
                /**
                 * Configuration options for setting up a mandate
                 */
                mandate_options?: Pix.MandateOptions;
            }
            interface SepaDebit {
            }
            interface Upi {
                /**
                 * Configuration options for setting up an eMandate
                 */
                mandate_options?: Upi.MandateOptions;
            }
            interface UsBankAccount {
                /**
                 * Additional fields for Financial Connections Session creation
                 */
                financial_connections?: UsBankAccount.FinancialConnections;
                /**
                 * Verification method for the intent
                 */
                verification_method?: UsBankAccount.VerificationMethod;
            }
            namespace AcssDebit {
                interface MandateOptions {
                    /**
                     * Transaction type of the mandate.
                     */
                    transaction_type?: MandateOptions.TransactionType;
                }
                type VerificationMethod = 'automatic' | 'instant' | 'microdeposits' | OtherString;
                namespace MandateOptions {
                    type TransactionType = 'business' | 'personal' | OtherString;
                }
            }
            namespace Bancontact {
                type PreferredLanguage = 'de' | 'en' | 'fr' | 'nl' | OtherString;
            }
            namespace Card {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments, specified in the presentment currency.
                     */
                    amount?: number;
                    /**
                     * One of `fixed` or `maximum`. If `fixed`, the `amount` param refers to the exact amount to be charged in future payments. If `maximum`, the amount charged can be up to the value passed for the `amount` param.
                     */
                    amount_type?: MandateOptions.AmountType;
                    /**
                     * A description of the mandate or subscription that is meant to be displayed to the customer.
                     */
                    description?: string;
                }
                type Network = 'amex' | 'cartes_bancaires' | 'diners' | 'discover' | 'eftpos_au' | 'girocard' | 'interac' | 'jcb' | 'link' | 'mastercard' | 'unionpay' | 'unknown' | 'visa' | OtherString;
                type RequestThreeDSecure = 'any' | 'automatic' | 'challenge' | OtherString;
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                }
            }
            namespace CustomerBalance {
                interface BankTransfer {
                    /**
                     * Configuration for eu_bank_transfer funding type.
                     */
                    eu_bank_transfer?: BankTransfer.EuBankTransfer;
                    /**
                     * The bank transfer type that can be used for funding. Permitted values include: `eu_bank_transfer`, `gb_bank_transfer`, `jp_bank_transfer`, `mx_bank_transfer`, or `us_bank_transfer`.
                     */
                    type?: string;
                }
                namespace BankTransfer {
                    interface EuBankTransfer {
                        /**
                         * The desired country code of the bank account information. Permitted values include: `DE`, `FR`, `IE`, or `NL`.
                         */
                        country: string;
                    }
                }
            }
            namespace Payto {
                interface MandateOptions {
                    /**
                     * The maximum amount that can be collected in a single invoice. If you don't specify a maximum, then there is no limit.
                     */
                    amount?: number;
                    /**
                     * The purpose for which payments are made. Has a default value based on your merchant category code.
                     */
                    purpose?: MandateOptions.Purpose;
                }
                namespace MandateOptions {
                    type Purpose = 'dependant_support' | 'government' | 'loan' | 'mortgage' | 'other' | 'pension' | 'personal' | 'retail' | 'salary' | 'tax' | 'utility' | OtherString;
                }
            }
            namespace Pix {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments. If not provided, defaults to 40000.
                     */
                    amount?: number;
                    /**
                     * Determines if the amount includes the IOF tax. Defaults to `never`.
                     */
                    amount_includes_iof?: MandateOptions.AmountIncludesIof;
                    /**
                     * Date when the mandate expires and no further payments will be charged, in `YYYY-MM-DD`. If not provided, the mandate will be active until canceled.
                     */
                    end_date?: string;
                    /**
                     * Schedule at which the future payments will be charged. Defaults to the subscription servicing interval.
                     */
                    payment_schedule?: MandateOptions.PaymentSchedule;
                }
                namespace MandateOptions {
                    type AmountIncludesIof = 'always' | 'never' | OtherString;
                    type PaymentSchedule = 'halfyearly' | 'monthly' | 'quarterly' | 'weekly' | 'yearly' | OtherString;
                }
            }
            namespace Upi {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments.
                     */
                    amount?: number;
                    /**
                     * One of `fixed` or `maximum`. If `fixed`, the `amount` param refers to the exact amount to be charged in future payments. If `maximum`, the amount charged can be up to the value passed for the `amount` param.
                     */
                    amount_type?: MandateOptions.AmountType;
                    /**
                     * A description of the mandate or subscription that is meant to be displayed to the customer.
                     */
                    description?: string;
                    /**
                     * End date of the mandate or subscription.
                     */
                    end_date?: number;
                }
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                }
            }
            namespace UsBankAccount {
                interface FinancialConnections {
                    /**
                     * Provide filters for the linked accounts that the customer can select for the payment method.
                     */
                    filters?: FinancialConnections.Filters;
                    /**
                     * The list of permissions to request. If this parameter is passed, the `payment_method` permission must be included. Valid permissions include: `balances`, `ownership`, `payment_method`, and `transactions`.
                     */
                    permissions?: Array<FinancialConnections.Permission>;
                    /**
                     * List of data features that you would like to retrieve upon account creation.
                     */
                    prefetch?: Array<FinancialConnections.Prefetch>;
                }
                type VerificationMethod = 'automatic' | 'instant' | 'microdeposits' | OtherString;
                namespace FinancialConnections {
                    interface Filters {
                        /**
                         * The account subcategories to use to filter for selectable accounts. Valid subcategories are `checking` and `savings`.
                         */
                        account_subcategories?: Array<Filters.AccountSubcategory>;
                    }
                    type Permission = 'balances' | 'ownership' | 'payment_method' | 'transactions' | OtherString;
                    type Prefetch = 'balances' | 'ownership' | 'transactions' | OtherString;
                    namespace Filters {
                        type AccountSubcategory = 'checking' | 'savings' | OtherString;
                    }
                }
            }
        }
    }
    namespace PendingInvoiceItemInterval {
        type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
    }
    namespace TrialSettings {
        interface EndBehavior {
            /**
             * Indicates how the subscription should change when the trial ends if the user did not provide a payment method.
             */
            missing_payment_method: EndBehavior.MissingPaymentMethod;
        }
        namespace EndBehavior {
            type MissingPaymentMethod = 'cancel' | 'create_invoice' | 'pause' | OtherString;
        }
    }
}
export interface SubscriptionRetrieveParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface SubscriptionUpdateParams {
    /**
     * A list of prices and quantities that will generate invoice items appended to the next invoice for this subscription. You may pass up to 20 items.
     */
    add_invoice_items?: Array<SubscriptionUpdateParams.AddInvoiceItem>;
    /**
     * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the application owner's Stripe account. The request must be made by a platform account on a connected account in order to set an application fee percentage. For more information, see the application fees [documentation](https://stripe.com/docs/connect/subscriptions#collecting-fees-on-subscriptions).
     */
    application_fee_percent?: Emptyable<number>;
    /**
     * Automatic tax settings for this subscription. We recommend you only include this parameter when the existing value is being changed.
     */
    automatic_tax?: SubscriptionUpdateParams.AutomaticTax;
    /**
     * Either `now` or `unchanged`. Setting the value to `now` resets the subscription's billing cycle anchor to the current time (in UTC). For more information, see the billing cycle [documentation](https://docs.stripe.com/billing/subscriptions/billing-cycle).
     */
    billing_cycle_anchor?: SubscriptionUpdateParams.BillingCycleAnchor;
    /**
     * An array of billing schedules, which allow you to bill customers in advance for multiple service periods. Requires flexible billing mode and API version 2026-05-27.dahlia or later. Learn more about [prebilling](https://docs.stripe.com/billing/subscriptions/prebilling).
     */
    billing_schedules?: Emptyable<Array<SubscriptionUpdateParams.BillingSchedule>>;
    /**
     * Define thresholds at which an invoice will be sent, and the subscription advanced to a new billing period. When updating, pass an empty string to remove previously-defined thresholds.
     */
    billing_thresholds?: Emptyable<SubscriptionUpdateParams.BillingThresholds>;
    /**
     * A timestamp at which the subscription should cancel. If set to a date before the current period ends, this will cause a proration if prorations have been enabled using `proration_behavior`. If set during a future period, this will always cause a proration for that period.
     */
    cancel_at?: Emptyable<number | SubscriptionUpdateParams.CancelAt>;
    /**
     * Indicate whether this subscription should cancel at the end of the current period (`current_period_end`).
     */
    cancel_at_period_end?: boolean;
    /**
     * Details about why this subscription was cancelled
     */
    cancellation_details?: SubscriptionUpdateParams.CancellationDetails;
    /**
     * Either `charge_automatically`, or `send_invoice`. When charging automatically, Stripe will attempt to pay this subscription at the end of the cycle using the default source attached to the customer. When sending an invoice, Stripe will email your customer an invoice with payment instructions and mark the subscription as `active`. Defaults to `charge_automatically`.
     */
    collection_method?: SubscriptionUpdateParams.CollectionMethod;
    /**
     * Number of days a customer has to pay invoices generated by this subscription. Valid only for subscriptions where `collection_method` is set to `send_invoice`.
     */
    days_until_due?: number;
    /**
     * ID of the default payment method for the subscription. It must belong to the customer associated with the subscription. This takes precedence over `default_source`. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).
     */
    default_payment_method?: string;
    /**
     * ID of the default payment source for the subscription. It must belong to the customer associated with the subscription and be in a chargeable state. If `default_payment_method` is also set, `default_payment_method` will take precedence. If neither are set, invoices will use the customer's [invoice_settings.default_payment_method](https://docs.stripe.com/api/customers/object#customer_object-invoice_settings-default_payment_method) or [default_source](https://docs.stripe.com/api/customers/object#customer_object-default_source).
     */
    default_source?: Emptyable<string>;
    /**
     * The tax rates that will apply to any subscription item that does not have `tax_rates` set. Invoices created will have their `default_tax_rates` populated from the subscription. Pass an empty string to remove previously-defined tax rates.
     */
    default_tax_rates?: Emptyable<Array<string>>;
    /**
     * The subscription's description, meant to be displayable to the customer. Use this field to optionally store an explanation of the subscription for rendering in Stripe surfaces and certain local payment methods UIs.
     */
    description?: Emptyable<string>;
    /**
     * The coupons to redeem into discounts for the subscription. A populated array overwrites the existing discounts on the subscription. If not specified or empty array, it leaves the subscription's discounts unchanged. If empty string, it clears the subscription's discounts.
     */
    discounts?: Emptyable<Array<SubscriptionUpdateParams.Discount>>;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * All invoices will be billed using the specified settings.
     */
    invoice_settings?: SubscriptionUpdateParams.InvoiceSettings;
    /**
     * A list of up to 20 subscription items, each with an attached price.
     */
    items?: Array<SubscriptionUpdateParams.Item>;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
     */
    metadata?: Emptyable<MetadataParam>;
    /**
     * Indicates if a customer is on or off-session while an invoice payment is attempted. Defaults to `false` (on-session).
     */
    off_session?: boolean;
    /**
     * The account on behalf of which to charge, for each of the subscription's invoices.
     */
    on_behalf_of?: Emptyable<string>;
    /**
     * If specified, payment collection for this subscription will be paused. Note that the subscription status will be unchanged and will not be updated to `paused`. Learn more about [pausing collection](https://docs.stripe.com/billing/subscriptions/pause-payment).
     */
    pause_collection?: Emptyable<SubscriptionUpdateParams.PauseCollection>;
    /**
     * Controls how Stripe handles payment when a subscription update requires payment and `collection_method=charge_automatically`.
     */
    payment_behavior?: SubscriptionUpdateParams.PaymentBehavior;
    /**
     * Payment settings to pass to invoices created by the subscription.
     */
    payment_settings?: SubscriptionUpdateParams.PaymentSettings;
    /**
     * Specifies an interval for how often to bill for any pending invoice items. It is analogous to calling [Create an invoice](https://docs.stripe.com/api/invoices/create) for the given subscription at the specified interval.
     */
    pending_invoice_item_interval?: Emptyable<SubscriptionUpdateParams.PendingInvoiceItemInterval>;
    /**
     * Determines how to handle [prorations](https://docs.stripe.com/billing/subscriptions/prorations) when the billing cycle changes (e.g., when switching plans, resetting `billing_cycle_anchor=now`, or starting a trial), or if an item's `quantity` changes. The default value is `create_prorations`.
     */
    proration_behavior?: SubscriptionUpdateParams.ProrationBehavior;
    /**
     * If set, prorations will be calculated as though the subscription was updated at the given time. This can be used to apply exactly the same prorations that were previewed with the [create preview](https://stripe.com/docs/api/invoices/create_preview) endpoint. `proration_date` can also be used to implement custom proration logic, such as prorating by day instead of by second, by providing the time that you wish to use for proration calculations.
     */
    proration_date?: number;
    /**
     * If specified, the funds from the subscription's invoices will be transferred to the destination and the ID of the resulting transfers will be found on the resulting charges. This will be unset if you POST an empty value.
     */
    transfer_data?: Emptyable<SubscriptionUpdateParams.TransferData>;
    /**
     * Unix timestamp representing the end of the trial period the customer will get before being charged for the first time. This will always overwrite any trials that might apply via a subscribed plan. If set, `trial_end` will override the default trial period of the plan the customer is being subscribed to. The `billing_cycle_anchor` will be updated to the `trial_end` value. The special value `now` can be provided to end the customer's trial immediately. Can be at most two years from `billing_cycle_anchor`.
     */
    trial_end?: 'now' | number;
    /**
     * Indicates if a plan's `trial_period_days` should be applied to the subscription. Setting `trial_end` per subscription is preferred, and this defaults to `false`. Setting this flag to `true` together with `trial_end` is not allowed. See [Using trial periods on subscriptions](https://docs.stripe.com/billing/subscriptions/trials) to learn more.
     */
    trial_from_plan?: boolean;
    /**
     * Settings related to subscription trials.
     */
    trial_settings?: SubscriptionUpdateParams.TrialSettings;
}
export declare namespace SubscriptionUpdateParams {
    interface AddInvoiceItem {
        /**
         * Controls whether discounts apply to this invoice item. Defaults to true if no value is provided.
         */
        discountable?: boolean;
        /**
         * The coupons to redeem into discounts for the item.
         */
        discounts?: Array<AddInvoiceItem.Discount>;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
         */
        metadata?: MetadataParam;
        /**
         * The period associated with this invoice item. If not set, `period.start.type` defaults to `max_item_period_start` and `period.end.type` defaults to `min_item_period_end`.
         */
        period?: AddInvoiceItem.Period;
        /**
         * The ID of the price object. One of `price` or `price_data` is required.
         */
        price?: string;
        /**
         * Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline. One of `price` or `price_data` is required.
         */
        price_data?: AddInvoiceItem.PriceData;
        /**
         * Quantity for this item. Defaults to 1.
         */
        quantity?: number;
        /**
         * The tax rates which apply to the item. When set, the `default_tax_rates` do not apply to this item.
         */
        tax_rates?: Emptyable<Array<string>>;
    }
    interface AutomaticTax {
        /**
         * Enabled automatic tax calculation which will automatically compute tax rates on all invoices generated by the subscription.
         */
        enabled: boolean;
        /**
         * The account that's liable for tax. If set, the business address and tax registrations required to perform the tax calculation are loaded from this account. The tax transaction is returned in the report of the connected account.
         */
        liability?: AutomaticTax.Liability;
    }
    type BillingCycleAnchor = 'now' | 'unchanged' | OtherString;
    interface BillingSchedule {
        /**
         * Configure billing schedule differently for individual subscription items.
         */
        applies_to?: Array<BillingSchedule.AppliesTo>;
        /**
         * The end date for the billing schedule. You must not set this earlier than current period end for every applicable subscription item.
         */
        bill_until?: BillingSchedule.BillUntil;
        /**
         * Specify a key for the billing schedule. Must be unique to this field, alphanumeric, and up to 200 characters. If not provided, a unique key will be generated.
         */
        key?: string;
    }
    interface BillingThresholds {
        /**
         * Monetary threshold that triggers the subscription to advance to a new billing period
         */
        amount_gte?: number;
        /**
         * Indicates if the `billing_cycle_anchor` should be reset when a threshold is reached. If true, `billing_cycle_anchor` will be updated to the date/time the threshold was last reached; otherwise, the value will remain unchanged.
         */
        reset_billing_cycle_anchor?: boolean;
    }
    type CancelAt = 'max_billed_until' | 'max_period_end' | 'min_period_end' | OtherString;
    interface CancellationDetails {
        /**
         * Additional comments about why the user canceled the subscription, if the subscription was canceled explicitly by the user.
         */
        comment?: Emptyable<string>;
        /**
         * The customer submitted reason for why they canceled, if the subscription was canceled explicitly by the user.
         */
        feedback?: Emptyable<CancellationDetails.Feedback>;
        /**
         * Customized feedback options that provide deeper insight into why the subscription was canceled, if the subscription was canceled explicitly by the user.
         */
        feedback_option?: string;
    }
    type CollectionMethod = 'charge_automatically' | 'send_invoice' | OtherString;
    interface Discount {
        /**
         * ID of the coupon to create a new discount for.
         */
        coupon?: string;
        /**
         * ID of an existing discount on the object (or one of its ancestors) to reuse.
         */
        discount?: string;
        /**
         * ID of the promotion code to create a new discount for.
         */
        promotion_code?: string;
    }
    interface InvoiceSettings {
        /**
         * The account tax IDs associated with the subscription. Will be set on invoices generated by the subscription.
         */
        account_tax_ids?: Emptyable<Array<string>>;
        /**
         * A list of up to 4 custom fields to be displayed on the invoice.
         */
        custom_fields?: Emptyable<Array<InvoiceSettings.CustomField>>;
        /**
         * An arbitrary string attached to the object. Often useful for displaying to users.
         */
        description?: Emptyable<string>;
        /**
         * Footer to be displayed on the invoice.
         */
        footer?: Emptyable<string>;
        /**
         * The connected account that issues the invoice. The invoice is presented with the branding and support information of the specified account.
         */
        issuer?: InvoiceSettings.Issuer;
    }
    interface Item {
        /**
         * Define thresholds at which an invoice will be sent, and the subscription advanced to a new billing period. Pass an empty string to remove previously-defined thresholds.
         */
        billing_thresholds?: Emptyable<Item.BillingThresholds>;
        /**
         * Delete all usage for a given subscription item. You must pass this when deleting a usage records subscription item. `clear_usage` has no effect if the plan has a billing meter attached.
         */
        clear_usage?: boolean;
        /**
         * A flag that, if set to `true`, will delete the specified item.
         */
        deleted?: boolean;
        /**
         * The coupons to redeem into discounts for the subscription item.
         */
        discounts?: Emptyable<Array<Item.Discount>>;
        /**
         * Subscription item to update. If you omit `id`, the API adds a new subscription item rather than updating the existing one. See [Changing a subscription's price](https://docs.stripe.com/billing/subscriptions/change-price#changing).
         */
        id?: string;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
         */
        metadata?: Emptyable<MetadataParam>;
        /**
         * Plan ID for this item, as a string.
         */
        plan?: string;
        /**
         * The ID of the price object. One of `price` or `price_data` is required. When changing a subscription item's price, `quantity` is set to 1 unless a `quantity` parameter is provided.
         */
        price?: string;
        /**
         * Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline. One of `price` or `price_data` is required.
         */
        price_data?: Item.PriceData;
        /**
         * Quantity for this item.
         */
        quantity?: number;
        /**
         * A list of [Tax Rate](https://docs.stripe.com/api/tax_rates) ids. These Tax Rates will override the [`default_tax_rates`](https://docs.stripe.com/api/subscriptions/create#create_subscription-default_tax_rates) on the Subscription. When updating, pass an empty string to remove previously-defined tax rates.
         */
        tax_rates?: Emptyable<Array<string>>;
    }
    interface PauseCollection {
        /**
         * The payment collection behavior for this subscription while paused.
         */
        behavior: PauseCollection.Behavior;
        /**
         * The time after which the subscription will resume collecting payments.
         */
        resumes_at?: number;
    }
    type PaymentBehavior = 'allow_incomplete' | 'default_incomplete' | 'error_if_incomplete' | 'pending_if_incomplete' | OtherString;
    interface PaymentSettings {
        /**
         * Payment-method-specific configuration to provide to invoices created by the subscription.
         */
        payment_method_options?: PaymentSettings.PaymentMethodOptions;
        /**
         * The list of payment method types (e.g. card) to provide to the invoice's PaymentIntent. If not set, Stripe attempts to automatically determine the types to use by looking at the invoice's default payment method, the subscription's default payment method, the customer's default payment method, and your [invoice template settings](https://dashboard.stripe.com/settings/billing/invoice). Should not be specified with payment_method_configuration
         */
        payment_method_types?: Emptyable<Array<PaymentSettings.PaymentMethodType>>;
        /**
         * Configure whether Stripe updates `subscription.default_payment_method` when payment succeeds. Defaults to `off` if unspecified.
         */
        save_default_payment_method?: PaymentSettings.SaveDefaultPaymentMethod;
    }
    interface PendingInvoiceItemInterval {
        /**
         * Specifies invoicing frequency. Either `day`, `week`, `month` or `year`.
         */
        interval: PendingInvoiceItemInterval.Interval;
        /**
         * The number of intervals between invoices. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of one year interval allowed (1 year, 12 months, or 52 weeks).
         */
        interval_count?: number;
    }
    type ProrationBehavior = 'always_invoice' | 'create_prorations' | 'none' | OtherString;
    interface TransferData {
        /**
         * A non-negative decimal between 0 and 100, with at most two decimal places. This represents the percentage of the subscription invoice total that will be transferred to the destination account. By default, the entire amount is transferred to the destination.
         */
        amount_percent?: number;
        /**
         * ID of an existing, connected Stripe account.
         */
        destination: string;
    }
    interface TrialSettings {
        /**
         * Defines how the subscription should behave when the user's free trial ends.
         */
        end_behavior: TrialSettings.EndBehavior;
    }
    namespace AddInvoiceItem {
        interface Discount {
            /**
             * ID of the coupon to create a new discount for.
             */
            coupon?: string;
            /**
             * ID of an existing discount on the object (or one of its ancestors) to reuse.
             */
            discount?: string;
            /**
             * ID of the promotion code to create a new discount for.
             */
            promotion_code?: string;
        }
        interface Period {
            /**
             * End of the invoice item period.
             */
            end: Period.End;
            /**
             * Start of the invoice item period.
             */
            start: Period.Start;
        }
        interface PriceData {
            /**
             * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
             */
            currency: string;
            /**
             * The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
             */
            product: string;
            /**
             * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
             */
            tax_behavior?: PriceData.TaxBehavior;
            /**
             * A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge or a negative integer representing the amount to credit to the customer.
             */
            unit_amount?: number;
            /**
             * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
             */
            unit_amount_decimal?: Decimal;
        }
        namespace Period {
            interface End {
                /**
                 * A precise Unix timestamp for the end of the invoice item period. Must be greater than or equal to `period.start`.
                 */
                timestamp?: number;
                /**
                 * Select how to calculate the end of the invoice item period.
                 */
                type: End.Type;
            }
            interface Start {
                /**
                 * A precise Unix timestamp for the start of the invoice item period. Must be less than or equal to `period.end`.
                 */
                timestamp?: number;
                /**
                 * Select how to calculate the start of the invoice item period.
                 */
                type: Start.Type;
            }
            namespace End {
                type Type = 'min_item_period_end' | 'timestamp' | OtherString;
            }
            namespace Start {
                type Type = 'max_item_period_start' | 'now' | 'timestamp' | OtherString;
            }
        }
        namespace PriceData {
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
        }
    }
    namespace AutomaticTax {
        interface Liability {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string;
            /**
             * Type of the account referenced in the request.
             */
            type: Liability.Type;
        }
        namespace Liability {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace BillingSchedule {
        interface AppliesTo {
            /**
             * The ID of the price object.
             */
            price?: string;
            /**
             * Controls which subscription items the billing schedule applies to.
             */
            type: 'price';
        }
        interface BillUntil {
            /**
             * Specifies the billing period.
             */
            duration?: BillUntil.Duration;
            /**
             * The end date of the billing schedule.
             */
            timestamp?: number;
            /**
             * Describes how the billing schedule will determine the end date. Either `duration` or `timestamp`.
             */
            type: BillUntil.Type;
        }
        namespace BillUntil {
            interface Duration {
                /**
                 * Specifies billing duration. Either `day`, `week`, `month` or `year`.
                 */
                interval: Duration.Interval;
                /**
                 * The multiplier applied to the interval.
                 */
                interval_count?: number;
            }
            type Type = 'duration' | 'timestamp' | OtherString;
            namespace Duration {
                type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
            }
        }
    }
    namespace CancellationDetails {
        type Feedback = 'customer_service' | 'low_quality' | 'missing_features' | 'other' | 'switched_service' | 'too_complex' | 'too_expensive' | 'unused' | OtherString;
    }
    namespace InvoiceSettings {
        interface CustomField {
            /**
             * The name of the custom field. This may be up to 40 characters.
             */
            name: string;
            /**
             * The value of the custom field. This may be up to 140 characters.
             */
            value: string;
        }
        interface Issuer {
            /**
             * The connected account being referenced when `type` is `account`.
             */
            account?: string;
            /**
             * Type of the account referenced in the request.
             */
            type: Issuer.Type;
        }
        namespace Issuer {
            type Type = 'account' | 'self' | OtherString;
        }
    }
    namespace Item {
        interface BillingThresholds {
            /**
             * Number of units that meets the billing threshold to advance the subscription to a new billing period (e.g., it takes 10 $5 units to meet a $50 [monetary threshold](https://docs.stripe.com/api/subscriptions/update#update_subscription-billing_thresholds-amount_gte))
             */
            usage_gte: number;
        }
        interface Discount {
            /**
             * ID of the coupon to create a new discount for.
             */
            coupon?: string;
            /**
             * ID of an existing discount on the object (or one of its ancestors) to reuse.
             */
            discount?: string;
            /**
             * ID of the promotion code to create a new discount for.
             */
            promotion_code?: string;
        }
        interface PriceData {
            /**
             * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
             */
            currency: string;
            /**
             * The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
             */
            product: string;
            /**
             * The recurring components of a price such as `interval` and `interval_count`.
             */
            recurring: PriceData.Recurring;
            /**
             * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
             */
            tax_behavior?: PriceData.TaxBehavior;
            /**
             * A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge.
             */
            unit_amount?: number;
            /**
             * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
             */
            unit_amount_decimal?: Decimal;
        }
        namespace PriceData {
            interface Recurring {
                /**
                 * Specifies billing frequency. Either `day`, `week`, `month` or `year`.
                 */
                interval: Recurring.Interval;
                /**
                 * The number of intervals between subscription billings. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of three years interval allowed (3 years, 36 months, or 156 weeks).
                 */
                interval_count?: number;
            }
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
            namespace Recurring {
                type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
            }
        }
    }
    namespace PauseCollection {
        type Behavior = 'keep_as_draft' | 'mark_uncollectible' | 'void' | OtherString;
    }
    namespace PaymentSettings {
        interface PaymentMethodOptions {
            /**
             * This sub-hash contains details about the Canadian pre-authorized debit payment method options to pass to the invoice's PaymentIntent.
             */
            acss_debit?: Emptyable<PaymentMethodOptions.AcssDebit>;
            /**
             * This sub-hash contains details about the Bancontact payment method options to pass to the invoice's PaymentIntent.
             */
            bancontact?: Emptyable<PaymentMethodOptions.Bancontact>;
            /**
             * This sub-hash contains details about the Billie payment method options to pass to the invoice's PaymentIntent.
             */
            billie?: Emptyable<PaymentMethodOptions.Billie>;
            /**
             * This sub-hash contains details about the Card payment method options to pass to the invoice's PaymentIntent.
             */
            card?: Emptyable<PaymentMethodOptions.Card>;
            /**
             * This sub-hash contains details about the Bank transfer payment method options to pass to the invoice's PaymentIntent.
             */
            customer_balance?: Emptyable<PaymentMethodOptions.CustomerBalance>;
            /**
             * This sub-hash contains details about the Konbini payment method options to pass to the invoice's PaymentIntent.
             */
            konbini?: Emptyable<PaymentMethodOptions.Konbini>;
            /**
             * This sub-hash contains details about the PayTo payment method options to pass to the invoice's PaymentIntent.
             */
            payto?: Emptyable<PaymentMethodOptions.Payto>;
            /**
             * This sub-hash contains details about the Pix payment method options to pass to the invoice's PaymentIntent.
             */
            pix?: Emptyable<PaymentMethodOptions.Pix>;
            /**
             * This sub-hash contains details about the SEPA Direct Debit payment method options to pass to the invoice's PaymentIntent.
             */
            sepa_debit?: Emptyable<PaymentMethodOptions.SepaDebit>;
            /**
             * This sub-hash contains details about the UPI payment method options to pass to the invoice's PaymentIntent.
             */
            upi?: Emptyable<PaymentMethodOptions.Upi>;
            /**
             * This sub-hash contains details about the ACH direct debit payment method options to pass to the invoice's PaymentIntent.
             */
            us_bank_account?: Emptyable<PaymentMethodOptions.UsBankAccount>;
        }
        type PaymentMethodType = 'ach_credit_transfer' | 'ach_debit' | 'acss_debit' | 'affirm' | 'alipay' | 'amazon_pay' | 'au_becs_debit' | 'bacs_debit' | 'bancontact' | 'billie' | 'boleto' | 'card' | 'cashapp' | 'crypto' | 'custom' | 'customer_balance' | 'eps' | 'fpx' | 'giropay' | 'grabpay' | 'ideal' | 'jp_credit_transfer' | 'kakao_pay' | 'klarna' | 'konbini' | 'kr_card' | 'link' | 'mb_way' | 'multibanco' | 'naver_pay' | 'nz_bank_account' | 'p24' | 'pay_by_bank' | 'payco' | 'paynow' | 'paypal' | 'payto' | 'pix' | 'promptpay' | 'revolut_pay' | 'satispay' | 'sepa_credit_transfer' | 'sepa_debit' | 'sofort' | 'swish' | 'twint' | 'upi' | 'us_bank_account' | 'wechat_pay' | OtherString;
        type SaveDefaultPaymentMethod = 'off' | 'on_subscription' | OtherString;
        namespace PaymentMethodOptions {
            interface AcssDebit {
                /**
                 * Additional fields for Mandate creation
                 */
                mandate_options?: AcssDebit.MandateOptions;
                /**
                 * Verification method for the intent
                 */
                verification_method?: AcssDebit.VerificationMethod;
            }
            interface Bancontact {
                /**
                 * Preferred language of the Bancontact authorization page that the customer is redirected to.
                 */
                preferred_language?: Bancontact.PreferredLanguage;
            }
            interface Billie {
            }
            interface Card {
                /**
                 * Configuration options for setting up an eMandate for cards issued in India.
                 */
                mandate_options?: Card.MandateOptions;
                /**
                 * Selected network to process this Subscription on. Depends on the available networks of the card attached to the Subscription. Can be only set confirm-time.
                 */
                network?: Card.Network;
                /**
                 * We strongly recommend that you rely on our SCA Engine to automatically prompt your customers for authentication based on risk level and [other requirements](https://docs.stripe.com/strong-customer-authentication). However, if you wish to request 3D Secure based on logic from your own fraud engine, provide this option. Read our guide on [manually requesting 3D Secure](https://docs.stripe.com/payments/3d-secure/authentication-flow#manual-three-ds) for more information on how this configuration interacts with Radar and our SCA Engine.
                 */
                request_three_d_secure?: Card.RequestThreeDSecure;
            }
            interface CustomerBalance {
                /**
                 * Configuration for the bank transfer funding type, if the `funding_type` is set to `bank_transfer`.
                 */
                bank_transfer?: CustomerBalance.BankTransfer;
                /**
                 * The funding method type to be used when there are not enough funds in the customer balance. Permitted values include: `bank_transfer`.
                 */
                funding_type?: string;
            }
            interface Konbini {
            }
            interface Payto {
                /**
                 * Additional fields for Mandate creation.
                 */
                mandate_options?: Payto.MandateOptions;
            }
            interface Pix {
                /**
                 * The number of seconds (between 10 and 1209600) after which Pix payment will expire. Defaults to 86400 seconds.
                 */
                expires_after_seconds?: number;
                /**
                 * Configuration options for setting up a mandate
                 */
                mandate_options?: Pix.MandateOptions;
            }
            interface SepaDebit {
            }
            interface Upi {
                /**
                 * Configuration options for setting up an eMandate
                 */
                mandate_options?: Upi.MandateOptions;
            }
            interface UsBankAccount {
                /**
                 * Additional fields for Financial Connections Session creation
                 */
                financial_connections?: UsBankAccount.FinancialConnections;
                /**
                 * Verification method for the intent
                 */
                verification_method?: UsBankAccount.VerificationMethod;
            }
            namespace AcssDebit {
                interface MandateOptions {
                    /**
                     * Transaction type of the mandate.
                     */
                    transaction_type?: MandateOptions.TransactionType;
                }
                type VerificationMethod = 'automatic' | 'instant' | 'microdeposits' | OtherString;
                namespace MandateOptions {
                    type TransactionType = 'business' | 'personal' | OtherString;
                }
            }
            namespace Bancontact {
                type PreferredLanguage = 'de' | 'en' | 'fr' | 'nl' | OtherString;
            }
            namespace Card {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments, specified in the presentment currency.
                     */
                    amount?: number;
                    /**
                     * One of `fixed` or `maximum`. If `fixed`, the `amount` param refers to the exact amount to be charged in future payments. If `maximum`, the amount charged can be up to the value passed for the `amount` param.
                     */
                    amount_type?: MandateOptions.AmountType;
                    /**
                     * A description of the mandate or subscription that is meant to be displayed to the customer.
                     */
                    description?: string;
                }
                type Network = 'amex' | 'cartes_bancaires' | 'diners' | 'discover' | 'eftpos_au' | 'girocard' | 'interac' | 'jcb' | 'link' | 'mastercard' | 'unionpay' | 'unknown' | 'visa' | OtherString;
                type RequestThreeDSecure = 'any' | 'automatic' | 'challenge' | OtherString;
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                }
            }
            namespace CustomerBalance {
                interface BankTransfer {
                    /**
                     * Configuration for eu_bank_transfer funding type.
                     */
                    eu_bank_transfer?: BankTransfer.EuBankTransfer;
                    /**
                     * The bank transfer type that can be used for funding. Permitted values include: `eu_bank_transfer`, `gb_bank_transfer`, `jp_bank_transfer`, `mx_bank_transfer`, or `us_bank_transfer`.
                     */
                    type?: string;
                }
                namespace BankTransfer {
                    interface EuBankTransfer {
                        /**
                         * The desired country code of the bank account information. Permitted values include: `DE`, `FR`, `IE`, or `NL`.
                         */
                        country: string;
                    }
                }
            }
            namespace Payto {
                interface MandateOptions {
                    /**
                     * The maximum amount that can be collected in a single invoice. If you don't specify a maximum, then there is no limit.
                     */
                    amount?: number;
                    /**
                     * The purpose for which payments are made. Has a default value based on your merchant category code.
                     */
                    purpose?: MandateOptions.Purpose;
                }
                namespace MandateOptions {
                    type Purpose = 'dependant_support' | 'government' | 'loan' | 'mortgage' | 'other' | 'pension' | 'personal' | 'retail' | 'salary' | 'tax' | 'utility' | OtherString;
                }
            }
            namespace Pix {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments. If not provided, defaults to 40000.
                     */
                    amount?: number;
                    /**
                     * Determines if the amount includes the IOF tax. Defaults to `never`.
                     */
                    amount_includes_iof?: MandateOptions.AmountIncludesIof;
                    /**
                     * Date when the mandate expires and no further payments will be charged, in `YYYY-MM-DD`. If not provided, the mandate will be active until canceled.
                     */
                    end_date?: string;
                    /**
                     * Schedule at which the future payments will be charged. Defaults to the subscription servicing interval.
                     */
                    payment_schedule?: MandateOptions.PaymentSchedule;
                }
                namespace MandateOptions {
                    type AmountIncludesIof = 'always' | 'never' | OtherString;
                    type PaymentSchedule = 'halfyearly' | 'monthly' | 'quarterly' | 'weekly' | 'yearly' | OtherString;
                }
            }
            namespace Upi {
                interface MandateOptions {
                    /**
                     * Amount to be charged for future payments.
                     */
                    amount?: number;
                    /**
                     * One of `fixed` or `maximum`. If `fixed`, the `amount` param refers to the exact amount to be charged in future payments. If `maximum`, the amount charged can be up to the value passed for the `amount` param.
                     */
                    amount_type?: MandateOptions.AmountType;
                    /**
                     * A description of the mandate or subscription that is meant to be displayed to the customer.
                     */
                    description?: string;
                    /**
                     * End date of the mandate or subscription.
                     */
                    end_date?: number;
                }
                namespace MandateOptions {
                    type AmountType = 'fixed' | 'maximum' | OtherString;
                }
            }
            namespace UsBankAccount {
                interface FinancialConnections {
                    /**
                     * Provide filters for the linked accounts that the customer can select for the payment method.
                     */
                    filters?: FinancialConnections.Filters;
                    /**
                     * The list of permissions to request. If this parameter is passed, the `payment_method` permission must be included. Valid permissions include: `balances`, `ownership`, `payment_method`, and `transactions`.
                     */
                    permissions?: Array<FinancialConnections.Permission>;
                    /**
                     * List of data features that you would like to retrieve upon account creation.
                     */
                    prefetch?: Array<FinancialConnections.Prefetch>;
                }
                type VerificationMethod = 'automatic' | 'instant' | 'microdeposits' | OtherString;
                namespace FinancialConnections {
                    interface Filters {
                        /**
                         * The account subcategories to use to filter for selectable accounts. Valid subcategories are `checking` and `savings`.
                         */
                        account_subcategories?: Array<Filters.AccountSubcategory>;
                    }
                    type Permission = 'balances' | 'ownership' | 'payment_method' | 'transactions' | OtherString;
                    type Prefetch = 'balances' | 'ownership' | 'transactions' | OtherString;
                    namespace Filters {
                        type AccountSubcategory = 'checking' | 'savings' | OtherString;
                    }
                }
            }
        }
    }
    namespace PendingInvoiceItemInterval {
        type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
    }
    namespace TrialSettings {
        interface EndBehavior {
            /**
             * Indicates how the subscription should change when the trial ends if the user did not provide a payment method.
             */
            missing_payment_method: EndBehavior.MissingPaymentMethod;
        }
        namespace EndBehavior {
            type MissingPaymentMethod = 'cancel' | 'create_invoice' | 'pause' | OtherString;
        }
    }
}
export interface SubscriptionListParams extends PaginationParams {
    /**
     * Filter subscriptions by their automatic tax settings.
     */
    automatic_tax?: SubscriptionListParams.AutomaticTax;
    /**
     * The collection method of the subscriptions to retrieve. Either `charge_automatically` or `send_invoice`.
     */
    collection_method?: SubscriptionListParams.CollectionMethod;
    /**
     * Only return subscriptions that were created during the given date interval.
     */
    created?: RangeQueryParam | number;
    /**
     * Only return subscriptions whose minimum item current_period_end falls within the given date interval.
     */
    current_period_end?: RangeQueryParam | number;
    /**
     * Only return subscriptions whose maximum item current_period_start falls within the given date interval.
     */
    current_period_start?: RangeQueryParam | number;
    /**
     * The ID of the customer whose subscriptions you're retrieving.
     */
    customer?: string;
    /**
     * The ID of the account representing the customer whose subscriptions you're retrieving.
     */
    customer_account?: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * The ID of the plan whose subscriptions will be retrieved.
     */
    plan?: string;
    /**
     * Filter for subscriptions that contain this recurring price ID.
     */
    price?: string;
    /**
     * The status of the subscriptions to retrieve. Passing in a value of `canceled` will return all canceled subscriptions, including those belonging to deleted customers. Pass `ended` to find subscriptions that are canceled and subscriptions that are expired due to [incomplete payment](https://docs.stripe.com/billing/subscriptions/overview#subscription-statuses). Passing in a value of `all` will return subscriptions of all statuses. If no value is supplied, all subscriptions that have not been canceled are returned.
     */
    status?: SubscriptionListParams.Status;
    /**
     * Filter for subscriptions that are associated with the specified test clock. The response will not include subscriptions with test clocks if this and the customer parameter is not set.
     */
    test_clock?: string;
}
export declare namespace SubscriptionListParams {
    interface AutomaticTax {
        /**
         * Enabled automatic tax calculation which will automatically compute tax rates on all invoices generated by the subscription.
         */
        enabled: boolean;
    }
    type CollectionMethod = 'charge_automatically' | 'send_invoice' | OtherString;
    type Status = 'active' | 'all' | 'canceled' | 'ended' | 'incomplete' | 'incomplete_expired' | 'past_due' | 'paused' | 'trialing' | 'unpaid' | OtherString;
}
export interface SubscriptionCancelParams {
    /**
     * Details about why this subscription was cancelled
     */
    cancellation_details?: SubscriptionCancelParams.CancellationDetails;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * Will generate a final invoice that invoices for any un-invoiced metered usage and new/pending proration invoice items. Defaults to `false`.
     */
    invoice_now?: boolean;
    /**
     * Will generate a proration invoice item that credits remaining unused time until the subscription period end. Defaults to `false`.
     */
    prorate?: boolean;
}
export declare namespace SubscriptionCancelParams {
    interface CancellationDetails {
        /**
         * Additional comments about why the user canceled the subscription, if the subscription was canceled explicitly by the user.
         */
        comment?: Emptyable<string>;
        /**
         * The customer submitted reason for why they canceled, if the subscription was canceled explicitly by the user.
         */
        feedback?: Emptyable<CancellationDetails.Feedback>;
        /**
         * Customized feedback options that provide deeper insight into why the subscription was canceled, if the subscription was canceled explicitly by the user.
         */
        feedback_option?: string;
    }
    namespace CancellationDetails {
        type Feedback = 'customer_service' | 'low_quality' | 'missing_features' | 'other' | 'switched_service' | 'too_complex' | 'too_expensive' | 'unused' | OtherString;
    }
}
export interface SubscriptionDeleteDiscountParams {
}
export interface SubscriptionMigrateParams {
    /**
     * Controls how prorations and invoices for subscriptions are calculated and orchestrated.
     */
    billing_mode: SubscriptionMigrateParams.BillingMode;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export declare namespace SubscriptionMigrateParams {
    interface BillingMode {
        /**
         * Configure behavior for flexible billing mode.
         */
        flexible?: BillingMode.Flexible;
        /**
         * Controls the calculation and orchestration of prorations and invoices for subscriptions.
         */
        type: 'flexible';
    }
    namespace BillingMode {
        interface Flexible {
            /**
             * Controls how invoices and invoice items display proration amounts and discount amounts.
             */
            proration_discounts?: Flexible.ProrationDiscounts;
        }
        namespace Flexible {
            type ProrationDiscounts = 'included' | 'itemized' | OtherString;
        }
    }
}
export interface SubscriptionResumeParams {
    /**
     * The billing cycle anchor that applies when the subscription is resumed. Either `now` or `unchanged`. The default is `now`. For more information, see the billing cycle [documentation](https://docs.stripe.com/billing/subscriptions/billing-cycle).
     */
    billing_cycle_anchor?: SubscriptionResumeParams.BillingCycleAnchor;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * Determines how to handle [prorations](https://docs.stripe.com/billing/subscriptions/prorations) resulting from the `billing_cycle_anchor` being `unchanged`. When the `billing_cycle_anchor` is set to `now` (default value), no prorations are generated. If no value is passed, the default is `create_prorations`.
     */
    proration_behavior?: SubscriptionResumeParams.ProrationBehavior;
    /**
     * If set, prorations will be calculated as though the subscription was resumed at the given time. This can be used to apply exactly the same prorations that were previewed with the [create preview](https://stripe.com/docs/api/invoices/create_preview) endpoint.
     */
    proration_date?: number;
}
export declare namespace SubscriptionResumeParams {
    type BillingCycleAnchor = 'now' | 'unchanged' | OtherString;
    type ProrationBehavior = 'always_invoice' | 'create_prorations' | 'none' | OtherString;
}
export interface SubscriptionSearchParams {
    /**
     * The search query string. See [search query language](https://docs.stripe.com/search#search-query-language) and the list of supported [query fields for subscriptions](https://docs.stripe.com/search#query-fields-for-subscriptions).
     */
    query: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * A limit on the number of objects to be returned. Limit can range between 1 and 100, and the default is 10.
     */
    limit?: number;
    /**
     * A cursor for pagination across multiple pages of results. Don't include this parameter on the first call. Use the next_page value returned in a previous response to request subsequent results.
     */
    page?: string;
}
