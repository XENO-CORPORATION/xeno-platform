export interface MeterEventSummary {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'billing.meter_event_summary';
    /**
     * Aggregated value of all the events within `start_time` (inclusive) and `end_time` (inclusive). The aggregation strategy is defined on meter via `default_aggregation`.
     */
    aggregated_value: number;
    /**
     * End timestamp for this event summary (exclusive). Must be aligned with minute boundaries.
     */
    end_time: number;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * The meter associated with this event summary.
     */
    meter: string;
    /**
     * Start timestamp for this event summary (inclusive). Must be aligned with minute boundaries.
     */
    start_time: number;
}
