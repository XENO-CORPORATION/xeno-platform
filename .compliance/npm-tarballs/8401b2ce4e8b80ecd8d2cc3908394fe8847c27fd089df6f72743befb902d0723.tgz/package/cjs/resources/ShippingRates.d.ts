import { StripeResource } from '../StripeResource.js';
import { TaxCode } from './TaxCodes.js';
import { MetadataParam, OtherString, Emptyable, PaginationParams, RangeQueryParam, Metadata } from '../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../lib.js';
export declare class ShippingRateResource extends StripeResource {
    /**
     * Returns a list of your shipping rates.
     */
    list(params?: ShippingRateListParams, options?: RequestOptions): ApiListPromise<ShippingRate>;
    /**
     * Creates a new shipping rate object.
     */
    create(params: ShippingRateCreateParams, options?: RequestOptions): Promise<Response<ShippingRate>>;
    /**
     * Returns the shipping rate object with the given ID.
     */
    retrieve(id: string, params?: ShippingRateRetrieveParams, options?: RequestOptions): Promise<Response<ShippingRate>>;
    /**
     * Updates an existing shipping rate object.
     */
    update(id: string, params?: ShippingRateUpdateParams, options?: RequestOptions): Promise<Response<ShippingRate>>;
}
export interface ShippingRate {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'shipping_rate';
    /**
     * Whether the shipping rate can be used for new purchases. Defaults to `true`.
     */
    active: boolean;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * The estimated range for how long shipping will take, meant to be displayable to the customer. This will appear on CheckoutSessions.
     */
    delivery_estimate: ShippingRate.DeliveryEstimate | null;
    /**
     * The name of the shipping rate, meant to be displayable to the customer. This will appear on CheckoutSessions.
     */
    display_name: string | null;
    fixed_amount?: ShippingRate.FixedAmount;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
     */
    metadata: Metadata;
    /**
     * Specifies whether the rate is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`.
     */
    tax_behavior: ShippingRate.TaxBehavior | null;
    /**
     * A [tax code](https://docs.stripe.com/tax/tax-categories) ID. The Shipping tax code is `txcd_92010001`.
     */
    tax_code: string | TaxCode | null;
    /**
     * The type of calculation to use on the shipping rate.
     */
    type: 'fixed_amount';
}
export declare namespace ShippingRate {
    interface DeliveryEstimate {
        /**
         * The upper bound of the estimated range. If empty, represents no upper bound i.e., infinite.
         */
        maximum: DeliveryEstimate.Maximum | null;
        /**
         * The lower bound of the estimated range. If empty, represents no lower bound.
         */
        minimum: DeliveryEstimate.Minimum | null;
    }
    interface FixedAmount {
        /**
         * A non-negative integer in cents representing how much to charge.
         */
        amount: number;
        /**
         * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
         */
        currency: string;
        /**
         * Shipping rates defined in each available currency option. Each key must be a three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html) and a [supported currency](https://stripe.com/docs/currencies).
         */
        currency_options?: {
            [key: string]: FixedAmount.CurrencyOptions;
        };
    }
    type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
    namespace DeliveryEstimate {
        interface Maximum {
            /**
             * A unit of time.
             */
            unit: Maximum.Unit;
            /**
             * Must be greater than 0.
             */
            value: number;
        }
        interface Minimum {
            /**
             * A unit of time.
             */
            unit: Minimum.Unit;
            /**
             * Must be greater than 0.
             */
            value: number;
        }
        namespace Maximum {
            type Unit = 'business_day' | 'day' | 'hour' | 'month' | 'week' | OtherString;
        }
        namespace Minimum {
            type Unit = 'business_day' | 'day' | 'hour' | 'month' | 'week' | OtherString;
        }
    }
    namespace FixedAmount {
        interface CurrencyOptions {
            /**
             * A non-negative integer in cents representing how much to charge.
             */
            amount: number;
            /**
             * Specifies whether the rate is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`.
             */
            tax_behavior: CurrencyOptions.TaxBehavior;
        }
        namespace CurrencyOptions {
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
        }
    }
}
export interface ShippingRateCreateParams {
    /**
     * The name of the shipping rate, meant to be displayable to the customer. This will appear on CheckoutSessions.
     */
    display_name: string;
    /**
     * The estimated range for how long shipping will take, meant to be displayable to the customer. This will appear on CheckoutSessions.
     */
    delivery_estimate?: ShippingRateCreateParams.DeliveryEstimate;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * Describes a fixed amount to charge for shipping. Must be present if type is `fixed_amount`.
     */
    fixed_amount?: ShippingRateCreateParams.FixedAmount;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
     */
    metadata?: MetadataParam;
    /**
     * Specifies whether the rate is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`.
     */
    tax_behavior?: ShippingRateCreateParams.TaxBehavior;
    /**
     * A [tax code](https://docs.stripe.com/tax/tax-categories) ID. The Shipping tax code is `txcd_92010001`.
     */
    tax_code?: string;
    /**
     * The type of calculation to use on the shipping rate.
     */
    type?: 'fixed_amount';
}
export declare namespace ShippingRateCreateParams {
    interface DeliveryEstimate {
        /**
         * The upper bound of the estimated range. If empty, represents no upper bound i.e., infinite.
         */
        maximum?: DeliveryEstimate.Maximum;
        /**
         * The lower bound of the estimated range. If empty, represents no lower bound.
         */
        minimum?: DeliveryEstimate.Minimum;
    }
    interface FixedAmount {
        /**
         * A non-negative integer in cents representing how much to charge.
         */
        amount: number;
        /**
         * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
         */
        currency: string;
        /**
         * Shipping rates defined in each available currency option. Each key must be a three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html) and a [supported currency](https://stripe.com/docs/currencies).
         */
        currency_options?: {
            [key: string]: FixedAmount.CurrencyOptions;
        };
    }
    type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
    namespace DeliveryEstimate {
        interface Maximum {
            /**
             * A unit of time.
             */
            unit: Maximum.Unit;
            /**
             * Must be greater than 0.
             */
            value: number;
        }
        interface Minimum {
            /**
             * A unit of time.
             */
            unit: Minimum.Unit;
            /**
             * Must be greater than 0.
             */
            value: number;
        }
        namespace Maximum {
            type Unit = 'business_day' | 'day' | 'hour' | 'month' | 'week' | OtherString;
        }
        namespace Minimum {
            type Unit = 'business_day' | 'day' | 'hour' | 'month' | 'week' | OtherString;
        }
    }
    namespace FixedAmount {
        interface CurrencyOptions {
            /**
             * A non-negative integer in cents representing how much to charge.
             */
            amount: number;
            /**
             * Specifies whether the rate is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`.
             */
            tax_behavior?: CurrencyOptions.TaxBehavior;
        }
        namespace CurrencyOptions {
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
        }
    }
}
export interface ShippingRateRetrieveParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface ShippingRateUpdateParams {
    /**
     * Whether the shipping rate can be used for new purchases. Defaults to `true`.
     */
    active?: boolean;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * Describes a fixed amount to charge for shipping. Must be present if type is `fixed_amount`.
     */
    fixed_amount?: ShippingRateUpdateParams.FixedAmount;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
     */
    metadata?: Emptyable<MetadataParam>;
    /**
     * Specifies whether the rate is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`.
     */
    tax_behavior?: ShippingRateUpdateParams.TaxBehavior;
}
export declare namespace ShippingRateUpdateParams {
    interface FixedAmount {
        /**
         * Shipping rates defined in each available currency option. Each key must be a three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html) and a [supported currency](https://stripe.com/docs/currencies).
         */
        currency_options?: {
            [key: string]: FixedAmount.CurrencyOptions;
        };
    }
    type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
    namespace FixedAmount {
        interface CurrencyOptions {
            /**
             * A non-negative integer in cents representing how much to charge.
             */
            amount?: number;
            /**
             * Specifies whether the rate is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`.
             */
            tax_behavior?: CurrencyOptions.TaxBehavior;
        }
        namespace CurrencyOptions {
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
        }
    }
}
export interface ShippingRateListParams extends PaginationParams {
    /**
     * Only return shipping rates that are active or inactive.
     */
    active?: boolean;
    /**
     * A filter on the list, based on the object `created` field. The value can be a string with an integer Unix timestamp, or it can be a dictionary with a number of different query options.
     */
    created?: RangeQueryParam | number;
    /**
     * Only return shipping rates for the given currency.
     */
    currency?: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
