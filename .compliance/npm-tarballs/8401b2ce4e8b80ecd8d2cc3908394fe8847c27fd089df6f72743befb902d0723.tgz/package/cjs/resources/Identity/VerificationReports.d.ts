import { StripeResource } from '../../StripeResource.js';
import { PaginationParams, RangeQueryParam, OtherString, Address } from '../../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../../lib.js';
export declare class VerificationReportResource extends StripeResource {
    /**
     * List all verification reports.
     */
    list(params?: Identity.VerificationReportListParams, options?: RequestOptions): ApiListPromise<VerificationReport>;
    /**
     * Retrieves an existing VerificationReport
     */
    retrieve(id: string, params?: Identity.VerificationReportRetrieveParams, options?: RequestOptions): Promise<Response<VerificationReport>>;
}
export interface VerificationReport {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'identity.verification_report';
    /**
     * A string to reference this user. This can be a customer ID, a session ID, or similar, and can be used to reconcile this verification with your internal systems.
     */
    client_reference_id: string | null;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * Result from a document check
     */
    document?: VerificationReport.Document;
    /**
     * Result from a email check
     */
    email?: VerificationReport.Email;
    /**
     * Result from an id_number check
     */
    id_number?: VerificationReport.IdNumber;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    options?: VerificationReport.Options;
    /**
     * Result from a phone check
     */
    phone?: VerificationReport.Phone;
    /**
     * Result from a selfie check
     */
    selfie?: VerificationReport.Selfie;
    /**
     * Type of report.
     */
    type: VerificationReport.Type;
    /**
     * The configuration token of a verification flow from the dashboard.
     */
    verification_flow?: string;
    /**
     * ID of the VerificationSession that created this report.
     */
    verification_session: string | null;
}
export declare namespace VerificationReport {
    interface Document {
        /**
         * Address as it appears in the document.
         */
        address: Address | null;
        /**
         * Date of birth as it appears in the document.
         */
        dob?: Document.Dob | null;
        /**
         * Details on the verification error. Present when status is `unverified`.
         */
        error: Document.Error | null;
        /**
         * Expiration date of the document.
         */
        expiration_date?: Document.ExpirationDate | null;
        /**
         * Array of [File](https://docs.stripe.com/api/files) ids containing images for this document.
         */
        files: Array<string> | null;
        /**
         * First name as it appears in the document.
         */
        first_name: string | null;
        /**
         * Issued date of the document.
         */
        issued_date: Document.IssuedDate | null;
        /**
         * Issuing country of the document.
         */
        issuing_country: string | null;
        /**
         * Last name as it appears in the document.
         */
        last_name: string | null;
        /**
         * Document ID number.
         */
        number?: string | null;
        /**
         * Sex of the person in the document.
         */
        sex?: Document.Sex | null;
        /**
         * Status of this `document` check.
         */
        status: Document.Status;
        /**
         * Type of the document.
         */
        type: Document.Type | null;
        /**
         * Place of birth as it appears in the document.
         */
        unparsed_place_of_birth?: string | null;
        /**
         * Sex as it appears in the document.
         */
        unparsed_sex?: string | null;
    }
    interface Email {
        /**
         * Email to be verified.
         */
        email: string | null;
        /**
         * Details on the verification error. Present when status is `unverified`.
         */
        error: Email.Error | null;
        /**
         * Status of this `email` check.
         */
        status: Email.Status;
    }
    interface IdNumber {
        /**
         * Date of birth.
         */
        dob?: IdNumber.Dob | null;
        /**
         * Details on the verification error. Present when status is `unverified`.
         */
        error: IdNumber.Error | null;
        /**
         * First name.
         */
        first_name: string | null;
        /**
         * ID number. When `id_number_type` is `us_ssn`, only the last 4 digits are present.
         */
        id_number?: string | null;
        /**
         * Type of ID number.
         */
        id_number_type: IdNumber.IdNumberType | null;
        /**
         * Last name.
         */
        last_name: string | null;
        /**
         * Status of this `id_number` check.
         */
        status: IdNumber.Status;
    }
    interface Options {
        document?: Options.Document;
        id_number?: Options.IdNumber;
    }
    interface Phone {
        /**
         * Details on the verification error. Present when status is `unverified`.
         */
        error: Phone.Error | null;
        /**
         * Phone to be verified.
         */
        phone: string | null;
        /**
         * Status of this `phone` check.
         */
        status: Phone.Status;
    }
    interface Selfie {
        /**
         * ID of the [File](https://docs.stripe.com/api/files) holding the image of the identity document used in this check.
         */
        document: string | null;
        /**
         * Details on the verification error. Present when status is `unverified`.
         */
        error: Selfie.Error | null;
        /**
         * ID of the [File](https://docs.stripe.com/api/files) holding the image of the selfie used in this check.
         */
        selfie: string | null;
        /**
         * Status of this `selfie` check.
         */
        status: Selfie.Status;
    }
    type Type = 'document' | 'id_number' | 'verification_flow' | OtherString;
    namespace Document {
        interface Dob {
            /**
             * Numerical day between 1 and 31.
             */
            day: number | null;
            /**
             * Numerical month between 1 and 12.
             */
            month: number | null;
            /**
             * The four-digit year.
             */
            year: number | null;
        }
        interface Error {
            /**
             * A short machine-readable string giving the reason for the verification failure.
             */
            code: Error.Code | null;
            /**
             * A human-readable message giving the reason for the failure. These messages can be shown to your users.
             */
            reason: string | null;
        }
        interface ExpirationDate {
            /**
             * Numerical day between 1 and 31.
             */
            day: number | null;
            /**
             * Numerical month between 1 and 12.
             */
            month: number | null;
            /**
             * The four-digit year.
             */
            year: number | null;
        }
        interface IssuedDate {
            /**
             * Numerical day between 1 and 31.
             */
            day: number | null;
            /**
             * Numerical month between 1 and 12.
             */
            month: number | null;
            /**
             * The four-digit year.
             */
            year: number | null;
        }
        type Sex = '[redacted]' | 'female' | 'male' | 'unknown' | OtherString;
        type Status = 'unverified' | 'verified' | OtherString;
        type Type = 'driving_license' | 'id_card' | 'passport' | OtherString;
        namespace Error {
            type Code = 'document_expired' | 'document_type_not_supported' | 'document_unverified_other' | OtherString;
        }
    }
    namespace Email {
        interface Error {
            /**
             * A short machine-readable string giving the reason for the verification failure.
             */
            code: Error.Code | null;
            /**
             * A human-readable message giving the reason for the failure. These messages can be shown to your users.
             */
            reason: string | null;
        }
        type Status = 'unverified' | 'verified' | OtherString;
        namespace Error {
            type Code = 'email_unverified_other' | 'email_verification_declined' | OtherString;
        }
    }
    namespace IdNumber {
        interface Dob {
            /**
             * Numerical day between 1 and 31.
             */
            day: number | null;
            /**
             * Numerical month between 1 and 12.
             */
            month: number | null;
            /**
             * The four-digit year.
             */
            year: number | null;
        }
        interface Error {
            /**
             * A short machine-readable string giving the reason for the verification failure.
             */
            code: Error.Code | null;
            /**
             * A human-readable message giving the reason for the failure. These messages can be shown to your users.
             */
            reason: string | null;
        }
        type IdNumberType = 'br_cpf' | 'sg_nric' | 'us_ssn' | OtherString;
        type Status = 'unverified' | 'verified' | OtherString;
        namespace Error {
            type Code = 'id_number_insufficient_document_data' | 'id_number_mismatch' | 'id_number_unverified_other' | OtherString;
        }
    }
    namespace Options {
        interface Document {
            /**
             * Array of strings of allowed identity document types. If the provided identity document isn't one of the allowed types, the verification check will fail with a document_type_not_allowed error code.
             */
            allowed_types?: Array<Document.AllowedType>;
            /**
             * Collect an ID number and perform an [ID number check](https://docs.stripe.com/identity/verification-checks?type=id-number) with the document's extracted name and date of birth.
             */
            require_id_number?: boolean;
            /**
             * Disable image uploads, identity document images have to be captured using the device's camera.
             */
            require_live_capture?: boolean;
            /**
             * Capture a face image and perform a [selfie check](https://docs.stripe.com/identity/verification-checks?type=selfie) comparing a photo ID and a picture of your user's face. [Learn more](https://docs.stripe.com/identity/selfie).
             */
            require_matching_selfie?: boolean;
        }
        interface IdNumber {
        }
        namespace Document {
            type AllowedType = 'driving_license' | 'id_card' | 'passport' | OtherString;
        }
    }
    namespace Phone {
        interface Error {
            /**
             * A short machine-readable string giving the reason for the verification failure.
             */
            code: Error.Code | null;
            /**
             * A human-readable message giving the reason for the failure. These messages can be shown to your users.
             */
            reason: string | null;
        }
        type Status = 'unverified' | 'verified' | OtherString;
        namespace Error {
            type Code = 'phone_unverified_other' | 'phone_verification_declined' | OtherString;
        }
    }
    namespace Selfie {
        interface Error {
            /**
             * A short machine-readable string giving the reason for the verification failure.
             */
            code: Error.Code | null;
            /**
             * A human-readable message giving the reason for the failure. These messages can be shown to your users.
             */
            reason: string | null;
        }
        type Status = 'unverified' | 'verified' | OtherString;
        namespace Error {
            type Code = 'selfie_document_missing_photo' | 'selfie_face_mismatch' | 'selfie_manipulated' | 'selfie_unverified_other' | OtherString;
        }
    }
}
export declare namespace Identity {
    interface VerificationReportRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Identity {
    interface VerificationReportListParams extends PaginationParams {
        /**
         * A string to reference this user. This can be a customer ID, a session ID, or similar, and can be used to reconcile this verification with your internal systems.
         */
        client_reference_id?: string;
        /**
         * Only return VerificationReports that were created during the given date interval.
         */
        created?: RangeQueryParam | number;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
        /**
         * Only return VerificationReports of this type
         */
        type?: VerificationReportListParams.Type;
        /**
         * Only return VerificationReports created by this VerificationSession ID. It is allowed to provide a VerificationIntent ID.
         */
        verification_session?: string;
    }
    namespace VerificationReportListParams {
        type Type = 'document' | 'id_number' | OtherString;
    }
}
