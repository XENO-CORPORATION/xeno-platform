import { AccountOwner } from './AccountOwners.js';
import { ApiList } from '../../lib.js';
export interface AccountOwnership {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'financial_connections.account_ownership';
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * A paginated list of owners for this account.
     */
    owners: ApiList<AccountOwner>;
}
