import { StripeResource } from '../../StripeResource.js';
import { Feature } from './Features.js';
import { PaginationParams } from '../../shared.js';
import { RequestOptions, ApiListPromise, Response } from '../../lib.js';
export declare class ActiveEntitlementResource extends StripeResource {
    /**
     * Retrieve a list of active entitlements for a customer
     */
    list(params: Entitlements.ActiveEntitlementListParams, options?: RequestOptions): ApiListPromise<ActiveEntitlement>;
    /**
     * Retrieve an active entitlement
     */
    retrieve(id: string, params?: Entitlements.ActiveEntitlementRetrieveParams, options?: RequestOptions): Promise<Response<ActiveEntitlement>>;
}
export interface ActiveEntitlement {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'entitlements.active_entitlement';
    /**
     * The [Feature](https://docs.stripe.com/api/entitlements/feature) that the customer is entitled to.
     */
    feature: string | Feature;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * A unique key you provide as your own system identifier. This may be up to 80 characters.
     */
    lookup_key: string;
}
export declare namespace Entitlements {
    interface ActiveEntitlementRetrieveParams {
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
export declare namespace Entitlements {
    interface ActiveEntitlementListParams extends PaginationParams {
        /**
         * The ID of the customer.
         */
        customer: string;
        /**
         * Specifies which fields in the response should be expanded.
         */
        expand?: Array<string>;
    }
}
