import { OtherString } from '../shared.js';
export interface CashBalance {
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'cash_balance';
    /**
     * A hash of all cash balances available to this customer. You cannot delete a customer with any cash balances, even if the balance is 0. Amounts are represented in the [smallest currency unit](https://docs.stripe.com/currencies#zero-decimal).
     */
    available: {
        [key: string]: number;
    } | null;
    /**
     * The ID of the customer whose cash balance this object represents.
     */
    customer: string;
    /**
     * The ID of an Account representing a customer whose cash balance this object represents.
     */
    customer_account: string | null;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    settings: CashBalance.Settings;
}
export declare namespace CashBalance {
    interface Settings {
        /**
         * The configuration for how funds that land in the customer cash balance are reconciled.
         */
        reconciliation_mode: Settings.ReconciliationMode;
        /**
         * A flag to indicate if reconciliation mode returned is the user's default or is specific to this customer cash balance
         */
        using_merchant_default: boolean;
    }
    namespace Settings {
        type ReconciliationMode = 'automatic' | 'manual' | OtherString;
    }
}
