import { StripeResource } from '../StripeResource.js';
import { DeletedProductFeature, ProductFeature } from './ProductFeatures.js';
import { Price } from './Prices.js';
import { TaxCode } from './TaxCodes.js';
import { MetadataParam, Decimal, OtherString, Emptyable, PaginationParams, RangeQueryParam, Metadata } from '../shared.js';
import { RequestOptions, Response, ApiListPromise, ApiSearchResultPromise } from '../lib.js';
export declare class ProductResource extends StripeResource {
    /**
     * Delete a product. Deleting a product is only possible if it has no prices associated with it. Additionally, deleting a product with type=good is only possible if it has no SKUs associated with it.
     */
    del(id: string, params?: ProductDeleteParams, options?: RequestOptions): Promise<Response<DeletedProduct>>;
    /**
     * Retrieves the details of an existing product. Supply the unique product ID from either a product creation request or the product list, and Stripe will return the corresponding product information.
     */
    retrieve(id: string, params?: ProductRetrieveParams, options?: RequestOptions): Promise<Response<Product>>;
    /**
     * Updates the specific product by setting the values of the parameters passed. Any parameters not provided will be left unchanged.
     */
    update(id: string, params?: ProductUpdateParams, options?: RequestOptions): Promise<Response<Product>>;
    /**
     * Returns a list of your products. The products are returned sorted by creation date, with the most recently created products appearing first.
     */
    list(params?: ProductListParams, options?: RequestOptions): ApiListPromise<Product>;
    /**
     * Creates a new product object.
     */
    create(params: ProductCreateParams, options?: RequestOptions): Promise<Response<Product>>;
    /**
     * Search for products you've previously created using Stripe's [Search Query Language](https://docs.stripe.com/docs/search#search-query-language).
     * Don't use search in read-after-write flows where strict consistency is necessary. Under normal operating
     * conditions, data is searchable in less than a minute. Occasionally, propagation of new or updated data can be up
     * to an hour behind during outages. Search functionality is not available to merchants in India.
     */
    search(params: ProductSearchParams, options?: RequestOptions): ApiSearchResultPromise<Product>;
    /**
     * Deletes the feature attachment to a product
     */
    deleteFeature(productId: string, id: string, params?: ProductDeleteFeatureParams, options?: RequestOptions): Promise<Response<DeletedProductFeature>>;
    /**
     * Retrieves a product_feature, which represents a feature attachment to a product
     */
    retrieveFeature(productId: string, id: string, params?: ProductRetrieveFeatureParams, options?: RequestOptions): Promise<Response<ProductFeature>>;
    /**
     * Retrieve a list of features for a product
     */
    listFeatures(id: string, params?: ProductListFeaturesParams, options?: RequestOptions): ApiListPromise<ProductFeature>;
    /**
     * Creates a product_feature, which represents a feature attachment to a product
     */
    createFeature(id: string, params: ProductCreateFeatureParams, options?: RequestOptions): Promise<Response<ProductFeature>>;
}
export interface Product {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'product';
    /**
     * Whether the product is currently available for purchase.
     */
    active: boolean;
    /**
     * Time at which the object was created. Measured in seconds since the Unix epoch.
     */
    created: number;
    /**
     * The ID of the [Price](https://docs.stripe.com/api/prices) object that is the default price for this product.
     */
    default_price?: string | Price | null;
    /**
     * Always true for a deleted object
     */
    deleted?: void;
    /**
     * The product's description, meant to be displayable to the customer. Use this field to optionally store a long form explanation of the product being sold for your own rendering purposes.
     */
    description: string | null;
    /**
     * A list of up to 8 URLs of images for this product, meant to be displayable to the customer.
     */
    images: Array<string>;
    /**
     * If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
     */
    livemode: boolean;
    /**
     * A list of up to 15 marketing features for this product. These are displayed in [pricing tables](https://docs.stripe.com/payments/checkout/pricing-table).
     */
    marketing_features: Array<Product.MarketingFeature>;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
     */
    metadata: Metadata;
    /**
     * The product's name, meant to be displayable to the customer.
     */
    name: string;
    /**
     * The dimensions of this product for shipping purposes.
     */
    package_dimensions: Product.PackageDimensions | null;
    /**
     * Whether this product is shipped (i.e., physical goods).
     */
    shippable: boolean | null;
    /**
     * Extra information about a product which will appear on your customer's credit card statement. In the case that multiple products are billed at once, the first statement descriptor will be used. Only used for subscription payments.
     */
    statement_descriptor?: string | null;
    /**
     * A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
     */
    tax_code?: string | TaxCode | null;
    /**
     * The type of the product. The product is either of type `good`, which is eligible for use with Orders and SKUs, or `service`, which is eligible for use with Subscriptions and Plans.
     */
    type: Product.Type;
    /**
     * A label that represents units of this product. When set, this will be included in customers' receipts, invoices, Checkout, and the customer portal.
     */
    unit_label?: string | null;
    /**
     * Time at which the object was last updated. Measured in seconds since the Unix epoch.
     */
    updated: number;
    /**
     * A URL of a publicly-accessible webpage for this product.
     */
    url: string | null;
}
export interface DeletedProduct {
    /**
     * Unique identifier for the object.
     */
    id: string;
    /**
     * String representing the object's type. Objects of the same type share the same value.
     */
    object: 'product';
    /**
     * Always true for a deleted object
     */
    deleted: true;
}
export declare namespace Product {
    interface MarketingFeature {
        /**
         * The marketing feature name. Up to 80 characters long.
         */
        name?: string;
    }
    interface PackageDimensions {
        /**
         * Height, in inches.
         */
        height: number;
        /**
         * Length, in inches.
         */
        length: number;
        /**
         * Weight, in ounces.
         */
        weight: number;
        /**
         * Width, in inches.
         */
        width: number;
    }
    type Type = 'good' | 'service' | OtherString;
}
export interface ProductCreateParams {
    /**
     * The product's name, meant to be displayable to the customer.
     */
    name: string;
    /**
     * Whether the product is currently available for purchase. Defaults to `true`.
     */
    active?: boolean;
    /**
     * Data used to generate a new [Price](https://docs.stripe.com/api/prices) object. This Price will be set as the default price for this product.
     */
    default_price_data?: ProductCreateParams.DefaultPriceData;
    /**
     * The product's description, meant to be displayable to the customer. Use this field to optionally store a long form explanation of the product being sold for your own rendering purposes.
     */
    description?: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * An identifier will be randomly generated by Stripe. You can optionally override this ID, but the ID must be unique across all products in your Stripe account.
     */
    id?: string;
    /**
     * A list of up to 8 URLs of images for this product, meant to be displayable to the customer.
     */
    images?: Array<string>;
    /**
     * A list of up to 15 marketing features for this product. These are displayed in [pricing tables](https://docs.stripe.com/payments/checkout/pricing-table).
     */
    marketing_features?: Array<ProductCreateParams.MarketingFeature>;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
     */
    metadata?: MetadataParam;
    /**
     * The dimensions of this product for shipping purposes.
     */
    package_dimensions?: ProductCreateParams.PackageDimensions;
    /**
     * Whether this product is shipped (i.e., physical goods).
     */
    shippable?: boolean;
    /**
     * An arbitrary string to be displayed on your customer's credit card or bank statement. While most banks display this information consistently, some may display it incorrectly or not at all.
     *
     * This may be up to 22 characters. The statement description may not include `<`, `>`, `\`, `"`, `'` characters, and will appear on your customer's statement in capital letters. Non-ASCII characters are automatically stripped.
     *  It must contain at least one letter. Only used for subscription payments.
     */
    statement_descriptor?: string;
    /**
     * A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
     */
    tax_code?: string;
    /**
     * The type of the product. Defaults to `service` if not explicitly specified, enabling use of this product with Subscriptions and Plans. Set this parameter to `good` to use this product with Orders and SKUs. On API versions before `2018-02-05`, this field defaults to `good` for compatibility reasons.
     */
    type?: ProductCreateParams.Type;
    /**
     * A label that represents units of this product. When set, this will be included in customers' receipts, invoices, Checkout, and the customer portal.
     */
    unit_label?: string;
    /**
     * A URL of a publicly-accessible webpage for this product.
     */
    url?: string;
}
export declare namespace ProductCreateParams {
    interface DefaultPriceData {
        /**
         * Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
         */
        currency: string;
        /**
         * Prices defined in each available currency option. Each key must be a three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html) and a [supported currency](https://stripe.com/docs/currencies).
         */
        currency_options?: {
            [key: string]: DefaultPriceData.CurrencyOptions;
        };
        /**
         * When set, provides configuration for the amount to be adjusted by the customer during Checkout Sessions and Payment Links.
         */
        custom_unit_amount?: DefaultPriceData.CustomUnitAmount;
        /**
         * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
         */
        metadata?: MetadataParam;
        /**
         * The recurring components of a price such as `interval` and `interval_count`.
         */
        recurring?: DefaultPriceData.Recurring;
        /**
         * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
         */
        tax_behavior?: DefaultPriceData.TaxBehavior;
        /**
         * A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge. One of `unit_amount`, `unit_amount_decimal`, or `custom_unit_amount` is required.
         */
        unit_amount?: number;
        /**
         * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
         */
        unit_amount_decimal?: Decimal;
    }
    interface MarketingFeature {
        /**
         * The marketing feature name. Up to 80 characters long.
         */
        name: string;
    }
    interface PackageDimensions {
        /**
         * Height, in inches. Maximum precision is 2 decimal places.
         */
        height: number;
        /**
         * Length, in inches. Maximum precision is 2 decimal places.
         */
        length: number;
        /**
         * Weight, in ounces. Maximum precision is 2 decimal places.
         */
        weight: number;
        /**
         * Width, in inches. Maximum precision is 2 decimal places.
         */
        width: number;
    }
    type Type = 'good' | 'service' | OtherString;
    namespace DefaultPriceData {
        interface CurrencyOptions {
            /**
             * When set, provides configuration for the amount to be adjusted by the customer during Checkout Sessions and Payment Links.
             */
            custom_unit_amount?: CurrencyOptions.CustomUnitAmount;
            /**
             * Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
             */
            tax_behavior?: CurrencyOptions.TaxBehavior;
            /**
             * Each element represents a pricing tier. This parameter requires `billing_scheme` to be set to `tiered`. See also the documentation for `billing_scheme`.
             */
            tiers?: Array<CurrencyOptions.Tier>;
            /**
             * A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge.
             */
            unit_amount?: number;
            /**
             * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
             */
            unit_amount_decimal?: Decimal;
        }
        interface CustomUnitAmount {
            /**
             * Pass in `true` to enable `custom_unit_amount`, otherwise omit `custom_unit_amount`.
             */
            enabled: boolean;
            /**
             * The maximum unit amount the customer can specify for this item.
             */
            maximum?: number;
            /**
             * The minimum unit amount the customer can specify for this item. Must be at least the minimum charge amount.
             */
            minimum?: number;
            /**
             * The starting unit amount which can be updated by the customer.
             */
            preset?: number;
        }
        interface Recurring {
            /**
             * Specifies billing frequency. Either `day`, `week`, `month` or `year`.
             */
            interval: Recurring.Interval;
            /**
             * The number of intervals between subscription billings. For example, `interval=month` and `interval_count=3` bills every 3 months. Maximum of three years interval allowed (3 years, 36 months, or 156 weeks).
             */
            interval_count?: number;
        }
        type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
        namespace CurrencyOptions {
            interface CustomUnitAmount {
                /**
                 * Pass in `true` to enable `custom_unit_amount`, otherwise omit `custom_unit_amount`.
                 */
                enabled: boolean;
                /**
                 * The maximum unit amount the customer can specify for this item.
                 */
                maximum?: number;
                /**
                 * The minimum unit amount the customer can specify for this item. Must be at least the minimum charge amount.
                 */
                minimum?: number;
                /**
                 * The starting unit amount which can be updated by the customer.
                 */
                preset?: number;
            }
            type TaxBehavior = 'exclusive' | 'inclusive' | 'unspecified' | OtherString;
            interface Tier {
                /**
                 * The flat billing amount for an entire tier, regardless of the number of units in the tier.
                 */
                flat_amount?: number;
                /**
                 * Same as `flat_amount`, but accepts a decimal value representing an integer in the minor units of the currency. Only one of `flat_amount` and `flat_amount_decimal` can be set.
                 */
                flat_amount_decimal?: Decimal;
                /**
                 * The per unit billing amount for each individual unit for which this tier applies.
                 */
                unit_amount?: number;
                /**
                 * Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
                 */
                unit_amount_decimal?: Decimal;
                /**
                 * Specifies the upper bound of this tier. The lower bound of a tier is the upper bound of the previous tier adding one. Use `inf` to define a fallback tier.
                 */
                up_to: 'inf' | number;
            }
        }
        namespace Recurring {
            type Interval = 'day' | 'month' | 'week' | 'year' | OtherString;
        }
    }
}
export interface ProductRetrieveParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface ProductUpdateParams {
    /**
     * Whether the product is available for purchase.
     */
    active?: boolean;
    /**
     * The ID of the [Price](https://docs.stripe.com/api/prices) object that is the default price for this product.
     */
    default_price?: string;
    /**
     * The product's description, meant to be displayable to the customer. Use this field to optionally store a long form explanation of the product being sold for your own rendering purposes.
     */
    description?: Emptyable<string>;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * A list of up to 8 URLs of images for this product, meant to be displayable to the customer.
     */
    images?: Emptyable<Array<string>>;
    /**
     * A list of up to 15 marketing features for this product. These are displayed in [pricing tables](https://docs.stripe.com/payments/checkout/pricing-table).
     */
    marketing_features?: Emptyable<Array<ProductUpdateParams.MarketingFeature>>;
    /**
     * Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
     */
    metadata?: Emptyable<MetadataParam>;
    /**
     * The product's name, meant to be displayable to the customer.
     */
    name?: string;
    /**
     * The dimensions of this product for shipping purposes.
     */
    package_dimensions?: Emptyable<ProductUpdateParams.PackageDimensions>;
    /**
     * Whether this product is shipped (i.e., physical goods).
     */
    shippable?: boolean;
    /**
     * An arbitrary string to be displayed on your customer's credit card or bank statement. While most banks display this information consistently, some may display it incorrectly or not at all.
     *
     * This may be up to 22 characters. The statement description may not include `<`, `>`, `\`, `"`, `'` characters, and will appear on your customer's statement in capital letters. Non-ASCII characters are automatically stripped.
     *  It must contain at least one letter. May only be set if `type=service`. Only used for subscription payments.
     */
    statement_descriptor?: string;
    /**
     * A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
     */
    tax_code?: Emptyable<string>;
    /**
     * A label that represents units of this product. When set, this will be included in customers' receipts, invoices, Checkout, and the customer portal. May only be set if `type=service`.
     */
    unit_label?: Emptyable<string>;
    /**
     * A URL of a publicly-accessible webpage for this product.
     */
    url?: Emptyable<string>;
}
export declare namespace ProductUpdateParams {
    interface MarketingFeature {
        /**
         * The marketing feature name. Up to 80 characters long.
         */
        name: string;
    }
    interface PackageDimensions {
        /**
         * Height, in inches. Maximum precision is 2 decimal places.
         */
        height: number;
        /**
         * Length, in inches. Maximum precision is 2 decimal places.
         */
        length: number;
        /**
         * Weight, in ounces. Maximum precision is 2 decimal places.
         */
        weight: number;
        /**
         * Width, in inches. Maximum precision is 2 decimal places.
         */
        width: number;
    }
}
export interface ProductListParams extends PaginationParams {
    /**
     * Only return products that are active or inactive (e.g., pass `false` to list all inactive products).
     */
    active?: boolean;
    /**
     * Only return products that were created during the given date interval.
     */
    created?: RangeQueryParam | number;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * Only return products with the given IDs. Cannot be used with [starting_after](https://api.stripe.com#list_products-starting_after) or [ending_before](https://api.stripe.com#list_products-ending_before).
     */
    ids?: Array<string>;
    /**
     * Only return products that can be shipped (i.e., physical, not digital products).
     */
    shippable?: boolean;
    /**
     * Only return products of this type.
     */
    type?: ProductListParams.Type;
    /**
     * Only return products with the given url.
     */
    url?: string;
}
export declare namespace ProductListParams {
    type Type = 'good' | 'service' | OtherString;
}
export interface ProductDeleteParams {
}
export interface ProductCreateFeatureParams {
    /**
     * The ID of the [Feature](https://docs.stripe.com/api/entitlements/feature) object attached to this product.
     */
    entitlement_feature: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface ProductDeleteFeatureParams {
}
export interface ProductListFeaturesParams extends PaginationParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface ProductRetrieveFeatureParams {
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
}
export interface ProductSearchParams {
    /**
     * The search query string. See [search query language](https://docs.stripe.com/search#search-query-language) and the list of supported [query fields for products](https://docs.stripe.com/search#query-fields-for-products).
     */
    query: string;
    /**
     * Specifies which fields in the response should be expanded.
     */
    expand?: Array<string>;
    /**
     * A limit on the number of objects to be returned. Limit can range between 1 and 100, and the default is 10.
     */
    limit?: number;
    /**
     * A cursor for pagination across multiple pages of results. Don't include this parameter on the first call. Use the next_page value returned in a previous response to request subsequent results.
     */
    page?: string;
}
