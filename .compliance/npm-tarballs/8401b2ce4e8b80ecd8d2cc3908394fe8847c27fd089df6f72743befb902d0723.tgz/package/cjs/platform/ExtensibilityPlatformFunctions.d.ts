import { CryptoProvider } from '../crypto/CryptoProvider.js';
import { FetchHttpClientInterface, HttpClient, NodeHttpClientInterface } from '../net/HttpClient.js';
import { StripeEventEmitter } from '../StripeEventEmitter.js';
import { BufferedFile, MultipartRequestData, RequestAuthenticator, RequestData } from '../Types.js';
import { PlatformFunctions } from './PlatformFunctions.js';
/**
 * Platform functions for extensibility scripts.
 */
export declare class ExtensibilityPlatformFunctions extends PlatformFunctions {
    /** @override */
    emitWarning(_warning: string): void;
    /** @override */
    getEnv(): null;
    /** @override */
    getRuntimeVersion(): null;
    /** @override */
    getDefaultMaxNetworkRetries(): number;
    /** @override */
    createDefaultAuthenticator(): RequestAuthenticator;
    /** @override */
    createEmitter(): StripeEventEmitter;
    /** @override */
    tryBufferData(data: MultipartRequestData): Promise<RequestData | BufferedFile>;
    /** @override */
    createDefaultHttpClient(): HttpClient;
    /** @override */
    createFetchHttpClient(): FetchHttpClientInterface;
    /** @override */
    createNodeHttpClient(): NodeHttpClientInterface;
    /** @override */
    createNodeCryptoProvider(): CryptoProvider;
    /** @override */
    createDefaultCryptoProvider(): CryptoProvider;
}
