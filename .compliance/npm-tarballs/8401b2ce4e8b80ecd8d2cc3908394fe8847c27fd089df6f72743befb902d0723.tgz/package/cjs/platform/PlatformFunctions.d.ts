/// <reference types="node" />
import * as http from 'http';
import { CryptoProvider } from '../crypto/CryptoProvider.js';
import { HttpClient, NodeHttpClientInterface, FetchHttpClientInterface } from '../net/HttpClient.js';
import { MultipartRequestData, RequestData, BufferedFile, RequestEvent, ResponseEvent, RequestAuthenticator } from '../Types.js';
export interface StripeEmitterInterface {
    on(eventName: string, listener: (...args: any[]) => any): void;
    once(eventName: string, listener: (...args: any[]) => any): void;
    removeListener(eventName: string, listener: (...args: any[]) => any): void;
    emit(eventName: string, data?: RequestEvent | ResponseEvent): boolean;
}
/**
 * Interface encapsulating various utility functions whose
 * implementations depend on the platform / JS runtime.
 */
export declare class PlatformFunctions {
    _fetchFn: any | null;
    _agent: http.Agent | null;
    constructor();
    /**
     * Returns platform info string for telemetry, or null if unavailable.
     */
    getPlatformInfo(): string | null;
    getTelemetryId(): string | null;
    /**
     * Writes a message to stderr, or does nothing if unavailable.
     */
    writeStderr(_msg: string): void;
    /**
     * Emits a warning. Node.js uses process.emitWarning; other runtimes
     * fall back to console.warn.
     */
    emitWarning(warning: string): void;
    /**
     * Returns environment variables, or null if unavailable.
     */
    getEnv(): Record<string, string | undefined> | null;
    /**
     * Returns the runtime version string, or null if unavailable.
     */
    getRuntimeVersion(): string | null;
    /**
     * Returns the default number of network retries for this platform.
     */
    getDefaultMaxNetworkRetries(): number;
    /**
     * Returns the default request authenticator for this platform.
     */
    createDefaultAuthenticator(): RequestAuthenticator | null;
    /**
     * Generates a v4 UUID. See https://stackoverflow.com/a/2117523
     */
    uuid4(): string;
    /**
     * Compares strings in constant time.
     */
    secureCompare(a: string, b: string): boolean;
    /**
     * Creates an event emitter.
     */
    createEmitter(): StripeEmitterInterface;
    /**
     * Checks if the request data is a stream. If so, read the entire stream
     * to a buffer and return the buffer.
     */
    tryBufferData(data: MultipartRequestData): Promise<RequestData | BufferedFile>;
    /**
     * Creates an HTTP client which uses the Node `http` and `https` packages
     * to issue requests.
     */
    createNodeHttpClient(agent?: http.Agent): NodeHttpClientInterface;
    /**
     * Creates an HTTP client for issuing Stripe API requests which uses the Web
     * Fetch API.
     *
     * A fetch function can optionally be passed in as a parameter. If none is
     * passed, will default to the default `fetch` function in the global scope.
     */
    createFetchHttpClient(fetchFn?: typeof fetch): FetchHttpClientInterface;
    /**
     * Creates an HTTP client using runtime-specific APIs.
     */
    createDefaultHttpClient(): HttpClient;
    /**
     * Creates a CryptoProvider which uses the Node `crypto` package for its computations.
     */
    createNodeCryptoProvider(): CryptoProvider;
    /**
     * Creates a CryptoProvider which uses the SubtleCrypto interface of the Web Crypto API.
     */
    createSubtleCryptoProvider(subtleCrypto?: typeof crypto.subtle): CryptoProvider;
    createDefaultCryptoProvider(): CryptoProvider;
}
