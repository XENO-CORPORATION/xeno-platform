import { CryptoProvider } from './crypto/CryptoProvider.js';
import { PlatformFunctions } from './platform/PlatformFunctions.js';
import { Event } from './resources/Events.js';
/**
 * Value of the `stripe-signature` header from Stripe.
 * Typically a string.
 *
 * Note that this is typed to accept an array of strings
 * so that it works seamlessly with express's types,
 * but will throw if an array is passed in practice
 * since express should never return this header as an array,
 * only a string.
 */
export type WebhookHeader = string | string[] | Uint8Array;
export type WebhookTestHeaderOptions = {
    timestamp?: number;
    payload: string;
    secret: string;
    scheme?: string;
    signature?: string;
    cryptoProvider?: CryptoProvider;
};
export type WebhookPayload = string | Uint8Array;
export type WebhookSignatureObject = {
    /**
     * Verifies the authenticity (and recency) of a webhook, throwing a `SignatureVerificationError`
     * if there's a mismatch. Useful for quickly validating incoming webhooks before storing them for
     * later processing (at which time you can use the `*WithoutVerification` methods for parsing).
     */
    verifyHeader: (encodedPayload: WebhookPayload, encodedHeader: WebhookHeader, secret: string, tolerance?: number, cryptoProvider?: CryptoProvider, receivedAt?: number) => boolean;
    /**
     * Verifies the authenticity (and recency) of a webhook (async version), throwing a
     * `SignatureVerificationError` if there's a mismatch.
     */
    verifyHeaderAsync: (encodedPayload: WebhookPayload, encodedHeader: WebhookHeader, secret: string, tolerance?: number, cryptoProvider?: CryptoProvider, receivedAt?: number) => Promise<boolean>;
};
export type WebhookObject = {
    DEFAULT_TOLERANCE: number;
    signature: WebhookSignatureObject | null;
    /**
     * Constructs a [snapshot event](https://docs.stripe.com/event-destinations#snapshot-payload) from an
     * incoming webhook after verifying its authenticity. To work with a webhook that has already been
     * verified (i.e. one from a cloud provider, an asynchronous queue, or during testing), see
     * `constructEventWithoutVerification`.
     */
    constructEvent: (payload: WebhookPayload, header: WebhookHeader, secret: string, tolerance?: number, cryptoProvider?: CryptoProvider, receivedAt?: number) => Event;
    /**
     * Constructs a [snapshot event](https://docs.stripe.com/event-destinations#snapshot-payload) from an
     * incoming webhook after verifying its authenticity (async version). To work with a webhook that
     * has already been verified (i.e. one from a cloud provider, an asynchronous queue, or during
     * testing), see `constructEventWithoutVerification`.
     */
    constructEventAsync: (payload: WebhookPayload, header: WebhookHeader, secret: string, tolerance?: number, cryptoProvider?: CryptoProvider, receivedAt?: number) => Promise<Event>;
    /**
     * Constructs a [snapshot event](https://docs.stripe.com/event-destinations#snapshot-payload) from an
     * incoming webhook without first verifying its authenticity. Should be used after calling
     * `webhooks.verifySignatureHeader(...)` or with input from a trusted source (such as
     * [AWS EventBridge](https://docs.stripe.com/event-destinations/eventbridge), or
     * [Azure Event Grid](https://docs.stripe.com/event-destinations/eventgrid) payload). Or, to verify &
     * construct in a single call, use `webhooks.constructEvent(...)` instead.
     */
    constructEventWithoutVerification: (payload: string) => Event;
    /**
     * Compute the `Stripe-Signature` header for a given webhook body & secret. Useful for signing
     * payloads in unit tests.
     *
     * @property {number} timestamp - Timestamp of the header. Defaults to Date.now()
     * @property {string} payload - JSON stringified payload object, containing the 'id' and 'object' parameters
     * @property {string} secret - Stripe webhook secret 'whsec_...'
     * @property {string} scheme - Version of API to hit. Defaults to 'v1'.
     * @property {string} signature - Computed webhook signature
     * @property {CryptoProvider} cryptoProvider - Crypto provider to use for computing the signature if none was provided. Defaults to NodeCryptoProvider.
     */
    generateTestHeaderString: (opts: WebhookTestHeaderOptions) => string;
    generateTestHeaderStringAsync: (opts: WebhookTestHeaderOptions) => Promise<string>;
};
export declare function createWebhooks(platformFunctions: PlatformFunctions): WebhookObject;
