export declare const ApiVersion = "2026-08-26.dahlia";
export declare const ApiMajorVersion = "dahlia";
