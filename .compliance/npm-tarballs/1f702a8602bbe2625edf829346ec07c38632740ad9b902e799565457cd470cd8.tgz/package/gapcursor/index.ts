export * from 'prosemirror-gapcursor'
