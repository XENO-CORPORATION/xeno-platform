# `@napi-rs/canvas-linux-arm-gnueabihf`

This is the **armv7-unknown-linux-gnueabihf** binary for `@napi-rs/canvas`
