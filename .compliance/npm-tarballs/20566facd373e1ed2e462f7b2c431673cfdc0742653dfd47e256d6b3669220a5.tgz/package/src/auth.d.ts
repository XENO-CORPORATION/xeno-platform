import { RequiredConfig } from "./config";
export declare const TOKEN_EXPIRATION_SECONDS = 120;
/**
 * Get a token to connect to the realtime endpoint.
 */
export declare function getTemporaryAuthToken(app: string, config: RequiredConfig): Promise<string>;
