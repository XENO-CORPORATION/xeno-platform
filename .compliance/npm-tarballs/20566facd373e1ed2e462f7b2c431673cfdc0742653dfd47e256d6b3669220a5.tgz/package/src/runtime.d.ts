export declare function isBrowser(): boolean;
export declare function getUserAgent(): string;
