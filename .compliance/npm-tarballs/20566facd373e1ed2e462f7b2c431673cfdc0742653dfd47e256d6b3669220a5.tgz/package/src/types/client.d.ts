import { EndpointTypeMap } from "./endpoints";
export type EndpointType = keyof EndpointTypeMap | (string & {});
export type InputType<T extends string> = T extends keyof EndpointTypeMap ? EndpointTypeMap[T]["input"] : Record<string, any>;
export type OutputType<T extends string> = T extends keyof EndpointTypeMap ? EndpointTypeMap[T]["output"] : any;
