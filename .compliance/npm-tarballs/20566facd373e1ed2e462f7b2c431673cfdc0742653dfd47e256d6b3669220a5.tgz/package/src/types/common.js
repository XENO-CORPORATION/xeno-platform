"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isQueueStatus = isQueueStatus;
exports.isCompletedQueueStatus = isCompletedQueueStatus;
function isQueueStatus(obj) {
    return obj && obj.status && obj.response_url;
}
function isCompletedQueueStatus(obj) {
    return isQueueStatus(obj) && obj.status === "COMPLETED";
}
//# sourceMappingURL=common.js.map